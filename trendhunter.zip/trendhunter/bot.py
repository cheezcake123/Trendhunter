#!/usr/bin/env python3
"""TrendHunter v2 — Binance spot momentum sleeve + USD-M futures breakout sleeve, operated from Telegram.

Run:  python3 bot.py [--data ~/trendhunter-data]
Mode starts as PAPER (simulated fills on live prices). Switch with /live in Telegram.
Futures sleeve: 4h Donchian breakout in a 1d EMA uptrend, exchange-side stops (strategy.py).
Spot sleeve: daily time-series momentum + volatility targeting on the top-volume majors (spot_strategy.py).
Capital is split between the two wallets (alloc_spot_pct) and rebalanced with universal transfers.
"""
from __future__ import annotations

import argparse
import logging
import logging.handlers
import math
import os
import queue
import secrets as pysecrets
import signal
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

import report as RP  # noqa: E402
import risk as R  # noqa: E402
import strategy as S  # noqa: E402
from binance_api import BinanceError, BinanceFutures, NetworkError, parse_filters  # noqa: E402
from binance_spot import BinanceSpot  # noqa: E402
from brokers import LiveBroker, PaperBroker, _chunks  # noqa: E402
from spot import SpotManager, utc_day  # noqa: E402
from store import Store, load_config  # noqa: E402
from telegram_client import Poller, Telegram  # noqa: E402

KST = timezone(timedelta(hours=9))
TF_SECONDS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200,
              "4h": 14400, "6h": 21600, "8h": 28800, "12h": 43200, "1d": 86400}

SIDE_KO = {S.LONG: "롱", S.SHORT: "숏"}
SIDE_ICON = {S.LONG: "🟢", S.SHORT: "🔴"}
EXIT_KO = {
    "STOP": "손절",
    "TRAIL": "추적 손절·이익 보호",
    "TIME": "시간 손절",
    "REVERSE": "반대 신호",
    "SOFT_STOP": "봇 백업 손절",
    "STOP_NOW": "손절가 통과 즉시 청산",
    "NO_STOP": "손절 주문 실패 안전 청산",
    "MANUAL": "수동 청산",
    "EXTERNAL": "외부 청산(앱에서 직접 등)",
}

KEYBOARD = [["📊 상태", "💰 손익"], ["🪙 현물", "🔎 스캔"], ["📜 기록", "⚖️ 배분"], ["⏸ 정지", "▶️ 재개"], ["❓ 도움말"]]
LABEL_CMD = {"📊 상태": "status", "💰 손익": "pnl", "🔎 스캔": "scan", "📜 기록": "log", "🪙 현물": "spot",
             "⚖️ 배분": "alloc", "⏸ 정지": "pause", "▶️ 재개": "resume", "❓ 도움말": "help"}
PRESETS = {  # name: (spot %, futures risk per trade %, spot vol target, pyramiding adds)
    "안정": (70, 2.0, 0.6, 2),
    "기본": (50, 2.5, 0.6, 2),
    "공격": (40, 3.0, 0.6, 2),
}
PRESET_NOTE = {  # v2.4 rules on Binance candles 2020-01 ~ 2026-11, funding assumed 0.03% per 8h
    "안정": "과거 최대낙폭 약 -28%, 2024~26 연 42%",
    "기본": "과거 최대낙폭 약 -35%, 2024~26 연 60%",
    "공격": "과거 최대낙폭 약 -41%, 2024~26 연 74%",
}
# Outside money (deposits, withdrawals, transfers made by hand in the app): see Trader.flow_pass
FLOW_TYPES = ("TRANSFER", "INTERNAL_TRANSFER", "COIN_SWAP_DEPOSIT", "COIN_SWAP_WITHDRAW",
              "CROSS_COLLATERAL_TRANSFER", "STRATEGY_UMFUTURES_TRANSFER")  # income rows that move money: not results
FLOW_EVERY_S = 600            # regular look at both wallets
FLOW_BACK_MS = 900_000        # income rows are read again this far back (a row can show up late); seen ones are skipped
FLOW_RELEASE_S = FLOW_BACK_MS / 1000 + 60  # a change no row explains counts as a result once its row cannot turn up
FLOW_GIVE_UP_S = 86400        # while the history cannot be read at all: a day at the very most
FLOW_SPAN_MS = 2 * 3_600_000  # how far a transfer of the bot and its income row may lie apart
LEDGER_BASES = ("start_equity", "peak_equity", "day_start_equity")

WHATS_NEW = {
    "2.6.0": "🆕 v2.6 — 펀딩비 과열 필터: 최근 3일 평균 펀딩비가 8시간당 0.04%를 넘는 코인은 새로 롱 진입하지 않습니다"
             "(롱이 몰린 구간은 보유 비용이 크고 되돌림이 잦음). 실제 선물 데이터 7년 백테스트에서 연수익이 오르고 "
             "최대낙폭은 얕아졌습니다. 보유 중인 포지션과 불타기는 그대로입니다. 끄기: /set funding_max_pct 0",
    "2.5.0": "🆕 v2.5 — 입금·출금을 봇이 스스로 알아챕니다(실전 모드, 10분 안). 수익률·최대낙폭·월간 리포트는 넣거나 뺀 "
             "돈을 빼고 계산하고, 새로 넣은 돈은 다음 09:05 KST 점검 때 현물·선물로 나눕니다.\n"
             "기록 보기: /flows · 잘못 잡힌 기록 취소: /flows undo · 입금 뒤 /rebase 는 이제 필요 없습니다.\n"
             "주식·원자재 기반(TradFi) 무기한은 거래 시간이 따로 있어 선물 종목으로 받지 않습니다.",
    "2.4.0": "🆕 v2.4 — 불타기(수익 중 추가 진입)를 쓸 수 있습니다. 기본은 꺼져 있고 /preset 에서 단계를 고르면 켜집니다.\n"
             "선물 진입은 이제 같은 포지션 크기를 더 적은 증거금으로 잡습니다(레버리지 숫자는 커지지만 손절 위험은 같고, "
             "손절이 미끄러질 때 잃을 수 있는 최대 금액이 줄어듭니다).",
}
COMMANDS = [
    ("status", "현재 상태·보유 포지션"), ("pnl", "손익 성과"), ("spot", "현물 보유·목표 비중"),
    ("alloc", "현물/선물 배분: /alloc 50"), ("preset", "위험 단계: /preset 기본"), ("scan", "종목별 신호 상태"),
    ("log", "최근 판단 기록"), ("pause", "신규 진입·불타기 일시정지"), ("resume", "신규 진입 재개"),
    ("close", "포지션 청산: /close BTC"), ("closeall", "전체 청산"), ("risk", "1회 위험 변경: /risk 3"),
    ("settings", "설정 보기"), ("set", "설정 변경: /set 키 값"), ("backtest", "백테스트: /backtest 365"),
    ("selftest", "계정·API 점검"), ("live", "실전 모드 전환"), ("paper", "모의 모드 전환"),
    ("update", "코드 업데이트"), ("rollback", "직전 버전 복구"), ("restart", "봇 재시작"),
    ("rebase", "자본 기준점 재설정"), ("export", "거래기록 CSV 받기"), ("report", "월간 리포트"),
    ("flows", "입금·출금 기록"), ("deposit", "놓친 입금 적기: /deposit 100"), ("withdraw", "놓친 출금 적기: /withdraw 100"),
    ("help", "도움말"),
]
SETTABLE = {
    "risk_per_trade_pct": (float, 0.25, 5.0),
    "max_open_positions": (int, 1, 6),
    "max_same_direction": (int, 1, 6),
    "max_entries_per_day": (int, 1, 24),
    "daily_loss_limit_pct": (float, 2.0, 30.0),
    "max_leverage": (int, 1, 20),
    "equity_floor_pct": (float, 0.0, 95.0),
    "loss_streak_limit": (int, 2, 10),
    "loss_streak_pause_hours": (float, 0.0, 72.0),
    "cooldown_after_loss_hours": (float, 0.0, 72.0),
    "time_stop_hours": (float, 0.0, 480.0),
    "pyramid_max_adds": (int, 0, 3),
    "pyramid_step_r": (float, 0.5, 5.0),
    "pyramid_risk_frac": (float, 0.1, 1.0),
    "liq_buffer_mult": (float, 0.0, 5.0),
    "funding_max_pct": (float, 0.0, 1.0),
    "allow_short": (bool, None, None),
    "allow_long": (bool, None, None),
    "adx_min": (float, 0.0, 50.0),
    "symbols": (list, None, None),
    "spot_enabled": (bool, None, None),
    "alloc_spot_pct": (float, 0.0, 100.0),
    "alloc_band_pct": (float, 2.0, 30.0),
    "spot_vol_target": (float, 0.2, 1.5),
    "spot_universe_size": (int, 1, 10),
    "spot_band_pct": (float, 1.0, 20.0),
    "spot_btc_gate": (bool, None, None),
    "spot_btc_gate_min": (float, 0.0, 1.0),
    "spot_earn": (bool, None, None),
    "spot_cash_yield": (float, 0.0, 0.3),
    "spot_candidates": ("spotlist", None, None),
    "update_url": (str, None, None),
    "brief_morning_kst": ("hhmm", None, None),
    "brief_evening_kst": ("hhmm", None, None),
    "monthly_report": (bool, None, None),
    "flow_detect": (bool, None, None),
}


# ---------------------------------------------------------------- formatting

def short(sym):
    return sym[:-4] if sym.endswith("USDT") else sym


def ver_key(v):
    """'2.10.1' -> (2, 10, 1) so versions compare as numbers."""
    return tuple(int(x) if x.isdigit() else 0 for x in str(v).split("."))


def usd(x, signed=True):
    if not signed:
        return f"${x:,.2f}"
    sign = "+" if x > 0.004 else ("-" if x < -0.004 else "")
    return f"{sign}${abs(x):,.2f}"


def px(x):
    if x is None:
        return "-"
    ax = abs(x)
    if ax >= 1000:
        return f"{x:,.1f}"
    if ax >= 100:
        return f"{x:,.2f}"
    if ax >= 1:
        return f"{x:,.4f}"
    return f"{x:.5f}"


def tfl(tf):
    return tf.upper()


def kst(ts):
    return datetime.fromtimestamp(ts, KST)


def hhmm(ts):
    return kst(ts).strftime("%m/%d %H:%M")


def setup_logging(store):
    log = logging.getLogger("trendhunter")
    if log.handlers:
        return log
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fh = logging.handlers.RotatingFileHandler(store.path("bot.log"), maxBytes=1_000_000, backupCount=5,
                                              encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    log.addHandler(sh)
    return log


# ---------------------------------------------------------------- trader

class Trader:
    def __init__(self, cfg, store, api, tg, log, clock=time.time, sleep=time.sleep, public_api_factory=None,
                 spot_api=None, spot_public_factory=None):
        self.cfg = cfg
        self.store = store
        self.api = api
        self.tg = tg
        self.log = log
        self.clock = clock
        self.sleep = sleep
        self.public_api_factory = public_api_factory or (lambda: BinanceFutures(base_url=api.base))
        self.spot_api = spot_api
        self.spot_public_factory = spot_public_factory or (
            lambda: BinanceSpot(base_url=self.spot_api.base if self.spot_api else "https://api.binance.com"))
        self.spot = None
        self.spot_ready = False
        self.spot_next_try = 0.0
        st = store.load_state() or {}
        self.ran_before = bool(st.get("ledger"))  # False on a fresh install
        st.setdefault("mode", "paper")
        st.setdefault("paused", False)
        st.setdefault("positions", {})
        st.setdefault("ledger", None)
        st.setdefault("last_candle", 0)
        st.setdefault("briefs", {})
        st.setdefault("blocked", None)
        st.setdefault("equity", None)
        st.setdefault("max_dd", 0.0)
        st.setdefault("spot", {})
        st.setdefault("total", {})
        st.setdefault("hist", [])
        st.setdefault("flow_fut", {})
        self.state = st
        self.filters = {}
        self.filters_loaded_at = 0.0
        self.data = {}
        self.marks = {}
        self.broker = None
        self.pending = {}
        self.exit_code = None
        self.bg_busy = None
        self.err_count = 0
        self.err_alerted = False
        self.last_alert = {}
        self.candle_retry = None
        self.fetch_failed = set()  # symbols whose last klines call failed
        self.funding_seen = {}     # (symbol, signal candle close ms) -> average funding rate (funding_ok)

    # ------------------------------------------------------------ basics
    @property
    def p(self):
        return self.cfg

    @property
    def positions(self):
        return self.state["positions"]

    @property
    def ledger(self):
        return self.state["ledger"]

    def now(self):
        return self.clock()

    def now_ms(self):
        return int(self.clock() * 1000)

    def symbols(self):
        if not self.filters:
            return list(self.cfg["symbols"])
        return [s for s in self.cfg["symbols"] if s in self.filters and self.plain_perp(s)]

    def data_symbols(self):
        """Symbols whose candles are fetched: the traded ones, plus any symbol the bot still holds a position in
        (it is managed to the end: trailing stop, time and reverse exits). No new entries or add-ons there."""
        held = [s for s in self.positions if s in self.cfg["symbols"] and s in self.filters and not self.plain_perp(s)]
        return self.symbols() + sorted(held)

    def plain_perp(self, sym):
        """Only ordinary crypto perpetuals are traded. Binance's stock / commodity perpetuals (TradFi) have
        trading hours of their own and halts during which a position cannot be managed; delivery contracts expire."""
        return (self.filters.get(sym) or {}).get("contract") in (None, "PERPETUAL")

    def mode_ko(self):
        return "실전(LIVE)" if self.state["mode"] == "live" else "모의(PAPER)"

    def save(self):
        self.store.save_state(self.state)

    def event(self, kind, **kw):
        try:
            self.store.event(kind, ts=self.now(), **kw)
        except Exception as e:  # logging must never break trading
            self.log.warning("event log failed: %s", e)

    def send(self, text, **kw):
        self.log.info("TG> %s", text.replace("\n", " | ")[:300])
        return self.tg.send(text, **kw) if self.tg else None

    def alert(self, key, text, every=1800):
        now = self.now()
        if now - self.last_alert.get(key, 0) >= every:
            self.last_alert[key] = now
            self.send(text)

    def make_broker(self):
        if self.state["mode"] == "live":
            return LiveBroker(self.api, self.filters, self.cfg, self.log)
        return PaperBroker(self.api, self.filters, self.cfg, self.store.path("paper.json"), self.log, self.clock)

    # ------------------------------------------------------------ lifecycle
    def startup(self):
        self.api.sync_time()
        self.load_filters()
        self.broker = self.make_broker()
        if self.state["mode"] == "live":
            self.check_account_settings(fix=True)
        for s in self.symbols():
            self.broker.prepare(s)
        self.marks = self.api.mark_prices(self.mark_symbols())
        self.broker.tick(self.marks)
        eq = self.broker.equity()
        now = self.now()
        if not self.ledger:
            self.state["ledger"] = R.new_ledger(eq["equity"], now)
        self.state["equity"] = eq["equity"]
        self.refresh_data()
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        cur_open = int(now // tf) * tf
        if not self.state.get("last_candle"):
            self.state["last_candle"] = (cur_open - tf) * 1000  # do not act on a candle that closed before start
        self.reconcile(startup=True)
        self.spot_startup()
        self.save()
        if self.tg:
            self.tg.set_commands(COMMANDS)
        lines = [f"🤖 {self.cfg['bot_name']} v{self.cfg['version']} 시작 — {self.mode_ko()}",
                 f"선물 {usd(eq['equity'], False)} | 감시 {len(self.symbols())}종목 | 1회 위험 {self.cfg['risk_per_trade_pct']}%",
                 f"보유 포지션 {len(self.positions)}개"]
        if self.cfg.get("spot_enabled", True):
            if self.spot_ready:
                sv = self.spot.cache or {}
                lines.append(f"현물 {usd(sv.get('equity', 0.0), False)} | 목표 배분 현물 {self.cfg['alloc_spot_pct']:g}% : 선물 "
                             f"{100 - float(self.cfg['alloc_spot_pct']):g}% | 리밸런싱 매일 09:05 KST")
            else:
                lines.append("⚠️ 현물 모듈 준비 실패 — 10분마다 재시도합니다 (/selftest 로 점검)")
        if self.state.get("blocked"):
            lines.append(f"⚠️ 신규 진입 차단: {self.state['blocked']}")
        if self.state.get("paused"):
            lines.append("⏸ 일시정지 상태입니다 (/resume 으로 재개)")
        self.send("\n".join(lines), keyboard=KEYBOARD)
        ver, seen = str(self.cfg["version"]), self.state.get("seen_version")
        if seen != ver:
            if ver_key(seen or "0") < ver_key("2.5.0"):
                # first start of v2.5 (also after a rollback to an older version and back): what is in the wallets
                # now is the starting point of the watch for outside money
                self.flow_reset()
            if seen or self.ran_before:  # an update, not a new install: every note the user has not seen yet
                for v in sorted(WHATS_NEW, key=ver_key):
                    if ver_key(seen or "0") < ver_key(v) <= ver_key(ver):
                        self.send(WHATS_NEW[v])
            self.state["seen_version"] = ver
            self.save()

    def load_filters(self):
        info = self.api.exchange_info()
        self.filters.clear()
        self.filters.update(parse_filters(info))
        self.filters_loaded_at = self.now()
        bad = [s for s in self.cfg["symbols"] if s not in self.filters or self.filters[s]["status"] != "TRADING"]
        if bad:
            self.alert("bad_symbols", f"⚠️ 거래 불가 종목 제외: {', '.join(bad)}", every=86400)
        other = [s for s in self.cfg["symbols"] if s in self.filters and not self.plain_perp(s)]
        if other:
            held = [s for s in other if s in self.positions]
            self.alert("tradfi_symbols", f"⚠️ {', '.join(other)}: 주식·원자재 기반(TradFi) 무기한과 만기 선물은 거래 시간이 따로 있고 "
                       "쉬는 동안 포지션을 관리할 수 없어 지원하지 않습니다. 새 진입 대상에서 제외했습니다."
                       + (f"\n이미 열린 포지션({', '.join(short(s) for s in held)})은 손절을 유지한 채 끝까지 관리합니다."
                          if held else ""), every=86400)

    def check_account_settings(self, fix=False):
        problems = []
        try:
            has_pos = bool(self.broker.positions()) if self.broker else False
            if self.api.get_position_mode():
                if fix and not has_pos:
                    self.api.set_position_mode(False)
                    self.send("🔧 포지션 모드를 헤지 → 단방향(One-way)으로 바꿨습니다.")
                else:
                    problems.append("헤지 모드 — 단방향(One-way)으로 바꿔주세요")
            if self.api.get_multi_assets():
                if fix and not has_pos:
                    self.api.set_multi_assets(False)
                    self.send("🔧 멀티에셋 모드 → 단일자산 모드로 바꿨습니다(격리 마진 사용을 위해).")
                else:
                    problems.append("멀티에셋 모드 — 단일자산 모드로 바꿔주세요")
        except (BinanceError, NetworkError) as e:
            problems.append(f"계정 설정 확인 실패: {e}")
        self.state["blocked"] = "; ".join(problems) or None
        return problems

    # ------------------------------------------------------------ market data
    def refresh_data(self, only=None):
        now = self.now()
        now_ms = int(now * 1000)
        tf_sec = TF_SECONDS[self.cfg["signal_tf"]]
        last_close_ms = int(now // tf_sec) * tf_sec * 1000 - 1  # close time of the candle that closed last
        wanted = self.data_symbols()
        for s in [s for s in self.data if s not in wanted]:
            self.data.pop(s, None)  # no longer watched: its last signal must not be traded
        for sym in wanted:
            if only is not None and sym not in only:
                continue
            try:
                raw1 = self.api.klines(sym, self.cfg["signal_tf"], limit=500)
                raw4 = self.api.klines(sym, self.cfg["trend_tf"], limit=1000)
            except (BinanceError, NetworkError) as e:
                self.log.warning("klines %s: %s", sym, e)
                self.data.pop(sym, None)
                self.fetch_failed.add(sym)
                continue
            self.fetch_failed.discard(sym)
            c1 = S.candles_from_klines(raw1, now_ms)
            c4 = S.candles_from_klines(raw4, now_ms)
            if len(c1["c"]) < 60 or not c4["c"]:
                self.data.pop(sym, None)
                continue
            ind = S.prepare_1h(c1, self.cfg)
            r4 = S.prepare_4h(c4, self.cfg)
            i = len(ind["c"]) - 1
            reg = S.regime_at(r4, ind["tc"][i])
            sig = S.evaluate(ind, i, reg, self.cfg)
            fresh = ind["tc"][i] >= last_close_ms - 1000  # the newest closed candle is really in the data
            self.data[sym] = {"ind": ind, "r4": r4, "sig": sig, "updated": now, "fresh": fresh}

    def stale_symbols(self):
        """Symbols whose newest closed candle did not arrive: the klines call failed, or it answered without the
        candle that just closed. A symbol that is not trading or too young for the indicators is not 'stale'."""
        out = []
        for s in self.symbols():
            if self.filters.get(s, {}).get("status", "TRADING") != "TRADING":
                continue
            d = self.data.get(s)
            if s in self.fetch_failed or (d is not None and not d.get("fresh")):
                out.append(s)
        return out

    def fresh_symbols(self):
        return {s for s, d in self.data.items() if d.get("fresh")}

    # ------------------------------------------------------------ main step
    def mark_symbols(self):
        return sorted(set(self.symbols()) | set(self.positions))

    def step(self):
        now = self.now()
        self.marks = self.api.mark_prices(self.mark_symbols())
        self.broker.tick(self.marks)
        if now - self.filters_loaded_at > 6 * 3600:
            self.load_filters()
        eq = self.broker.equity()
        self.flow_watch(now, eq)  # outside money is taken out before anything below looks at the balance
        self.track_equity(now, eq)
        self.reconcile()
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        cur_open = int(now // tf) * tf
        last_closed_ms = (cur_open - tf) * 1000
        if last_closed_ms > int(self.state.get("last_candle") or 0) and now - cur_open >= 5:
            self.state["last_candle"] = last_closed_ms
            self.on_candle(now, allow_entries=(now - cur_open) <= 600)
            # "judged": every symbol gets ONE look at entries per candle, whatever refreshes the data later
            self.candle_retry = {"candle": last_closed_ms, "next": now + 30, "judged": self.fresh_symbols()}
        elif self.candle_retry:
            self.retry_candle(now, cur_open)
        self.spot_step(now)
        if self.state.get("hist_day") != utc_day(now):
            self.record_daily(now)  # one total-equity row per UTC day, with or without the spot sleeve
        self.briefs(now)
        self.monthly(now)
        self.save()

    def retry_candle(self, now, cur_open):
        """A candle close is judged once. Symbols whose candle was missing then (failed or late klines) get
        another look every 30 s for the rest of the 10-minute entry window instead of waiting a whole candle."""
        r = self.candle_retry
        stale = [s for s in self.stale_symbols() if s not in r["judged"]] \
            if r["candle"] == int(self.state.get("last_candle") or 0) else []
        if not stale:
            self.candle_retry = None
        elif now - cur_open > 600:
            self.candle_retry = None
            self.alert("stale_candle", f"⚠️ {', '.join(short(x) for x in stale)}: 캔들 데이터를 받지 못해 이번 "
                       f"{self.cfg['signal_tf']} 봉 판단을 건너뜁니다. 보유 포지션의 거래소 손절은 그대로 유지됩니다.",
                       every=6 * 3600)
        elif now >= r["next"]:
            r["next"] = now + 30
            self.on_candle(now, allow_entries=True, only=set(stale))
            r["judged"] |= self.fresh_symbols() & set(stale)

    def stats_equity(self, equity):
        """Futures equity as the performance figures know it: without a wallet change that is still being judged
        (flow_pass). Peaks, drawdown and the day's starting balance use this view."""
        return float(equity) - self.fut_gap()

    def guard_equity(self, equity):
        """Futures equity for the equity floor: the lower of the real balance and the judged one. A drop that may be
        a withdrawal or a loss reaches the floor at once; a rise is only believed once it is judged — also when a
        loss came after it (the largest rise since the last finished look is left out)."""
        rise = float((self.state.get("flow_fut") or {}).get("rise") or 0.0) if self.flow_on() else 0.0
        return float(equity) - max(self.fut_gap(), rise, 0.0)

    def note_equity(self, eq):
        self.state["equity"], self.state["available"] = eq["equity"], eq["available"]
        if eq.get("wallet") is not None:
            self.state["wallet"] = float(eq["wallet"])

    def track_equity(self, now, eq=None):
        eq = eq or self.broker.equity()
        self.note_equity(eq)
        e = self.stats_equity(eq["equity"])
        g = self.guard_equity(eq["equity"])
        L = self.ledger
        if L is None:
            self.state["ledger"] = L = R.new_ledger(e, now)
        R.roll_day(L, now, e)
        if e > 0:  # a wallet that started empty (money arrived later by transfer): guards need a real baseline
            if float(L.get("start_equity") or 0) <= 0:
                L["start_equity"] = L["peak_equity"] = e
            if float(L.get("day_start_equity") or 0) <= 0:
                L["day_start_equity"] = e
        L["peak_equity"] = max(float(L.get("peak_equity") or e), e)
        if L["peak_equity"] > 0:
            dd = (e - L["peak_equity"]) / L["peak_equity"] * 100.0
            self.state["max_dd"] = min(float(self.state.get("max_dd") or 0.0), dd)
        floor = float(L.get("start_equity", 0)) * float(self.cfg["equity_floor_pct"]) / 100.0
        if g < floor and not self.state.get("floor_alerted") and not self.state.get("pending_transfer"):
            self.state["floor_alerted"] = True
            gap = self.fut_gap()
            how = ("전략을 점검한 뒤 /rebase (현재 잔고를 새 기준으로) 로 해제하세요." if gap > -1.0 else
                   f"선물 지갑의 {usd(gap)} 변화를 아직 확인하는 중입니다. 출금이었다면 확인되는 대로 기준이 조정되고 "
                   "신규 진입도 다시 열립니다.")
            self.send(f"🛑 자본 바닥선 도달 — 잔고 {usd(g, False)} < 바닥선 {usd(floor, False)}\n"
                      f"신규 진입을 멈췄습니다. 보유 포지션은 손절이 걸린 채 유지됩니다.\n{how}")
            self.event("GUARD", code="EQUITY_FLOOR", equity=g)
        return eq

    # ------------------------------------------------------------ spot sleeve & allocation
    def spot_startup(self):
        """(Re)build the spot sleeve from scratch for the CURRENT mode. Failures never stop the futures sleeve."""
        self.spot_ready = False
        self.spot = None
        if not self.cfg.get("spot_enabled", True):
            return False
        self.spot_next_try = self.now() + 600
        try:
            api = self.spot_api_or_new()
            if self.state["mode"] == "live":
                api.sync_time()
            mgr = SpotManager(self.cfg, self.store, api, self.spot_public_factory(), self.log,
                              self.send, self.state.setdefault("spot", {}), clock=self.clock, sleep=self.sleep,
                              persist=self.save)
            mgr.load_filters()
            if not mgr.tradable():
                raise RuntimeError("현물 종목 정보를 받지 못했습니다")
            mgr.make_ex(self.state["mode"])
            mgr.value(refresh=True)
        except Exception as e:  # noqa: BLE001 — anything here must not stop the futures sleeve
            self.log.warning("spot startup: %s", e)
            hint = ""
            if isinstance(e, BinanceError) and e.code == -2015:
                hint = "\nAPI 키에 'Enable Spot & Margin Trading' 권한과 서버 IP 등록이 필요합니다."
            self.alert("spot_start", f"⚠️ 현물 모듈 시작 실패: {e}{hint}\n선물 매매는 정상 진행합니다. 10분마다 재시도.",
                       every=6 * 3600)
            return False
        self.spot = mgr
        self.spot_ready = True
        return True

    def spot_mode_ok(self):
        return self.spot is not None and self.spot.ex is not None and self.spot.ex.name == self.state["mode"]

    def spot_step(self, now):
        if not self.cfg.get("spot_enabled", True) or getattr(self, "spot_busy", False):
            return
        if self.spot_ready and not self.spot_mode_ok():
            self.spot_ready = False  # never let a paper bot hold a live back-end, or the reverse
            self.spot_next_try = 0.0
        if not self.spot_ready:
            if now >= self.spot_next_try:
                self.spot_startup()
            if not self.spot_ready:
                return
        try:
            self.resolve_pending_transfer(now)
            if self.spot.due(now):
                self.daily_spot(now)
            else:
                self.spot.value()  # cached; refreshes at most every 10 minutes
            self.track_total(now)
        except Exception as e:  # spot problems must never stop futures risk management
            st = self.state["spot"]
            st["fails"] = int(st.get("fails", 0)) + 1
            st["retry_at"] = now + 600
            self.log.error("spot step failed: %s\n%s", e, traceback.format_exc())
            self.event("ERROR", where="spot", msg=str(e)[:300])
            if st["fails"] >= 3:
                self.alert("spot_fail", f"⚠️ 현물 리밸런싱 실패 {st['fails']}회: {e}\n10분 뒤 다시 시도합니다.", every=6 * 3600)
            if st["fails"] % 6 == 0:  # an hour of failures: rebuild the sleeve (fresh filters, fresh clients)
                self.spot_ready = False
                self.spot_next_try = now + 600

    def alloc_plan(self, now):
        """Signed USDT amount to move: + = spot -> futures, - = futures -> spot (0 = inside the band)."""
        spot_eq = self.spot.value(refresh=True)["equity"]
        fut = self.broker.equity()
        total = spot_eq + fut["equity"]
        if total <= 2:
            return 0.0
        target = float(self.cfg.get("alloc_spot_pct", 50)) / 100.0
        drift = spot_eq / total - target
        band = float(self.cfg.get("alloc_band_pct", 10)) / 100.0
        if datetime.fromtimestamp(now, timezone.utc).day == 1:
            band = min(band, 0.02)  # monthly: pull back close to the target
        if self.state.get("force_alloc"):
            band = 0.005  # the user just changed the target
        if abs(drift) < band:
            return 0.0
        amt = drift * total
        if amt < 0:  # futures -> spot: only free margin can move
            amt = -min(-amt, max(fut["available"] - 1.0, 0.0))
        if abs(amt) < max(1.0, total * 0.003):
            return 0.0
        return amt

    def transfer(self, amount, to_futures, why="배분 조정"):
        """Move USDT between the spot and futures wallets. Returns the amount moved (0 on failure / not yet known)."""
        amount = math.floor(max(amount, 0.0) * 100) / 100
        if amount < 1.0:
            return 0.0
        if not self.spot_mode_ok():
            raise RuntimeError("현물 모듈과 모드가 맞지 않아 이체를 멈췄습니다")
        before = self.broker.equity()
        fut_before = before["equity"]
        if self.state["mode"] != "live":
            self.broker.adjust_balance(amount if to_futures else -amount)
            self.spot.ex.adjust_usdt(-amount if to_futures else amount)
            self._book_transfer(amount, to_futures, fut_before, why, wallet_before=before.get("wallet"))
            return amount
        t0 = self.server_ms()
        try:
            self.spot.ex.transfer(to_futures, amount)
        except (BinanceError, NetworkError) as e:
            if isinstance(e, BinanceError) and (e.status or 0) < 500:
                self.event("ERROR", where="transfer", msg=str(e)[:300])
                self.alert("transfer", f"⚠️ 현물↔선물 자동 이체 실패: {e}\n"
                           "API 키에 '범용 이체(Permits Universal Transfer)' 권한이 있는지 확인하세요. "
                           "없으면 비율 조정만 멈추고 두 전략은 각자 지갑에서 계속 운용됩니다.", every=86400)
                return 0.0
            # outcome unknown: ask the transfer history, then look at the futures wallet itself
            ok = self.confirm_transfer(amount, to_futures, t0)
            if ok is not True and self.wallet_moved(before.get("wallet"), amount, to_futures):
                ok = True
            if ok is None:
                self.state["pending_transfer"] = {"amount": amount, "to_futures": to_futures, "t0": t0,
                                                  "fut_before": fut_before, "wallet_before": before.get("wallet"),
                                                  "why": why, "until": self.now() + 3600}
                self.save()
                self.alert("transfer_pending", f"⏳ 이체 응답이 없어({e}) 결과를 확인하는 중입니다. 확인 전까지 배분 조정을 멈춥니다.",
                           every=3600)
                return 0.0
            if not ok:
                self.event("ERROR", where="transfer", msg=f"not executed: {e}"[:300])
                return 0.0
        self._book_transfer(amount, to_futures, fut_before, why, t0, wallet_before=before.get("wallet"))
        return amount

    def server_ms(self):
        """Binance server time (transfer and income history are filtered and stamped in it, not in our clock). The
        futures client is synced at start-up and on every timestamp error; spot and futures share one clock."""
        off = getattr(self.api, "time_offset_ms", None)
        if off is None:
            off = getattr(self.spot_api_or_new(), "time_offset_ms", 0.0)
        return int(self.now_ms() + float(off or 0.0))

    def wallet_moved(self, wallet_before, amount, to_futures):
        """True if the futures wallet balance changed by about the transfer amount, in the right direction."""
        if wallet_before is None:
            return False
        for _ in range(2):
            try:
                now_w = self.broker.equity()["wallet"]
                break
            except (BinanceError, NetworkError):
                self.sleep(2.0)
        else:
            return False
        delta = now_w - float(wallet_before)
        expect = amount if to_futures else -amount
        return abs(delta - expect) <= max(0.3, abs(amount) * 0.05)

    def confirm_transfer(self, amount, to_futures, t0):
        """True / False from Binance's transfer history, None while it cannot be told."""
        kind = "MAIN_UMFUTURE" if to_futures else "UMFUTURE_MAIN"
        for _ in range(3):
            try:
                rows = self.spot_api_or_new().transfer_history(kind, start_ms=t0 - 60_000, retries=0)
                break
            except (BinanceError, NetworkError):
                self.sleep(2.0)
        else:
            return None
        for r in rows:
            if abs(float(r.get("amount") or 0) - amount) < 0.011 and int(r.get("timestamp") or 0) >= t0 - 60_000:
                st = str(r.get("status") or "").upper()
                if st == "CONFIRMED":
                    return True
                if st == "FAILED":
                    return False
                return None
        return None if self.server_ms() - t0 < 600_000 else False

    def resolve_pending_transfer(self, now):
        p = self.state.get("pending_transfer")
        if not p:
            return
        ok = self.confirm_transfer(p["amount"], p["to_futures"], p["t0"])
        if ok is not True and self.wallet_moved(p.get("wallet_before"), p["amount"], p["to_futures"]):
            ok = True
        if ok is None and now < float(p.get("until") or 0):
            return
        self.state["pending_transfer"] = None
        if ok:
            self._book_transfer(p["amount"], p["to_futures"], p["fut_before"], p.get("why", "배분 조정"), p.get("t0"),
                                late=True, wallet_before=p.get("wallet_before"))
            self.send(f"✅ 확인 중이던 이체가 처리됐습니다: {'현물→선물' if p['to_futures'] else '선물→현물'} "
                      f"{usd(p['amount'], False)}")
        else:
            self.send("ℹ️ 확인 중이던 이체는 실행되지 않은 것으로 판단했습니다(이체 기록·선물 지갑 모두 변화 없음). "
                      "다음 점검 때 다시 맞춥니다. 잔고가 이상해 보이면 /rebase 로 기준점을 다시 잡으세요.")
        self.save()
        # what the wallets did while the answer was open is judged now (a transfer that did go through after all
        # shows up as money that changed wallets, and is booked as that)
        self.flow_watch(now, force=True)

    def _scale_ledger(self, fut_before, fut_after):
        """Money moved into or out of the futures wallet (the bot's own transfer, or from outside): scale the
        guard baselines so the floor, the daily limit and the drawdown keep measuring trading, not the transfer.
        Returns the factor used, or None when the baselines were set afresh (the wallet was or is now empty)."""
        L = self.ledger
        if L is None:
            return None
        k = None
        if fut_before > 0 and fut_after > 0:
            k = fut_after / fut_before
            for key in LEDGER_BASES:
                L[key] = float(L.get(key) or 0.0) * k
        elif fut_after <= 0 < fut_before:  # the wallet was emptied: nothing left to guard until money comes back
            L["start_equity"] = L["peak_equity"] = L["day_start_equity"] = 0.0
        if float(L.get("start_equity") or 0) <= 0 < fut_after:
            L["start_equity"] = L["peak_equity"] = L["day_start_equity"] = fut_after
            k = None
        floor = float(L.get("start_equity") or 0) * float(self.cfg["equity_floor_pct"]) / 100.0
        if self.state.get("floor_alerted") and fut_after >= floor:
            self.state["floor_alerted"] = False  # the alert came from an unscaled baseline
        return k

    def _book_transfer(self, amount, to_futures, fut_before, why, t0=None, late=False, wallet_before=None):
        """fut_before / wallet_before: the futures balance read just before the transfer was sent. late: it was
        confirmed some time after that (the balances read since then already contain it)."""
        signed = amount if to_futures else -amount
        F = self.state.setdefault("flow_fut", {})
        if self.flow_on() and F.get("seen") is not None:  # the guard baselines know the judged balance only
            fb = fut_before - ((float(wallet_before) - float(F["seen"])) if wallet_before is not None else self.fut_gap())
        else:
            fb = fut_before
        self._scale_ledger(fb, fb + signed)
        st = self.state["spot"]
        st["net_in"] = float(st.get("net_in") or 0.0) - signed
        if self.state["mode"] == "live" and F.get("seen") is not None:
            # the bot's own move: neither wallet may report it as outside money (flow_pass)
            F["seen"] = float(F["seen"]) + signed
            F.setdefault("own", []).append({"ms": int(t0 or self.server_ms()), "amt": signed})
        if self.spot is not None:
            self.spot.expect({"USDT": -signed})
        if not late:
            self.state["equity"] = fut_before + signed
            if wallet_before is not None:
                self.state["wallet"] = float(wallet_before) + signed
        rec = {"ts": self.now(), "mode": self.state["mode"], "to": "futures" if to_futures else "spot",
               "amount": amount, "why": why}
        self.store.append("transfers.jsonl", rec)
        self.event("TRANSFER", msg=f"{'현물→선물' if to_futures else '선물→현물'} {amount:.2f}")
        self.save()

    # ------------------------------------------------------------ outside money (deposits / withdrawals)
    def flow_on(self):
        return self.state["mode"] == "live" and bool(self.cfg.get("flow_detect", True))

    def total_tracked(self):
        return bool(self.cfg.get("spot_enabled", True)) and self.spot_ready and self.spot is not None

    def unbooked(self):
        """Money in the wallets that the performance baselines do not know yet: seen, not judged (flow_pass)."""
        acc = float(self.spot.state.get("flow_acc") or 0.0) if self.total_tracked() else 0.0
        return self.fut_gap() + acc

    def flow_watch(self, now, eq=None, force=False):
        """flow_pass, but trouble in it never stops trading: it is reported and the look is repeated."""
        try:
            return self.flow_pass(now, eq, force)
        except Exception as e:  # noqa: BLE001
            F = self.state.setdefault("flow_fut", {})
            F["blocked"], F["retry"] = F.get("blocked") or now, now + 300  # tried again every five minutes
            self.log.error("flow pass failed: %s\n%s", e, traceback.format_exc())
            self.event("ERROR", where="flow", msg=str(e)[:300])
            self.alert("flow_err", f"⚠️ 입금·출금 확인 중 오류: {e}\n매매와 손절 관리는 그대로 진행합니다. "
                       "계속되면 /set flow_detect false 로 끌 수 있습니다.", every=6 * 3600)
            return "blocked"

    def flow_pass(self, now, eq=None, force=False):
        """Look for money that came in or went out from outside (a deposit, a withdrawal, a transfer made by hand
        in the app) and take it out of every performance baseline. Live mode only; called at every step.

        Futures wallet: F["seen"] is the balance the books have judged. A change since then is matched against
        Binance's income history: a transfer row that is not one of the bot's own transfers is outside money,
        every other row a trading result. Until the rows explain a change, the performance figures do not see it
        (fut_gap), while the equity floor sees the lower of the two balances (guard_equity). A change no row ever
        explains is counted as a result once a late row could no longer turn up (FLOW_RELEASE_S).
        Spot wallet: spot._scan adds up the quantity changes the bot's own orders and transfers do not explain.
        Both wallets are booked together and only with the whole picture, so money the user moved between them
        nets to zero. Returns 'off', 'idle', 'none', 'booked', 'wait' (rows pending), 'unread' (the history could not
        be read but nothing was waiting to be judged) or 'blocked'."""
        F = self.state.setdefault("flow_fut", {})
        if not self.flow_on():
            return "off"
        if eq is None:
            eq = self.broker.equity()
        self.note_equity(eq)
        w = float(eq["wallet"])
        if F.get("seen") is None or not F.get("ts"):  # first look: watch from now on
            F.update(ts=self.server_ms(), own=[], ids=[], seen=w, since=None, checked=now, blocked=None, rise=0.0)
            return "idle"
        gap = w - float(F["seen"])
        F["rise"] = max(float(F.get("rise") or 0.0), gap)  # the floor never counts on a rise not yet judged
        big = abs(gap) >= self._flow_big(eq)
        spot_on = bool(self.cfg.get("spot_enabled", True))
        sp = self.spot if spot_on and self.spot_ready and self.spot_mode_ok() else None
        if big and not F.get("since"):
            F["since"] = now
        if F.get("blocked") and not force and now < float(F.get("retry") or 0.0):
            return "blocked"  # between two tries
        stale = sp is not None and (not sp.cache or now - sp.cache_ts >= FLOW_EVERY_S - 1)
        spot_saw = sp is not None and abs(float(sp.state.get("flow_acc") or 0.0)) >= 0.005
        if not (force or big or stale or spot_saw or F.get("since") or F.get("blocked")
                or now - float(F.get("checked") or 0.0) >= FLOW_EVERY_S):
            return "idle"  # fees, funding, small results: judged at the regular look
        # 1. nothing is judged while a transfer of the bot is unconfirmed or the self-test is moving money
        if self.state.get("pending_transfer"):
            return self._flow_blocked(F, now, sp, "확인 중인 봇 이체가 끝나지 않음")
        if getattr(self, "spot_busy", False):
            return self._flow_blocked(F, now, sp, "실주문 테스트 중")
        # 2. the spot wallet
        spot_err = None
        if sp is not None:
            if force or stale or big or F.get("since"):
                try:
                    sp.value(refresh=True)
                except (BinanceError, NetworkError) as e:
                    self.log.warning("flow pass: spot balances: %s", e)
                    spot_err = "현물 잔고 조회 실패"
            if sp.state.get("flow_defer"):  # Earn could not be read while the wallet's USDT moved
                spot_err = spot_err or "이자 예치 잔고 조회 실패"
        acc = float(sp.state.get("flow_acc") or 0.0) if sp is not None else 0.0
        floor = self._flow_floor()
        # 3. the futures wallet: what do the income rows say?
        inc = self.futures_income(F)
        if inc is None:
            start = F.get("since") or (F.get("blocked") if abs(acc) >= floor else None)
            if start and now - float(start) >= FLOW_GIVE_UP_S:
                self._flow_give_up(F, now, w, gap)
                ext = 0.0
            elif not F.get("since") and abs(acc) < floor and not spot_err:
                F["checked"] = now
                return "unread"  # nothing was waiting to be judged; the rows are read at the next look
            else:
                return self._flow_blocked(F, now, sp, "바이낸스 선물 기록 조회 실패")
        else:
            ext, other, own, ids, mark = inc
            resid = gap - ext - other
            released = False
            if abs(resid) >= self._flow_big(eq):  # the rows do not (yet) explain the change
                F["since"] = F.get("since") or now
                if now - float(F["since"]) < FLOW_RELEASE_S:
                    return "wait"  # rows can show up late: the same rows are read again at the next step
                self.event("FLOW", msg=f"futures wallet change {resid:+.2f} without income rows: counted as a result")
                released = True
            if abs(ext) >= 0.005 and (spot_err or (spot_on and sp is None)):
                # outside money on the futures side; the other wallet has to be seen too (the rows are read again)
                return self._flow_blocked(F, now, sp, spot_err or "현물 모듈 준비 중")
            if released:  # all of the wallet up to now is judged: a row of that time that turns up later is skipped
                mark, ids = max(mark, self.server_ms()), []
            if F.get("gave_up") and self.state.get("floor_alerted"):
                self.send("ℹ️ 바이낸스 선물 기록을 다시 읽을 수 있습니다. 기록을 못 읽던 동안 선물 지갑에서 넣거나 뺀 돈이 "
                          "있었다면 /deposit 금액 선물 · /withdraw 금액 선물 로 적어 주세요(자본 바닥선 기준이 바로잡힙니다).")
            F.update(ts=mark, own=own, ids=ids, seen=w, since=None, checked=now, blocked=None, rise=0.0, gave_up=None)
        if spot_err:  # the futures side is judged; the spot wallet waits for the next try
            return self._flow_blocked(F, now, sp, spot_err)
        # 4. the whole picture is there
        F["blocked"] = None
        unsure = 0.0
        if sp is not None:
            unsure = float(sp.state.get("flow_unsure") or 0.0)
            sp.state["flow_acc"], sp.state["flow_unsure"] = 0.0, 0.0
        spot_flow = acc if abs(acc) >= max(floor, unsure * 0.003) else 0.0
        fut_flow = ext if abs(ext) >= floor else 0.0
        if not spot_flow and not fut_flow:
            return "none"
        self.book_flow(now, spot_flow, fut_flow)
        return "booked"

    def _flow_big(self, eq):
        """A change of the futures wallet that is too big to be fees or funding."""
        return max(1.0, abs(float(eq["equity"])) * 0.002)

    def _flow_floor(self):
        """Below this a flow is interest, dust or rounding and not booked."""
        return max(1.0, self.total_equity()[0] * 0.001)

    def _flow_blocked(self, F, now, sp, why):
        """This look could not be finished: nothing is booked and the figures keep their pre-change view. Tried
        again in a minute; after ten minutes with something waiting, the user is told."""
        F["blocked"] = F.get("blocked") or now
        F["retry"] = now + 60
        acc = float(sp.state.get("flow_acc") or 0.0) if sp is not None else 0.0
        if now - float(F["blocked"]) >= 600 and (F.get("since") or abs(acc) >= 1.0):
            self.alert("flow_blocked", f"⚠️ 입금·출금 확인이 {int((now - F['blocked']) / 60)}분째 밀려 있습니다({why}). "
                       "확인되면 자동으로 반영합니다. 그동안 현물↔선물 자동 이체는 쉬고, 매매·손절 관리·자본 바닥선은 "
                       "그대로 작동합니다.", every=6 * 3600)
        return "blocked"

    def _flow_give_up(self, F, now, w, gap):
        """The income history stayed unreadable for a day: what the futures wallet did meanwhile counts as results
        from here on. The bookmark moves to now, so rows of that time can never be booked twice later."""
        rise = float(F.get("rise") or 0.0)
        F.update(ts=self.server_ms(), own=[], ids=[], seen=w, since=None, checked=now, blocked=None, rise=0.0,
                 gave_up=now)
        self.event("FLOW", msg=f"income history unreadable for a day: futures change {gap:+.2f} counted as results")
        if abs(gap) >= 1.0 or rise >= 1.0:
            most = f" (가장 컸을 때 {usd(rise)})" if rise >= gap + 1.0 else ""
            self.send(f"⚠️ 하루 동안 바이낸스 선물 손익 기록을 읽지 못해, 그동안 설명하지 못한 선물 지갑 변화 {usd(gap)}{most}를 "
                      "매매 결과로 처리했습니다.\n그사이 선물 지갑에 직접 넣거나 뺀 돈이 있었다면 "
                      "/deposit 금액 선물 · /withdraw 금액 선물 로 적어 주세요. 지금 바로 적을 수 있고, 자본 바닥선 기준도 "
                      "그에 맞춰 바로잡힙니다.")

    def fut_gap(self):
        """What the futures wallet did since the balance the books judged last (flow_pass)."""
        if not self.flow_on():
            return 0.0
        F = self.state.get("flow_fut") or {}
        w = self.state.get("wallet")
        if F.get("seen") is None or w is None:
            return 0.0
        return float(w) - float(F["seen"])

    def held(self):
        """A change of the futures wallet that is waiting to be judged (0 when there is none)."""
        return self.fut_gap() if (self.state.get("flow_fut") or {}).get("since") else 0.0

    def futures_income(self, F):
        """Income rows of the futures wallet since the last look: (outside transfers, other USDT income, the bot's
        own transfers still waiting for their row, row ids seen, new bookmark). None if the history is unreadable.
        A transfer row is outside money unless it is one of the bot's own transfers (same direction and amount)."""
        now_ms = self.server_ms()
        since = max(int(F["ts"]), now_ms - 85 * 86_400_000)  # Binance keeps about three months
        rows = []
        try:
            for a, b in _chunks(since + 1, now_ms + 5000):
                start = a
                for _ in range(20):  # 1000 rows per call
                    part = self.api.income(start_time=start, end_time=b, limit=1000, retries=1)
                    rows.extend(part)
                    if len(part) < 1000:
                        break
                    start = max(int(r.get("time") or 0) for r in part)
        except (BinanceError, NetworkError) as e:
            self.log.warning("futures income history: %s", e)
            return None
        done = set(F.get("ids") or [])
        own = [dict(o) for o in (F.get("own") or [])]
        ext = other = 0.0
        keep = {}
        for r in sorted(rows, key=lambda r: int(r.get("time") or 0)):
            t_ms = int(r.get("time") or 0)
            key = f"{r.get('tranId')}:{r.get('incomeType')}:{t_ms}:{r.get('income')}:{r.get('symbol') or ''}"
            if t_ms <= since or key in keep:
                continue
            keep[key] = t_ms
            if key in done or r.get("asset", "USDT") != "USDT":
                continue
            try:
                amt = float(r.get("income") or 0.0)
            except (TypeError, ValueError):  # one unreadable row must not stop the look for good
                self.log.warning("futures income row skipped: %r", r)
                continue
            if r.get("incomeType") not in FLOW_TYPES:
                other += amt
                continue
            mine = next((o for o in own if (o["amt"] > 0) == (amt > 0) and abs(abs(o["amt"]) - abs(amt)) < 0.011
                         and abs(int(o["ms"]) - t_ms) <= FLOW_SPAN_MS), None)
            if mine:
                own.remove(mine)
            else:
                ext += amt
        mark = max(since, now_ms - FLOW_BACK_MS)  # trail behind: a row that shows up late is still read
        own = [o for o in own if int(o["ms"]) + FLOW_SPAN_MS > mark]  # its row can no longer turn up
        return ext, other, own, [k for k, t in keep.items() if t > mark], mark

    def _new_base(self, tot, now):
        """Measure the total from `tot` on. The unit price carries on from where it stood, so the monthly report
        stays continuous across /rebase and across a wallet that was emptied and filled again."""
        if self.state.get("nav_last"):
            self.state["nav_k"] = self.state["nav_last"]
        self.state["total"] = {"base": tot, "since": now, "peak": tot, "mdd": 0.0, "last": tot, "net_flow": 0.0}
        return self.state["total"]

    def nav(self, view):
        """Unit price of the account: total equity with every deposit and withdrawal taken out."""
        base = float((self.state.get("total") or {}).get("base") or 0.0)
        if base <= 0 or view <= 0:
            return None
        return float(self.state.get("nav_k") or 1.0) * view / base

    def book_flow(self, now, spot_flow, fut_flow, source="auto"):
        """Outside money reached (+) or left (-) the wallets: take it out of every performance baseline, so
        return and drawdown keep measuring the trading. The wallets' current values must already include it."""
        raw, sv, fv = self.total_equity()
        tot, fv = raw - self.unbooked(), self.stats_equity(fv)  # the judged view (all of it, right after a look)
        net = spot_flow + fut_flow
        if spot_flow and fut_flow and abs(net) < max(1.0, tot * 0.001):
            net = 0.0  # the same money changed wallets: a few cents of difference are not a deposit
        T = self.state.setdefault("total", {})
        st = self.state["spot"]
        L = self.ledger or {}
        prev = {"T": dict(T), "L": {key: L.get(key) for key in LEDGER_BASES}, "nav_k": self.state.get("nav_k")}
        k = 1.0
        if abs(net) >= 0.005 and self.total_tracked():
            before = tot - net
            if float(T.get("base") or 0) > 0 and before > 0 and tot > 0:
                k = tot / before
                T["base"] = float(T["base"]) * k
                T["peak"] = max(float(T.get("peak") or before) * k, tot)
                T["net_flow"] = float(T.get("net_flow") or 0.0) + net
                T["last"] = tot
            elif tot > 0:  # nothing was there before: this money is the starting point
                k = None
                self._new_base(tot, now)
            else:  # everything was taken out: there is nothing left to measure until money comes back
                k = None
                T.update(base=0.0, peak=0.0, last=0.0)
        if abs(net) >= 0.005:
            self.state["force_alloc"] = True  # split the new money (or the gap) at the next daily check
        if spot_flow:
            st["net_in"] = float(st.get("net_in") or 0.0) + spot_flow
        floor_was = bool(self.state.get("floor_alerted"))
        kf = self._scale_ledger(fv - fut_flow, fv) if fut_flow else 1.0
        rec = {"ts": now, "mode": self.state["mode"], "spot": round(spot_flow, 2), "fut": round(fut_flow, 2),
               "net": round(net, 2) + 0.0, "total": round(tot, 2), "src": source}
        self.store.append("flows.jsonl", rec)
        self.state["last_flow"] = dict(rec, k=k, kf=kf, prev=prev)
        self.event("FLOW", msg=f"{net:+.2f} (현물 {spot_flow:+.2f}, 선물 {fut_flow:+.2f}, {source})")
        self.save()
        text = self.flow_text(rec)
        if floor_was and not self.state.get("floor_alerted"):
            text += "\n자본 바닥선 경고는 손실이 아니라 옮긴 돈 때문이었습니다. 기준을 조정했고 신규 진입을 다시 허용합니다."
        self.send(text)
        return rec

    def flow_text(self, rec):
        net, sp, fu = rec["net"], rec["spot"], rec["fut"]
        if abs(net) < 0.005:  # the same money changed wallets (moved by hand in the app, or a late transfer)
            return (f"↔️ 현물↔선물 지갑 사이를 오간 돈을 반영했습니다: 현물 {usd(sp)}, 선물 {usd(fu)}.\n"
                    "총자산은 그대로라 수익률 계산은 바뀌지 않습니다. 배분은 다음 09:05 KST 점검 때 다시 봅니다.")
        kind = "입금" if net > 0 else "출금"
        where = " · ".join(x for x in (f"현물 {usd(sp)}" if sp else "", f"선물 {usd(fu)}" if fu else "") if x)
        auto = rec.get("src") == "auto"
        lines = [f"💵 {kind} {'감지' if auto else '기록'} — {usd(abs(net), False)} ({where})",
                 f"수익률·최대낙폭은 이 금액을 {kind}으로 빼고 계산합니다. 배분은 다음 09:05 KST 점검 때 목표 비율로 맞춥니다."]
        if auto:
            lines.append(f"{kind}이 아니라면 /flows undo 로 취소할 수 있습니다.")
        return "\n".join(lines)

    def flow_waiting(self):
        """Money seen in the wallets and still waiting to be judged (a held futures change, unbooked spot changes)."""
        if not self.flow_on():
            return 0.0
        acc = float(self.state.get("spot", {}).get("flow_acc") or 0.0) if self.total_tracked() else 0.0
        return self.held() + acc

    def flow_reset(self):
        """Watch for outside money from this moment on: whatever is in the wallets now is not a flow."""
        st = self.state.setdefault("spot", {})
        st.update(snap=None, flow_acc=0.0, own_dq={}, flow_unsure=0.0, flow_defer=None)
        if self.spot is not None:
            self.spot.cache = None
        self.state["flow_fut"] = {}
        self.state.pop("flow_hold", None)  # written by an earlier build of v2.5
        self.state["last_flow"] = None

    def daily_spot(self, now):
        if not self.spot_mode_ok():
            raise RuntimeError("현물 모듈과 모드가 맞지 않습니다")
        if self.state.get("pending_transfer"):
            return  # wait until the last transfer is confirmed before moving more money
        flow = self.flow_watch(now, force=True)  # the job starts from wallets whose outside money is booked
        if flow == "wait":
            return  # income rows are still due (minutes at most); the job is still due at the next step
        self.spot.load_filters()  # cheap; also drops a delisted candidate
        if not self.spot.tradable():
            raise RuntimeError("거래 가능한 현물 종목이 없습니다(바이낸스 점검 중일 수 있음)")
        # while the wallets cannot be judged (history unreadable), coins are still rebalanced but no money moves
        amt = 0.0 if flow == "blocked" else self.alloc_plan(now)
        moved_in = moved_out = 0.0
        if amt < 0:
            moved_in = self.transfer(-amt, to_futures=False)
        res = self.spot.rebalance(now, reserve=amt if amt > 0 else 0.0)
        if amt > 0:
            cash = self.spot.value(refresh=True)["usdt_free"]
            moved_out = self.transfer(min(amt, cash * 0.999), to_futures=True)
        if flow != "blocked" and (not amt or moved_in or moved_out):
            self.state["force_alloc"] = False
        parked = self.spot.earn_park(now)  # last: only what the trades and transfers left over (never raises)
        self.record_daily(now)
        if res["trades"] or res["errors"] or moved_in or moved_out:
            lines = ["🪙 현물 리밸런싱 (일봉 마감 기준)"]
            if moved_in:
                lines.append(f"↔️ 선물 → 현물 {usd(moved_in, False)} 이체 (목표 배분 유지)")
            if moved_out:
                lines.append(f"↔️ 현물 → 선물 {usd(moved_out, False)} 이체 (목표 배분 유지)")
            if parked > 0:
                lines.append(f"💤 남는 USDT {usd(parked, False)} 이자 예치(유연)")
            elif parked < 0:
                lines.append(f"💤 이자 예치 {usd(-parked, False)} 환매(예치 기능 꺼짐)")
            for t in res["trades"]:
                lines.append(f"{'🟢 매수' if t['side'] == 'BUY' else '🔴 매도'} {short(t['sym'])} {usd(t['quote'], False)} "
                             f"(목표 {t['target_w'] * 100:.0f}%)")
            for e in res["errors"]:
                lines.append(f"⚠️ {e}")
            lines += self.spot.lines(detail=False)
            self.send("\n".join(lines), silent=True)

    def record_daily(self, now):
        try:
            sv = self.spot.value()["equity"] if self.spot_ready else 0.0
        except (BinanceError, NetworkError) as e:  # try again on the next step
            self.log.warning("daily record: %s", e)
            return
        fv = float(self.state.get("equity") or 0.0)
        day = utc_day(now)
        self.state["hist_day"] = day
        h = self.state.setdefault("hist", [])
        row = [day, round(sv, 4), round(fv, 4)]
        nav = self.nav(sv + fv - self.unbooked()) if self.total_tracked() else None
        if nav:
            row.append(round(nav, 6))  # unit price: total equity with deposits/withdrawals taken out
        if h and h[-1][0] == day:
            h[-1] = row
        else:
            h.append(row)
        del h[:-1500]

    def total_equity(self):
        fv = float(self.state.get("equity") or 0.0)
        sv = (self.spot.cache or {}).get("equity", 0.0) if self.spot_ready else 0.0
        return fv + sv, sv, fv

    def track_total(self, now):
        tot = self.total_equity()[0] - self.unbooked()  # money that is seen but not booked yet is not a result
        T = self.state.setdefault("total", {})
        if not T.get("base"):
            if tot <= 0:
                return
            T = self._new_base(tot, now)
        T["peak"] = max(float(T.get("peak") or tot), tot)
        if T["peak"] > 0:
            T["mdd"] = min(float(T.get("mdd") or 0.0), (tot - T["peak"]) / T["peak"] * 100)
        T["last"] = tot
        nav = self.nav(tot)
        if nav:
            self.state["nav_last"] = nav

    # ------------------------------------------------------------ reconcile & protection
    def reconcile(self, startup=False):
        ex = self.broker.positions()
        known = set(self.positions)  # symbols handled below must not be "adopted" in the same pass
        for sym, pos in list(self.positions.items()):
            e = ex.get(sym)
            if not e or (e["amt"] > 0) != (pos["side"] == S.LONG):
                self.finalize(sym, pos)
                continue
            qty = abs(e["amt"])
            m = self.marks.get(sym) or e["mark"]
            if qty > pos["qty"] + float(self.filters.get(sym, R.DEFAULT_FILTER)["step"]) / 2:
                # The position grew on the exchange by at least a lot step (not float noise): an add whose answer
                # was lost has landed after all, the rest of a partly filled entry arrived, or the user added in
                # the app. The exchange's average entry is the truth; ensure_stop below re-sizes the stop.
                grown = qty - pos["qty"]
                ref = m or e["entry"] or pos["entry"]
                gap = (ref - pos["stop"]) if pos["side"] == S.LONG else (pos["stop"] - ref)
                pos["risk_amt"] = float(pos.get("risk_amt") or 0.0) + grown * max(gap, 0.0)
                pos["entry"] = e["entry"] or pos["entry"]
                if pos.pop("add_pending", None):  # only the bot's own unanswered add counts as a pyramid step
                    pos["adds"] = int(pos.get("adds", 0) or 0) + 1
                    pos["last_add_px"] = ref
                    self.event("ADD", sym=sym, side=pos["side"], qty=grown, entry=ref, n=pos["adds"], late=True)
                    self.send(f"➕ {short(sym)}: 응답을 받지 못했던 추가 진입이 체결돼 있어 반영했습니다 "
                              f"(불타기 {pos['adds']}회차, 총 수량 {qty:g}). 손절을 전체 수량으로 다시 겁니다.")
                else:
                    self.alert(f"grown_{sym}", f"ℹ️ {short(sym)} 포지션 수량이 거래소에서 {pos['qty']:g} → {qty:g} 로 늘어나 "
                               "있어 반영했습니다(앱에서 추가했거나 늦은 체결). 손절을 전체 수량으로 다시 겁니다.", every=600)
            if abs(qty - pos["qty"]) > 1e-12:
                pos["qty"] = qty
            pos["mark"] = m
            pos["upnl"] = e["upnl"]
            pos["liq"] = e.get("liq", 0.0)
            if pos["liq"] > 0 and ((pos["side"] == S.LONG and pos["liq"] >= pos["stop"]) or
                                   (pos["side"] == S.SHORT and pos["liq"] <= pos["stop"])):
                self.alert(f"liq_{sym}", f"⚠️ {short(sym)}: 청산가 {px(pos['liq'])}가 손절가 {px(pos['stop'])}보다 먼저 닿는 "
                           "위치입니다. 앱에서 증거금을 추가하거나 /close 로 정리해 주세요.", every=3600)
            if m:
                pos["extreme"] = max(pos["extreme"], m) if pos["side"] == S.LONG else min(pos["extreme"], m)
            if not self.ensure_stop(sym, pos):
                continue
            breached = m and ((pos["side"] == S.LONG and m <= pos["stop"]) or
                              (pos["side"] == S.SHORT and m >= pos["stop"]))
            if breached:
                pos["breach"] = int(pos.get("breach", 0)) + 1
                if pos["breach"] >= 3:
                    self.alert(f"soft_{sym}", f"⚠️ {short(sym)}: 가격이 손절가를 넘었는데 거래소 손절이 체결되지 않아 봇이 직접 청산합니다.", every=60)
                    self.exit_position(sym, "SOFT_STOP")
                    continue
            else:
                pos["breach"] = 0
            self.maybe_trail(sym, pos)
        for sym, e in ex.items():
            if sym in self.positions or sym in known:
                continue
            if sym not in self.cfg["symbols"]:
                self.alert(f"foreign_{sym}", f"ℹ️ 봇 감시 목록 밖의 포지션({short(sym)})은 관리하지 않습니다.", every=86400)
                continue
            self.adopt(sym, e)

    def ensure_stop(self, sym, pos):
        """Make sure exactly one protective stop sits on the exchange. Returns False if the position was closed."""
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        try:
            stops = self.broker.open_stops(sym)
        except (BinanceError, NetworkError) as e:
            self.log.warning("open stops %s: %s", sym, e)
            return True
        mine = [s for s in stops if s["side"] == close_side and (s["reduce_only"] or s["close_position"])]
        ids = {s["id"] for s in mine}
        if pos.get("stop_id") in ids:
            ours = next(s for s in mine if s["id"] == pos["stop_id"])
            for s in mine:
                if s["id"] != pos["stop_id"]:
                    self.broker.cancel_stop(sym, s["id"])
            if not ours["close_position"] and abs(ours["qty"] - pos["qty"]) > 1e-9:
                if not self.replace_stop(sym, pos, pos["stop"], resize=True) and sym in self.positions \
                        and not pos.get("exit_reason"):
                    self.alert(f"resize_{sym}", f"⚠️ {short(sym)}: 손절 주문 수량({ours['qty']:g})을 포지션 수량"
                               f"({pos['qty']:g})에 맞추지 못했습니다. 20초마다 다시 시도합니다. 앱에서도 확인해 주세요.",
                               every=600)
            return True
        if mine:
            # adopt the most protective stop that already exists, drop the rest
            if pos["side"] == S.LONG:
                best = max(mine, key=lambda s: s["trigger"])
                take = best["trigger"] >= pos["stop"]
            else:
                best = min(mine, key=lambda s: s["trigger"])
                take = best["trigger"] <= pos["stop"]
            for s in mine:
                if s["id"] != best["id"] or not take:
                    self.broker.cancel_stop(sym, s["id"])
            if take:
                pos["stop_id"] = best["id"]
                pos["stop"] = best["trigger"]
                self.save()
                return True
        if pos.get("stop_id"):
            self.alert(f"stop_gone_{sym}", f"⚠️ {short(sym)} 손절 주문이 거래소에서 사라져 다시 걸었습니다.", every=600)
        return self.place_stop_safe(sym, pos)

    def place_stop_safe(self, sym, pos, trigger=None):
        trigger = pos["stop"] if trigger is None else trigger
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        last = None
        for attempt in range(3):
            try:
                sid = self.broker.place_stop(sym, close_side, pos["qty"], trigger)
                pos.update(stop_id=sid, stop=trigger, stop_set_ms=self.now_ms())
                self.save()
                return True
            except BinanceError as e:
                last = e
                if e.code == -2021:  # would immediately trigger: price is already through the stop
                    self.exit_position(sym, "STOP_NOW")
                    return False
            except NetworkError as e:
                last = e
                try:
                    for s in self.broker.open_stops(sym):
                        if s["side"] == close_side and abs(s["trigger"] - trigger) <= abs(trigger) * 1e-6 + 1e-12:
                            pos.update(stop_id=s["id"], stop=trigger, stop_set_ms=self.now_ms())
                            self.save()
                            return True
                except Exception:
                    pass
            self.sleep(1.0)
        self.send(f"🚨 {short(sym)} 손절 주문을 걸지 못했습니다({last}). 안전을 위해 즉시 청산합니다.")
        self.event("ERROR", where="place_stop", sym=sym, msg=str(last))
        self.exit_position(sym, "NO_STOP")
        return False

    def replace_stop(self, sym, pos, new_trigger, note=True, resize=False):
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        old_id, old_stop = pos.get("stop_id"), pos["stop"]
        try:
            sid = self.broker.place_stop(sym, close_side, pos["qty"], new_trigger)
        except BinanceError as e:
            if e.code == -2021:
                self.exit_position(sym, "TRAIL")
            else:
                self.log.warning("replace stop %s: %s", sym, e)
                self.event("ERROR", where="replace_stop", sym=sym, msg=str(e))
            return False
        except NetworkError as e:
            self.log.warning("replace stop %s: %s", sym, e)
            return False
        pos.update(stop_id=sid, stop=new_trigger, stop_set_ms=self.now_ms())
        if old_id and old_id != sid:
            self.broker.cancel_stop(sym, old_id)
        self.save()
        if resize:  # same trigger, new quantity (after an add-on)
            return True
        self.event("TRAIL", sym=sym, old=old_stop, new=new_trigger)
        locked = (pos["side"] == S.LONG and new_trigger > pos["entry"]) or \
                 (pos["side"] == S.SHORT and new_trigger < pos["entry"])
        if note and locked and not pos.get("locked_notified"):
            pos["locked_notified"] = True
            gain = abs(new_trigger - pos["entry"]) * pos["qty"]
            self.send(f"🔒 {short(sym)} {SIDE_KO[pos['side']]}: 손절을 수익 구간 {px(new_trigger)}로 올렸습니다 "
                      f"(최소 {usd(gain)} 확보, 수수료 전).", silent=True)
        return True

    def maybe_trail(self, sym, pos, force=False):
        atr_v = pos.get("atr_now") or pos.get("atr")
        if not atr_v:
            return
        f = self.filters.get(sym, R.DEFAULT_FILTER)
        cand = S.trail_stop(pos["side"], pos["entry"], pos["r_dist"], pos["stop"], pos["extreme"], atr_v, self.cfg)
        cand = R.round_step(cand, f["tick"])
        improve = (cand - pos["stop"]) if pos["side"] == S.LONG else (pos["stop"] - cand)
        min_step = max(float(self.cfg["trail_min_step_atr"]) * atr_v, float(f["tick"]))
        if improve < min_step:
            return
        if not force and self.now_ms() - int(pos.get("stop_set_ms") or 0) < 300_000:
            return
        m = self.marks.get(sym)
        if m and ((pos["side"] == S.LONG and m <= cand) or (pos["side"] == S.SHORT and m >= cand)):
            self.exit_position(sym, "TRAIL")
            return
        self.replace_stop(sym, pos, cand)

    # ------------------------------------------------------------ candle close
    def on_candle(self, now, allow_entries=True, only=None):
        self.refresh_data(only)
        for sym, pos in list(self.positions.items()):
            d = self.data.get(sym)
            if not d or (only is not None and sym not in only):
                continue
            ind = d["ind"]
            i = len(ind["c"]) - 1
            start = int(pos["opened_ms"])
            hs = [ind["h"][k] for k in range(len(ind["t"])) if ind["tc"][k] > start]
            ls = [ind["l"][k] for k in range(len(ind["t"])) if ind["tc"][k] > start]
            if hs:
                pos["extreme"] = max(pos["extreme"], max(hs)) if pos["side"] == S.LONG else min(pos["extreme"], min(ls))
            pos["atr_now"] = ind["atr"][i] or pos.get("atr")
            if S.time_stop_due(start, int(now * 1000), pos["side"], pos["entry"], pos["extreme"], pos["r_dist"], self.cfg):
                self.exit_position(sym, "TIME")
                continue
            sig = d["sig"]
            if sig.get("side") and sig["side"] != pos["side"]:
                self.exit_position(sym, "REVERSE")
                continue
            self.maybe_trail(sym, pos, force=True)
        if allow_entries:
            self.try_addons(now, only)
            self.try_entries(now, only)
        self.save()

    def try_addons(self, now, only=None):
        """Pyramiding: on a fresh candle close, add one unit to each winner that qualifies (strategy.addon_due)."""
        if int(self.cfg.get("pyramid_max_adds", 0) or 0) <= 0:
            return
        for sym, pos in list(self.positions.items()):
            d = self.data.get(sym)
            if not d or not d.get("fresh") or (only is not None and sym not in only) \
                    or (self.filters and not self.plain_perp(sym)):
                continue
            if pos.get("exit_reason") or pos.get("fin_tries"):
                continue  # already closed or closing, only waiting to be booked: never add to that
            candle = d["ind"]["tc"][-1]
            if pos.get("add_candle") == candle or sym not in self.filters or not pos.get("lev"):
                continue
            pos.pop("add_pending", None)  # an add from an earlier candle has landed long ago, or never will
            if S.addon_due(pos, d["ind"]["c"][-1], self.cfg):
                self.add_unit(sym, pos, candle, now)

    def add_unit(self, sym, pos, candle, now):
        side = pos["side"]
        f = self.filters[sym]
        try:
            ex = self.broker.positions().get(sym)
            eq = self.broker.equity()
        except (BinanceError, NetworkError) as e:
            self.log.warning("add %s: account lookup failed: %s", sym, e)
            return False
        # the exchange must show exactly the position the books say (not closed by its stop, not resized by hand)
        if not ex or (ex["amt"] > 0) != (side == S.LONG) or abs(abs(ex["amt"]) - pos["qty"]) > float(f["step"]) / 2:
            self.event("SKIP", sym=sym, side=side, code="OUT_OF_SYNC", add=True)
            return False
        ok, code = R.can_add(self.ledger, now, self.guard_equity(eq["equity"]), self.cfg, paused=self.state.get("paused"),
                             blocked=bool(self.state.get("blocked")))
        mark = self.marks.get(sym) or pos.get("mark") or pos["entry"]
        sz = R.size_addon(eq["equity"], eq["available"], pos, mark, self.cfg, f) if ok else {"ok": False, "code": code}
        if not sz["ok"]:
            self.event("SKIP", sym=sym, side=side, code=sz["code"], add=True)
            return False
        # One attempt per candle, written down BEFORE the order: an add with an unknown outcome is never re-sent.
        # add_pending tells reconcile that a quantity which grows on the exchange is this add landing late.
        pos["add_candle"] = candle
        pos["add_pending"] = True
        self.save()
        try:
            fill = self.broker.market(sym, "BUY" if side == S.LONG else "SELL", sz["qty"], tag="A")
        except (BinanceError, NetworkError) as e:
            self.alert(f"add_{sym}", f"⚠️ {short(sym)} 추가 진입 주문 실패: {e}\n기존 포지션과 손절은 그대로입니다.", every=600)
            self.event("ERROR", where="add", sym=sym, msg=str(e))
            return False
        pos.pop("add_pending", None)
        if fill["qty"] <= 0 or fill["avg"] <= 0:
            self.save()
            return False
        old_qty = pos["qty"]
        pos["entry"] = (pos["entry"] * old_qty + fill["avg"] * fill["qty"]) / (old_qty + fill["qty"])
        pos["qty"] = R.round_step(old_qty + fill["qty"], f["step"])
        pos["adds"] = int(pos.get("adds", 0) or 0) + 1
        pos["last_add_px"] = fill["avg"]
        gap = (fill["avg"] - pos["stop"]) if side == S.LONG else (pos["stop"] - fill["avg"])
        add_risk = fill["qty"] * max(gap, 0.0)
        pos["risk_amt"] = float(pos.get("risk_amt") or 0.0) + add_risk
        pos["locked_notified"] = False
        self.save()
        self.event("ADD", sym=sym, side=side, qty=fill["qty"], entry=fill["avg"], n=pos["adds"])
        for _ in range(3):  # the exchange stop must cover the whole position again
            if self.replace_stop(sym, pos, pos["stop"], resize=True):
                break
            if sym not in self.positions or pos.get("exit_reason"):
                return True  # price was already through the stop: the whole position was closed instead
            self.sleep(1.0)
        else:
            return self.undo_add(sym, pos, fill["qty"], add_risk)
        at_stop = ((pos["stop"] - pos["entry"]) if side == S.LONG else (pos["entry"] - pos["stop"])) * pos["qty"]
        self.send(f"➕ 불타기 {pos['adds']}/{int(self.cfg['pyramid_max_adds'])} — {short(sym)} {SIDE_KO[side]}\n"
                  f"추가 {fill['qty']:g} @ {px(fill['avg'])} | 평균 진입가 {px(pos['entry'])} · 총 수량 {pos['qty']:g}\n"
                  f"손절 {px(pos['stop'])} (전체 수량에 다시 걸어둠) | 지금 손절되면 {usd(at_stop)} (수수료 전)")
        return True

    def undo_add(self, sym, pos, qty, add_risk):
        """The exchange would not take a stop for the bigger position: sell the added quantity again, so the stop
        that is still there covers everything (one stop for the whole position, always)."""
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        try:
            r = self.broker.market(sym, close_side, qty, reduce_only=True, tag="U")
        except (BinanceError, NetworkError) as e:
            self.send(f"🚨 {short(sym)}: 추가 진입분({qty:g})에 손절을 걸지 못했고, 되돌리는 주문도 실패했습니다({e}).\n"
                      "기존 손절은 처음 수량만 보호합니다. 봇이 20초마다 다시 시도합니다. 앱에서도 확인해 주세요.")
            self.event("ERROR", where="undo_add", sym=sym, msg=str(e))
            return False
        f = self.filters.get(sym, R.DEFAULT_FILTER)
        pos["qty"] = R.round_step(max(pos["qty"] - r["qty"], 0.0), f["step"])
        pos["risk_amt"] = max(float(pos.get("risk_amt") or 0.0) - add_risk, 0.0)
        self.save()
        self.event("ADD_UNDONE", sym=sym, msg=f"{r['qty']:g}")
        self.send(f"⚠️ {short(sym)}: 추가 진입분({r['qty']:g})에 손절 주문이 걸리지 않아 그만큼 바로 다시 정리했습니다. "
                  "기존 포지션과 손절은 그대로입니다.")
        return False

    def try_entries(self, now, only=None):
        cands = [(sym, d["sig"]) for sym, d in self.data.items()
                 if d.get("fresh") and d["sig"].get("side") and sym not in self.positions
                 and (only is None or sym in only) and (not self.filters or self.plain_perp(sym))]
        cands.sort(key=lambda x: -x[1].get("strength", 0))
        for sym, sig in cands:
            if not self.funding_ok(sym, sig):
                continue
            eq = self.broker.equity()
            ok, code = R.can_enter(self.ledger, self.positions, sym, sig["side"], now, self.guard_equity(eq["equity"]),
                                   self.cfg, paused=self.state.get("paused"), blocked=bool(self.state.get("blocked")))
            if not ok:
                self.event("SKIP", sym=sym, side=sig["side"], code=code)
                continue
            self.enter(sym, sig, eq)

    def funding_ok(self, sym, sig):
        """False while the funding filter says this side is crowded (strategy.funding_blocks). Read once per signal
        candle. A funding history that cannot be read never blocks an entry: the bot then trades as before."""
        if float(self.cfg.get("funding_max_pct", 0) or 0) <= 0:
            return True
        try:
            tc = int((self.data.get(sym) or {})["ind"]["tc"][sig["i"]])
        except (KeyError, IndexError, TypeError, ValueError):
            return True
        key = (sym, tc)
        if key not in self.funding_seen:
            try:
                rows = self.api.funding_rates(sym, start_time=tc - S.FUNDING_WINDOW_H * 3_600_000, end_time=tc,
                                              limit=100)
                rows = sorted((int(r["fundingTime"]), float(r["fundingRate"])) for r in rows)
            except (BinanceError, NetworkError, KeyError, TypeError, ValueError) as e:
                self.log.warning("funding history %s: %s", sym, e)
                return True  # asked again at the next look
            self.funding_seen = {k: v for k, v in self.funding_seen.items() if k[1] >= tc - 2 * 86_400_000}
            self.funding_seen[key] = S.funding_avg_8h([t for t, _ in rows], [r for _, r in rows], tc)
            avg = self.funding_seen[key]
            if S.funding_blocks(sig["side"], avg, self.cfg):
                self.event("SKIP", sym=sym, side=sig["side"], code="FUNDING", funding=round(avg * 100, 4))
                self.alert(f"funding_{sym}", f"⏸ {short(sym)} {SIDE_KO[sig['side']]} 신호 — 3일 평균 펀딩비 {avg * 100:+.3f}%"
                           f"(8시간당)로 과열이라 진입하지 않습니다(기준 {float(self.cfg['funding_max_pct']):g}%, "
                           "같은 코인은 하루 한 번만 알림).", every=86400)
        return not S.funding_blocks(sig["side"], self.funding_seen[key], self.cfg)

    def enter(self, sym, sig, eq):
        side = sig["side"]
        f = self.filters[sym]
        mark = self.marks.get(sym) or sig["close"]
        stop_ref, dist = S.initial_stop(side, mark, sig["atr"], self.cfg)
        sz = R.size_position(eq["equity"], eq["available"], mark, dist, self.cfg, f)
        if not sz["ok"]:
            self.event("SKIP", sym=sym, side=side, code=sz["code"])
            return False
        try:
            self.broker.prepare(sym)
            self.broker.set_leverage(sym, sz["lev"])
            fill = self.broker.market(sym, "BUY" if side == S.LONG else "SELL", sz["qty"], tag="E")
        except (BinanceError, NetworkError) as e:
            self.alert(f"entry_{sym}", f"⚠️ {short(sym)} 진입 주문 실패: {e}", every=600)
            self.event("ERROR", where="entry", sym=sym, msg=str(e))
            return False
        if fill["qty"] <= 0 or fill["avg"] <= 0:
            self.alert(f"entry_{sym}", f"⚠️ {short(sym)} 진입 주문이 체결되지 않았습니다(상태 {fill.get('status')}).", every=600)
            return False
        entry = fill["avg"]
        stop = R.round_step(entry - dist if side == S.LONG else entry + dist, f["tick"])
        pos = {
            "sym": sym, "side": side, "qty": fill["qty"], "entry": entry, "stop": stop, "init_stop": stop,
            "r_dist": dist, "atr": sig["atr"], "atr_now": sig["atr"], "opened_ms": self.now_ms(),
            "extreme": entry, "stop_id": None, "stop_set_ms": 0, "lev": sz["lev"],
            "risk_amt": fill["qty"] * dist, "reason": sig["code"], "breach": 0,
            "entry_order_id": fill.get("order_id"), "adds": 0, "last_add_px": entry,
            "signal": {"regime": sig["regime"], "adx": round(sig["adx"], 1), "rsi": round(sig["rsi"], 1)},
        }
        self.positions[sym] = pos
        R.on_entry(self.ledger, self.now())
        self.save()
        if not self.place_stop_safe(sym, pos):
            return False
        self.event("ENTRY", sym=sym, side=side, qty=pos["qty"], entry=entry, stop=stop, lev=sz["lev"],
                   risk=round(pos["risk_amt"], 4))
        stop_pct = abs(entry - stop) / entry * 100
        eqv = eq["equity"] or 1
        regime_word = S.REGIME_KO.get(sig["regime"], sig["regime"])
        brk = "고점" if side == S.LONG else "저점"
        self.send(
            f"{SIDE_ICON[side]} {SIDE_KO[side]} 진입 — {short(sym)} (x{sz['lev']}, 격리)\n"
            f"진입가 {px(entry)} | 수량 {fill['qty']:g}\n"
            f"손절 {px(stop)} ({'-' if side == S.LONG else '+'}{stop_pct:.2f}%) — 거래소에 걸어둠\n"
            f"위험 {usd(pos['risk_amt'], False)} (잔고의 {pos['risk_amt'] / eqv * 100:.1f}%) | 증거금 {usd(sz['margin'], False)}\n"
            f"근거: {tfl(self.cfg['trend_tf'])} {regime_word} · {tfl(self.cfg['signal_tf'])} {self.cfg['donchian_len']}봉 {brk} 돌파 · ADX {sig['adx']:.0f} · RSI {sig['rsi']:.0f}"
            + ("\n※ 증거금 한도로 위험을 줄였습니다." if sz.get("capped") else ""))
        return True

    # ------------------------------------------------------------ exits
    def exit_position(self, sym, reason):
        pos = self.positions.get(sym)
        if not pos:
            return False
        pos["exit_reason"] = reason
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        try:
            self.broker.market(sym, close_side, pos["qty"], reduce_only=True, tag="X")
        except (BinanceError, NetworkError) as e:
            pos.pop("exit_reason", None)
            if isinstance(e, BinanceError) and e.code == -2022 and self.gone_on_exchange(sym, pos):
                # the exchange stop (or a close in the app) got there first: book what really happened, no alarm
                self.finalize(sym, pos)
                return True
            self.send(f"🚨 {short(sym)} 청산 주문 실패: {e}\n거래소 손절 주문은 유지됩니다. 앱에서 확인해 주세요.")
            self.event("ERROR", where="exit", sym=sym, msg=str(e))
            return False
        self.finalize(sym, pos, reason)
        return True

    def gone_on_exchange(self, sym, pos):
        """True only when the exchange positively shows no position on our side of sym."""
        try:
            e = self.broker.positions().get(sym)
        except (BinanceError, NetworkError):
            return False
        return not e or (e["amt"] > 0) != (pos["side"] == S.LONG)

    def finalize(self, sym, pos, reason=None):
        reason = reason or pos.get("exit_reason")
        since = max(int(pos["opened_ms"]) - 3000, int(self.state.get("last_close_ms", {}).get(sym, 0)) + 1)
        try:
            r = self.broker.realized(sym, since, pos["side"], pos.get("entry_order_id"))
        except (BinanceError, NetworkError) as e:
            self.log.warning("realized %s: %s", sym, e)
            r = None
        if (r is None or r["closed_qty"] < pos["qty"] * 0.99) and int(pos.get("fin_tries", 0)) < 6:
            pos["fin_tries"] = int(pos.get("fin_tries", 0)) + 1
            return False
        if r is None:
            r = {"pnl": 0.0, "fee": 0.0, "funding": 0.0, "closed_qty": 0.0, "exit_price": 0.0}
        exit_px = r["exit_price"] or self.marks.get(sym) or pos["entry"]
        pnl = r["pnl"] - r["fee"] + r["funding"]
        if reason is None:
            near = abs(exit_px - pos["stop"]) / max(pos["stop"], 1e-12) < 0.006
            locked = (pos["side"] == S.LONG and pos["stop"] > pos["entry"]) or \
                     (pos["side"] == S.SHORT and pos["stop"] < pos["entry"])
            reason = ("TRAIL" if locked else "STOP") if near else "EXTERNAL"
        try:
            for s in self.broker.open_stops(sym):
                self.broker.cancel_stop(sym, s["id"])
        except (BinanceError, NetworkError):
            pass
        rmult = pnl / pos["risk_amt"] if pos.get("risk_amt") else 0.0
        now = self.now()
        events = R.on_exit(self.ledger, sym, pnl, now, self.cfg)
        hours = (self.now_ms() - int(pos["opened_ms"])) / 3_600_000
        rec = {"ts": now, "mode": self.state["mode"], "sym": sym, "side": pos["side"], "qty": pos["qty"],
               "entry": pos["entry"], "exit": exit_px, "pnl": round(pnl, 6), "fee": round(r["fee"], 6),
               "funding": round(r["funding"], 6), "r": round(rmult, 3), "reason": reason,
               "opened_ms": pos["opened_ms"], "hours": round(hours, 2), "lev": pos.get("lev"),
               "adds": int(pos.get("adds", 0) or 0)}
        self.store.append("journal.jsonl", rec)
        self.positions.pop(sym, None)
        self.state.setdefault("last_close_ms", {})[sym] = self.now_ms()
        self.save()
        self.event("EXIT", sym=sym, side=pos["side"], pnl=round(pnl, 4), r=round(rmult, 2), reason=reason)
        head = "✅ 익절" if pnl > 0 else "❌ 손절" if pnl < 0 else "➖ 본전"
        try:
            e = self.broker.equity()
            self.note_equity(e)
            eq = e["equity"]
        except (BinanceError, NetworkError):
            eq = self.state.get("equity") or 0
        self.send(f"{head} — {short(sym)} {SIDE_KO[pos['side']]} ({EXIT_KO.get(reason, reason)})\n"
                  f"진입 {px(pos['entry'])} → 청산 {px(exit_px)} | 보유 {hours:.1f}시간\n"
                  f"손익 {usd(pnl)} ({rmult:+.2f}R, 수수료·펀딩 포함)\n"
                  f"오늘 누적 {usd(self.ledger['day_realized'])} | 잔고 {usd(eq, False)}")
        for ev in events:
            if ev == "DAILY_LIMIT":
                self.send(f"⛔ 일일 손실 한도(-{self.cfg['daily_loss_limit_pct']}%) 도달 — 오늘(09시 KST 기준) 신규 진입을 멈춥니다.\n"
                          "보유 포지션은 손절이 걸린 채 유지됩니다.")
            elif ev == "STREAK_PAUSE":
                until = self.ledger.get("pause_until", 0)
                self.send(f"⏸ {self.cfg['loss_streak_limit']}연속 손실 — {hhmm(until)} (KST)까지 신규 진입 휴식.")
            self.event("GUARD", code=ev)
        return True

    def adopt(self, sym, e):
        side = S.LONG if e["amt"] > 0 else S.SHORT
        d = self.data.get(sym)
        atr_v = None
        if d:
            atr_v = d["ind"]["atr"][-1]
        if not atr_v:
            atr_v = e["entry"] * 0.01
        f = self.filters.get(sym, R.DEFAULT_FILTER)
        stop, dist = S.initial_stop(side, e["entry"], atr_v, self.cfg)
        m = self.marks.get(sym) or e["mark"]
        if (side == S.LONG and m <= stop) or (side == S.SHORT and m >= stop):
            stop, dist = S.initial_stop(side, m, atr_v, self.cfg)
            dist = abs(e["entry"] - stop)
        stop = R.round_step(stop, f["tick"])
        pos = {"sym": sym, "side": side, "qty": abs(e["amt"]), "entry": e["entry"], "stop": stop, "init_stop": stop,
               "r_dist": dist, "atr": atr_v, "atr_now": atr_v, "opened_ms": self.now_ms(), "extreme": m or e["entry"],
               "stop_id": None, "stop_set_ms": 0, "lev": None, "risk_amt": abs(e["amt"]) * dist,
               "reason": "ADOPTED", "breach": 0, "adopted": True}
        self.positions[sym] = pos
        self.save()
        self.send(f"ℹ️ {short(sym)} {SIDE_KO[side]} 포지션을 발견해 관리합니다(봇이 연 포지션이 아니거나 재시작 복구).\n"
                  f"보호 손절 {px(stop)} 설정 중…")
        self.ensure_stop(sym, pos)
        self.event("ADOPT", sym=sym, side=side, qty=pos["qty"], stop=stop)

    # ------------------------------------------------------------ briefs
    def briefs(self, now):
        k = kst(now)
        today = k.strftime("%Y-%m-%d")
        for name in ("morning", "evening"):
            try:
                hh, mm = [int(x) for x in str(self.cfg[f"brief_{name}_kst"]).split(":")]
            except Exception:
                continue
            sched = k.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if k >= sched and (k - sched) < timedelta(hours=2) and self.state["briefs"].get(name) != today:
                self.state["briefs"][name] = today
                try:
                    self.send(self.brief_text(name, now))
                except Exception as e:
                    self.log.warning("brief failed: %s", e)

    def monthly(self, now):
        """Once a month, from 09:10 KST on the 1st (after the daily spot run), report the month that just ended."""
        if not self.cfg.get("monthly_report", True):
            return
        key = datetime.fromtimestamp(now, timezone.utc).strftime("%Y-%m")
        last = self.state.get("report_month")
        if last is None:
            self.state["report_month"] = key  # first run (new install or update): the first report is next month
            return
        if last == key or now - RP.month_start(now) < 600:
            return
        self.state["report_month"] = key
        try:
            start, end, label = RP.prev_month(now)
            self.send(self.monthly_text(start, end, label))
        except Exception as e:  # a report must never disturb trading
            self.log.warning("monthly report failed: %s", e)

    def monthly_text(self, start, end, label):
        js = self.journal()
        trades = [t for t in js if start <= t.get("ts", 0) < end]
        fills = [t for t in self.store.read_all("spot_trades.jsonl")
                 if t.get("mode") == self.state["mode"] and start <= t.get("ts", 0) < end]
        try:
            btc = self.api.klines("BTCUSDT", "1d", limit=45)
        except (BinanceError, NetworkError) as e:
            self.log.warning("monthly report BTC prices: %s", e)
            btc = None
        flows = [f for f in self.store.read_all("flows.jsonl") if f.get("mode") == self.state["mode"]]
        return RP.monthly_text(label, self.mode_ko(), self.state.get("hist") or [], start, end, trades, js[-30:],
                               len(fills), btc, flows)

    def worst_case(self):
        tot = 0.0
        for pos in self.positions.values():
            diff = (pos["stop"] - pos["entry"]) if pos["side"] == S.LONG else (pos["entry"] - pos["stop"])
            tot += diff * pos["qty"]
        return tot

    def brief_text(self, name, now):
        eq = self.state.get("equity") or 0.0
        if name == "morning":
            since = now - 11 * 3600
            title = "☀️ 아침 브리핑 — 밤사이(약 21시~08시)"
        else:
            since = datetime(*kst(now).timetuple()[:3], tzinfo=KST).timestamp()
            title = "🌙 저녁 브리핑 — 오늘(00시~지금 KST)"
        trades = [t for t in self.store.read_all("journal.jsonl") if t.get("ts", 0) >= since
                  and t.get("mode") == self.state["mode"]]
        entries = [e for e in self.store.tail("events.jsonl", 300) if e.get("kind") == "ENTRY" and e.get("ts", 0) >= since]
        pnl = sum(t["pnl"] for t in trades)
        lines = [title, f"모드 {self.mode_ko()} | " + self.total_line()]
        lines.append(f"[선물] 진입 {len(entries)}건 · 청산 {len(trades)}건 · 실현손익 {usd(pnl)}")
        for t in trades[-6:]:
            lines.append(f"  {'✅' if t['pnl'] > 0 else '❌'} {short(t['sym'])} {SIDE_KO.get(t['side'], '')} "
                         f"{usd(t['pnl'])} ({t['r']:+.1f}R, {EXIT_KO.get(t['reason'], t['reason'])})")
        if self.positions:
            lines.append(f"[선물] 보유 {len(self.positions)}개:")
            lines.extend(self.positions_lines())
            wc = self.worst_case()
            lines.append(f"모든 손절이 체결되면: {usd(wc)} (수수료 전)")
        else:
            lines.append("선물 보유 포지션 없음")
        lines.append(self.guard_line())
        if self.spot_ready:
            sp = [t for t in self.store.read_all("spot_trades.jsonl") if t.get("ts", 0) >= since
                  and t.get("mode") == self.state["mode"]]
            lines.append("[현물] " + (f"오늘 리밸런싱 {len(sp)}건" if sp else "변경 없음") + " (매일 09:05 KST)")
            if name == "morning":
                lines.append(self.spot.gate_line())
            lines.extend(self.spot.lines(detail=True))
        if name == "evening":
            lines.append("폰 반납 후에도 봇과 거래소 손절은 계속 작동합니다. 내일 08시에 다시 보고할게요.")
        return "\n".join(lines)

    # ------------------------------------------------------------ text blocks
    def total_line(self):
        tot, sv, fv = self.total_equity()
        if not self.cfg.get("spot_enabled", True) or not self.spot_ready:
            return f"선물 잔고 {usd(fv, False)}"
        share = sv / tot * 100 if tot else 0.0
        T = self.state.get("total") or {}
        base = float(T.get("base") or 0.0)
        chg = f" (기준 대비 {((tot - self.unbooked()) / base - 1) * 100:+.1f}%)" if base else ""
        return (f"총자산 {usd(tot, False)}{chg} = 현물 {usd(sv, False)} ({share:.0f}%) + 선물 {usd(fv, False)} "
                f"({100 - share:.0f}%) | 목표 현물 {float(self.cfg.get('alloc_spot_pct', 50)):g}%")

    def positions_lines(self):
        out = []
        for sym, p in self.positions.items():
            m = p.get("mark") or self.marks.get(sym) or p["entry"]
            chg = (m - p["entry"]) / p["entry"] * 100 * (1 if p["side"] == S.LONG else -1)
            upnl = (m - p["entry"]) * p["qty"] * (1 if p["side"] == S.LONG else -1)
            rnow = upnl / p["risk_amt"] if p.get("risk_amt") else 0
            stop_pct = (p["stop"] - p["entry"]) / p["entry"] * 100 * (1 if p["side"] == S.LONG else -1)
            lev = f" x{p['lev']}" if p.get("lev") else ""
            if p.get("adds"):
                lev += f" · 불타기 {p['adds']}회"
            out.append(f"{SIDE_ICON[p['side']]} {short(sym)} {SIDE_KO[p['side']]}{lev} | {px(p['entry'])} → {px(m)} ({chg:+.2f}%)")
            out.append(f"   손절 {px(p['stop'])} ({stop_pct:+.2f}%) | 미실현 {usd(upnl)} ({rnow:+.2f}R)")
        return out

    def guard_line(self):
        L = self.ledger or {}
        lim = float(L.get("day_start_equity", 0)) * float(self.cfg["daily_loss_limit_pct"]) / 100
        parts = [f"오늘 진입 {L.get('day_entries', 0)}/{self.cfg['max_entries_per_day']}",
                 f"연속손실 {L.get('loss_streak', 0)}/{self.cfg['loss_streak_limit']}",
                 f"일일손익 {usd(float(L.get('day_realized', 0)))} (한도 -{usd(lim, False)})"]
        if self.now() < float(L.get("pause_until", 0)):
            parts.append(f"휴식 ~{hhmm(L['pause_until'])}")
        if L.get("day_limit_hit"):
            parts.append("일일한도 도달")
        return "가드: " + " | ".join(parts)

    # ------------------------------------------------------------ telegram
    def handle_update(self, u):
        owner = str(self.tg.chat_id) if self.tg else None
        if "callback_query" in u:
            cb = u["callback_query"]
            chat = str(((cb.get("message") or {}).get("chat") or {}).get("id"))
            if owner and chat != owner:
                return
            self.tg.answer_callback(cb["id"])
            self.on_callback(cb.get("data", ""))
            return
        msg = u.get("message") or {}
        chat = str((msg.get("chat") or {}).get("id"))
        if owner and chat != owner:
            return
        text = (msg.get("text") or "").strip()
        if not text:
            return
        if text in LABEL_CMD:
            text = "/" + LABEL_CMD[text]
        if not text.startswith("/"):
            self.send("명령은 아래 버튼이나 /help 를 사용하세요.", keyboard=KEYBOARD)
            return
        parts = text.split()
        cmd = parts[0][1:].split("@")[0].lower()
        args = parts[1:]
        fn = getattr(self, f"cmd_{cmd}", None)
        if not fn:
            self.send(f"모르는 명령: /{cmd}  — /help 참고")
            return
        try:
            fn(args)
        except Exception as e:
            self.log.error("command %s failed: %s\n%s", cmd, e, traceback.format_exc())
            self.send(f"⚠️ /{cmd} 처리 중 오류: {e}")

    def confirm(self, text, action, *args):
        nonce = pysecrets.token_hex(3)
        self.pending = {k: v for k, v in self.pending.items() if v[2] > self.now()}
        self.pending[nonce] = (action, args, self.now() + 180)
        self.send(text + "\n(3분 안에 눌러주세요)", inline=[[("✅ 실행", f"ok:{nonce}"), ("취소", f"no:{nonce}")]])

    def on_callback(self, data):
        kind, _, nonce = data.partition(":")
        item = self.pending.pop(nonce, None)
        if kind == "no":
            self.send("취소했습니다.")
            return
        if not item or item[2] < self.now():
            self.send("만료된 버튼입니다. 명령을 다시 보내주세요.")
            return
        action, args, _ = item
        getattr(self, f"act_{action}")(*args)

    # --- commands
    def cmd_start(self, args):
        self.cmd_help(args)

    def cmd_help(self, args):
        self.send(
            f"🤖 {self.cfg['bot_name']} 명령어\n"
            "📊 /status 상태·보유 포지션\n💰 /pnl 손익 성과\n🪙 /spot 현물 보유·목표 비중\n"
            "⚖️ /alloc 현물/선물 배분 (/alloc 50 = 현물 50%)\n🎚 /preset 안정·기본·공격 위험 단계(불타기 포함)\n"
            "🔎 /scan 선물 종목별 신호 상태\n📜 /log 최근 판단 기록\n📁 /export 거래기록 CSV(세금 신고용)\n"
            "📅 /report 지난달 리포트 (/report 이번달) — 매월 1일 자동 발송\n"
            "💵 /flows 입금·출금 기록 (실전은 자동 감지 · 놓친 것은 /deposit 100, /withdraw 100)\n"
            "⏸ /pause 신규 진입 정지 · ▶️ /resume 재개\n"
            "/close BTC 한 종목 청산 · /closeall 전체 청산\n"
            "/risk 3 — 1회 위험(%) 변경 · /settings 설정 보기 · /set 키 값\n"
            "/backtest 365 — 최근 N일 백테스트\n/selftest — API·계정 점검 (/selftest live: 실주문 왕복 테스트)\n"
            "/live 실전 전환 · /paper 모의 전환\n/update 업데이트 · /rollback 이전 버전 · /restart 재시작\n"
            "/rebase 자본 기준점(바닥선) 재설정", keyboard=KEYBOARD)

    def cmd_status(self, args):
        eq = self.state.get("equity") or 0.0
        avail = self.state.get("available") or 0.0
        st = "⏸ 일시정지" if self.state.get("paused") else ("⚠️ 차단: " + self.state["blocked"] if self.state.get("blocked") else "정상 운영")
        L = self.ledger or {}
        lines = [f"📊 상태 — {self.mode_ko()} | {st}", self.total_line(),
                 f"[선물] 잔고 {usd(eq, False)} (가용 {usd(avail, False)}) | 오늘 실현 {usd(float(L.get('day_realized', 0)))}",
                 f"보유 {len(self.positions)}/{self.cfg['max_open_positions']}"]
        lines.extend(self.positions_lines())
        lines.append(self.guard_line())
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        nxt = (int(self.now() // tf) + 1) * tf
        lines.append(f"다음 판단: {kst(nxt).strftime('%H:%M')} KST ({self.cfg['signal_tf']} 마감)")
        if self.cfg.get("spot_enabled", True):
            if self.spot_ready:
                lines.append("[현물] 매일 09:05 KST 리밸런싱 — 자세히: /spot")
                lines.extend(self.spot.lines(detail=False))
            else:
                lines.append("[현물] ⚠️ 준비 안 됨 — /selftest 로 점검")
        self.send("\n".join(lines), keyboard=KEYBOARD)

    def journal(self):
        return [t for t in self.store.read_all("journal.jsonl") if t.get("mode") == self.state["mode"]]

    def cmd_pnl(self, args):
        js = self.journal()
        now = self.now()

        def block(rows, label):
            if not rows:
                return f"{label}: 거래 없음"
            pnl = sum(t["pnl"] for t in rows)
            wins = [t for t in rows if t["pnl"] > 0]
            return f"{label}: {len(rows)}건, 승률 {len(wins) / len(rows) * 100:.0f}%, {usd(pnl)}, 평균 {sum(t['r'] for t in rows) / len(rows):+.2f}R"

        L = self.ledger or {}
        day_start = datetime.fromtimestamp(now, timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        lines = [f"💰 성과 — {self.mode_ko()}"]
        if self.cfg.get("spot_enabled", True) and self.spot_ready:
            T = self.state.get("total") or {}
            tot, sv, fv = self.total_equity()
            base = float(T.get("base") or 0)
            if base:
                since = kst(float(T.get("since") or now)).strftime("%Y-%m-%d")
                net = float(T.get("net_flow") or 0.0)
                how = (f"{since} 기준 {usd(base, False)} 대비" if abs(net) < 0.005
                       else f"{since} 이후 수익률(순입금 {usd(net)} 제외)")
                lines.append(f"[전체] {usd(tot, False)} — {how} {((tot - self.unbooked()) / base - 1) * 100:+.1f}% "
                             f"| 최대낙폭 {float(T.get('mdd') or 0):.1f}%")
            net_in = float(self.state["spot"].get("net_in") or 0)
            n_sp = len([t for t in self.store.read_all("spot_trades.jsonl") if t.get("mode") == self.state["mode"]])
            if net_in > 0:
                lines.append(f"[현물] 평가 {usd(sv, False)} / 투입 {usd(net_in, False)} → {usd(sv - net_in)} "
                             f"({(sv / net_in - 1) * 100:+.1f}%) | 리밸런싱 체결 {n_sp}건")
            lines.append("[선물] 돌파 전략 성과:")
        lines += [block([t for t in js if t["ts"] >= day_start], "오늘(09시~)"),
                 block([t for t in js if t["ts"] >= now - 7 * 86400], "최근 7일"),
                 block(js, "전체")]
        if js:
            gw = sum(t["pnl"] for t in js if t["pnl"] > 0)
            gl = -sum(t["pnl"] for t in js if t["pnl"] < 0)
            best = max(js, key=lambda t: t["pnl"])
            worst = min(js, key=lambda t: t["pnl"])
            lines.append(f"수익팩터 {gw / gl:.2f}" if gl > 0 else "수익팩터 -")
            lines.append(f"최고 {usd(best['pnl'])} ({short(best['sym'])}) / 최저 {usd(worst['pnl'])} ({short(worst['sym'])})")
        start = float(L.get("start_equity") or 0)
        eq = self.state.get("equity") or 0
        if start:
            lines.append(f"선물 잔고 {usd(eq, False)} (기준 {usd(start, False)} 대비 {(eq / start - 1) * 100:+.1f}%) | 최대낙폭 {self.state.get('max_dd', 0):.1f}%")
        self.send("\n".join(lines))

    # --- spot sleeve / allocation
    def cmd_spot(self, args):
        if not self.cfg.get("spot_enabled", True):
            self.send("현물 전략이 꺼져 있습니다. 켜기: /set spot_enabled true")
            return
        if not self.spot_ready:
            self.send("⚠️ 현물 모듈이 준비되지 않았습니다. /selftest 로 API 권한(현물 거래·범용 이체)을 확인하세요.")
            return
        self.spot.value(refresh=True)
        st = self.state["spot"]
        uni = ", ".join(short(x) for x in st.get("universe") or []) or "(다음 리밸런싱 때 선정)"
        last = st.get("last_run")
        lines = ["🪙 현물 — 추세 모멘텀 + 변동성 맞춤 비중 (레버리지 없음)",
                 f"운용 종목(거래대금 상위 {self.cfg.get('spot_universe_size', 6)}): {uni}",
                 f"마지막 리밸런싱: {hhmm(last) if last else '아직 없음'} | 다음: 매일 09:05 KST",
                 self.spot.gate_line(), self.spot.earn_line()]
        lines += self.spot.lines(detail=True)
        lines.append("신호 n/4 = 20·60·120·250일 전보다 오른 기간 수. 4/4면 강한 상승, 0/4면 현금(USDT) 대피.")
        lines.append("목표 비중 = 신호 × 변동성 역비례(변동성 큰 코인은 적게). 합계가 100%를 넘지 않습니다.")
        lines.append(f"BTC 게이트: BTC 신호가 {float(self.cfg.get('spot_btc_gate_min', 0.5)) * 4:g}/4 미만이면 "
                     "BTC를 뺀 코인의 목표 비중을 0으로 합니다.")
        self.send("\n".join(lines))

    def cmd_alloc(self, args):
        if not args:
            tot, sv, fv = self.total_equity()
            lines = ["⚖️ 배분 — " + self.total_line(),
                     f"조정 규칙: 목표에서 {float(self.cfg.get('alloc_band_pct', 10)):g}%p 이상 벗어나면 이체, "
                     "매월 1일에는 2%p 이상이면 목표로 맞춤 (09:05 KST)"]
            rows = [t for t in self.store.read_all("transfers.jsonl") if t.get("mode") == self.state["mode"]][-5:]
            for t in rows:
                lines.append(f"  {kst(t['ts']).strftime('%m/%d %H:%M')} {'현물→선물' if t['to'] == 'futures' else '선물→현물'} "
                             f"{usd(t['amount'], False)}")
            lines.append("변경: /alloc 60 (현물 60% : 선물 40%) · 위험 단계: /preset")
            self.send("\n".join(lines))
            return
        try:
            pct = float(args[0].rstrip("%"))
            if not 0 <= pct <= 100:
                raise ValueError
        except ValueError:
            self.send("사용법: /alloc 50  (현물 비중 %, 0~100)")
            return
        self.confirm(f"목표 배분을 현물 {pct:g}% : 선물 {100 - pct:g}% 로 바꾸고 바로 맞출까요?", "alloc", pct)

    def act_alloc(self, pct):
        self._save_setting("alloc_spot_pct", float(pct))
        self.force_rebalance()
        self.send(f"✅ 목표 배분 현물 {pct:g}% : 선물 {100 - pct:g}% — 다음 점검(1분 안)에 이체·리밸런싱합니다.")

    def cmd_preset(self, args):
        cur = (float(self.cfg.get("alloc_spot_pct", 50)), float(self.cfg["risk_per_trade_pct"]),
               float(self.cfg.get("spot_vol_target", 0.6)), int(self.cfg.get("pyramid_max_adds", 0) or 0))
        if not args or args[0] not in PRESETS:
            lines = ["🎚 위험 단계 (백테스트 2020~2026, 수수료 포함·펀딩비 8시간 0.03% 가정)"]
            for k, (sp, rk, vt, adds) in PRESETS.items():
                mark = " ← 현재" if cur == (sp, rk, vt, adds) else ""
                lines.append(f"{k}: 현물 {sp}% / 선물 {100 - sp}% · 선물 1회 위험 {rk:g}% · 불타기 {adds}회 — "
                             f"{PRESET_NOTE[k]}{mark}")
            lines.append("불타기 = 손절이 평균 진입가 위로 올라와 손실 위험이 없어진 포지션에만, 가격이 더 오르면 추가 진입.")
            lines.append("변경: /preset 기본   (과거 수치는 미래를 보장하지 않습니다. 최근 2025~26년은 과거 평균보다 훨씬 약했습니다)")
            self.send("\n".join(lines))
            return
        name = args[0]
        sp, rk, vt, adds = PRESETS[name]
        self.confirm(f"'{name}' 단계로 바꿀까요?\n현물 {sp}% : 선물 {100 - sp}% · 선물 1회 위험 {rk:g}% · 불타기 {adds}회 · "
                     f"현물 변동성 목표 {vt:g}\n{PRESET_NOTE[name]}", "preset", name)

    def act_preset(self, name):
        sp, rk, vt, adds = PRESETS[name]
        self._save_setting("alloc_spot_pct", float(sp))
        self._save_setting("risk_per_trade_pct", float(rk))
        self._save_setting("spot_vol_target", float(vt))
        self._save_setting("pyramid_max_adds", int(adds))
        self.force_rebalance()
        self.send(f"✅ '{name}' 단계 적용 — 현물 {sp}% : 선물 {100 - sp}%, 선물 1회 위험 {rk:g}%, 불타기 {adds}회. 곧 배분을 맞춥니다.")

    def _save_setting(self, key, val):
        settings = self.store.load_settings()
        settings[key] = val
        self.store.save_settings(settings)
        self.cfg[key] = val
        self.event("SET", key=key, msg=str(val))

    def force_rebalance(self):
        st = self.state.setdefault("spot", {})
        st["last_day"] = None
        st["retry_at"] = 0.0
        self.state["force_alloc"] = True
        self.save()

    def cmd_export(self, args):
        year = args[0] if args and args[0].isdigit() else None
        rows = [["구분", "시각(KST)", "모드", "종목", "방향", "수량", "평균가", "금액(USDT)", "손익(USDT)", "수수료", "비고"]]

        def keep(ts):
            return year is None or kst(ts).strftime("%Y") == year

        for t in self.store.read_all("journal.jsonl"):
            if keep(t.get("ts", 0)):
                rows.append(["선물청산", kst(t["ts"]).strftime("%Y-%m-%d %H:%M"), t.get("mode"), t.get("sym"), t.get("side"),
                             t.get("qty"), t.get("exit"), round(float(t.get("qty") or 0) * float(t.get("exit") or 0), 4),
                             t.get("pnl"), t.get("fee"), f"진입 {t.get('entry')} · 펀딩 {t.get('funding')} · {t.get('reason')}"])
        for t in self.store.read_all("spot_trades.jsonl"):
            if keep(t.get("ts", 0)):
                fee = ";".join(f"{a}:{v:.8f}" for a, v in (t.get("fee") or {}).items())
                rows.append(["현물체결", kst(t["ts"]).strftime("%Y-%m-%d %H:%M"), t.get("mode"), t.get("sym"), t.get("side"),
                             t.get("qty"), t.get("avg"), t.get("quote"), "", fee, f"목표비중 {t.get('target_w')}"])
        for t in self.store.read_all("transfers.jsonl"):
            if keep(t.get("ts", 0)):
                rows.append(["지갑이체", kst(t["ts"]).strftime("%Y-%m-%d %H:%M"), t.get("mode"), "USDT",
                             "현물→선물" if t.get("to") == "futures" else "선물→현물", "", "", t.get("amount"), "", "", t.get("why")])
        for t in self.store.read_all("earn.jsonl"):
            if keep(t.get("ts", 0)):
                rows.append(["이자예치" if t.get("kind") == "subscribe" else "이자환매",
                             kst(t["ts"]).strftime("%Y-%m-%d %H:%M"), t.get("mode"), t.get("asset", "USDT"),
                             "현물→유연 예치" if t.get("kind") == "subscribe" else "유연 예치→현물", "", "",
                             t.get("amount"), "", "", f"{t.get('why', '')} · 번호 {t.get('id')}"])
        for t in self.store.read_all("flows.jsonl"):
            if keep(t.get("ts", 0)):
                net = float(t.get("net") or 0.0)
                kind = "지갑간 이동" if abs(net) < 0.005 else ("입금" if net > 0 else "출금")
                if t.get("src") == "undo":
                    kind += "(기록 취소)"
                rows.append(["입출금", kst(t["ts"]).strftime("%Y-%m-%d %H:%M"), t.get("mode"), "USDT", kind, "", "",
                             t.get("net"), "", "", f"현물 {t.get('spot')} · 선물 {t.get('fut')} · {t.get('src')}"])
        if len(rows) == 1:
            self.send("내보낼 기록이 없습니다.")
            return
        import csv
        import io
        buf = io.StringIO()
        csv.writer(buf).writerows(rows)
        data = ("\ufeff" + buf.getvalue()).encode("utf-8")  # BOM so Excel/Numbers open Korean correctly
        name = f"trendhunter_{year or 'all'}.csv"
        ok = self.tg.send_document(name, data, caption=f"거래기록 {len(rows) - 1}건 (선물 청산·현물 체결·지갑 이체·입출금)") \
            if self.tg and hasattr(self.tg, "send_document") else None
        if not ok:
            self.send("⚠️ 파일 전송에 실패했습니다. 잠시 뒤 다시 시도하세요.")

    def cmd_report(self, args):
        now = self.now()
        if args and args[0] in ("이번달", "this", "now"):
            start, end, label = RP.month_start(now), now, RP.month_label(now) + " (지금까지)"
        else:
            start, end, label = RP.prev_month(now)
        self.send(self.monthly_text(start, end, label))

    def cmd_deposit(self, args):
        self._flow_cmd(args, +1)

    def cmd_withdraw(self, args):
        self._flow_cmd(args, -1)

    def _flow_cmd(self, args, sign):
        word, cmd = ("입금", "deposit") if sign > 0 else ("출금", "withdraw")
        try:
            amt = float(args[0].replace(",", "").lstrip("$"))
            if not 0 < amt < 1e9:
                raise ValueError
        except (IndexError, ValueError):
            self.send(f"사용법: /{cmd} 100  (USDT 금액). 선물 지갑에 직접 넣고 뺀 돈이면 /{cmd} 100 선물\n"
                      f"실전 모드에서는 {word}을 봇이 10분 안에 스스로 알아챕니다. 이 명령은 놓친 것을 적어 넣을 때만 쓰세요.")
            return
        wallet = "fut" if len(args) > 1 and args[1].lower() in ("선물", "futures", "fut") else "spot"
        where = "현물" if wallet == "spot" else "선물"
        if not (self.cfg.get("spot_enabled", True) and self.spot_ready and self.spot_mode_ok()):
            self.send("현물 모듈이 준비되지 않아 기록할 수 없습니다. /selftest 로 점검해 주세요.")
            return
        if self.state["mode"] != "live":
            self.confirm(f"모의 모드: 가상으로 {usd(amt, False)}을 {where} 지갑에 {word}할까요?", "flow", sign * amt, wallet)
            return
        if not self._flow_settled_for_manual():
            return
        if not self._flow_amount_ok(sign * amt, wallet):
            return
        self.confirm(f"자동으로 감지된 {word}이 없습니다. 그래도 {usd(amt, False)}을 {where} 지갑 {word}으로 기록할까요?\n"
                     "수익률 계산에만 반영하고 돈은 움직이지 않습니다. 이미 반영된 금액을 또 적으면 수익률이 틀어집니다.",
                     "flow", sign * amt, wallet)

    def _flow_settled_for_manual(self):
        """Before a record is written by hand, look at both wallets once more. True when nothing was found and
        nothing is still open — only then can a hand-written record not double what the bot books itself."""
        if not self.flow_on():  # detection is switched off: only fresh numbers are needed
            self.track_equity(self.now())
            self.spot.value(refresh=True)
            return True
        res = self.flow_watch(self.now(), force=True)
        if res == "booked":
            self.send("ℹ️ 방금 확인에서 위 내용을 자동으로 반영했습니다. 따로 더 기록하지 않았습니다.")
            return False
        if res == "unread" and (self.state.get("flow_fut") or {}).get("gave_up"):
            return True  # the rows of the unreadable day are skipped for good: a record cannot be booked twice
        if res in ("wait", "blocked", "unread"):
            self.send("⏳ 지금은 지갑 변화를 확인하는 중이라 직접 기록할 수 없습니다(이체 확인 중이거나 바이낸스 기록을 "
                      "읽지 못함). 확인이 끝나면 봇이 자동으로 반영합니다. 몇 분 뒤 /flows 로 확인해 주세요.")
            return False
        return True

    def _flow_amount_ok(self, amount, wallet):
        """A deposit can only be recorded for money that is already in that wallet."""
        tot, sv, fv = self.total_equity()
        have = fv if wallet == "fut" else tot
        if amount > 0 and amount >= have:
            where = "선물 지갑" if wallet == "fut" else "총자산"
            self.send(f"입금액({usd(amount, False)})이 지금 {where}({usd(have, False)})보다 크거나 같습니다. "
                      "이미 지갑에 들어와 있는 돈만 기록할 수 있습니다. 금액을 다시 확인해 주세요.")
            return False
        return True

    def act_flow(self, amount, wallet):
        if not (self.spot_ready and self.spot_mode_ok()):
            self.send("현물 모듈이 준비되지 않아 기록하지 못했습니다.")
            return
        if self.state["mode"] != "live":  # paper: the virtual money really moves
            if wallet == "spot":
                if self.spot.value(refresh=True)["usdt_free"] + amount < 0:
                    self.send("가상 현물 지갑의 USDT가 그만큼 없습니다.")
                    return
                self.spot.ex.adjust_usdt(amount)
            else:
                if self.broker.equity()["available"] + amount < 0:
                    self.send("가상 선물 지갑의 여유 잔고가 그만큼 없습니다.")
                    return
                self.broker.adjust_balance(amount)
                self.state["equity"] = self.broker.equity()["equity"]
            self.spot.value(refresh=True)
        elif not self._flow_settled_for_manual():  # the wallets may have changed since the question was asked
            return
        elif not self._flow_amount_ok(amount, wallet):
            return
        self.book_flow(self.now(), amount if wallet == "spot" else 0.0, amount if wallet == "fut" else 0.0, "manual")

    def cmd_flows(self, args):
        if args and args[0].lower() in ("undo", "취소"):
            last = self.state.get("last_flow")
            if not last or last.get("mode") != self.state["mode"]:
                self.send("취소할 기록이 없습니다(가장 최근 기록 하나만 취소할 수 있습니다).")
                return
            self.confirm(f"마지막 기록({kst(last['ts']).strftime('%m/%d %H:%M')}, {usd(last['net'])})을 취소할까요? "
                         "수익률 계산이 그 기록 전 상태로 돌아갑니다.", "flow_undo")
            return
        rows = [f for f in self.store.read_all("flows.jsonl") if f.get("mode") == self.state["mode"]]
        open_ = self.unbooked() if self.flow_on() else 0.0
        waiting = f"⏳ 확인 중인 지갑 변화 {usd(open_)} — 확인되면 자동으로 반영합니다." if abs(open_) >= 1.0 else ""
        if not rows:
            self.send("기록된 입금·출금이 없습니다. 실전 모드에서는 봇이 10분 안에 스스로 알아채 기록합니다.\n"
                      "놓친 것 적기: /deposit 100 · /withdraw 100" + ("\n" + waiting if waiting else ""))
            return
        tag = {"auto": "자동", "manual": "수동", "undo": "취소"}
        lines = ["💵 입금·출금 기록 (최근 10건)"]
        for f in rows[-10:]:
            lines.append(f"  {kst(f['ts']).strftime('%m/%d %H:%M')} {usd(f['net'])} (현물 {usd(f['spot'])}, 선물 {usd(f['fut'])}) "
                         f"· {tag.get(f.get('src'), f.get('src'))}")
        T = self.state.get("total") or {}
        lines.append(f"기준점 이후 순입금 {usd(float(T.get('net_flow') or 0.0))} — 수익률은 이 금액을 빼고 계산합니다.")
        if waiting:
            lines.append(waiting)
        lines.append("잘못 잡힌 마지막 기록 취소: /flows undo · 놓친 것 적기: /deposit 100, /withdraw 100")
        self.send("\n".join(lines))

    def act_flow_undo(self):
        last = self.state.get("last_flow")
        if not last or last.get("mode") != self.state["mode"]:
            self.send("취소할 기록이 없습니다.")
            return
        T = self.state.setdefault("total", {})
        prev = last.get("prev") or {}
        k, kf = last.get("k"), last.get("kf")
        if k is None:  # the record set a new starting point (or emptied it): the one before it comes back
            if prev.get("T") is not None:
                self.state["total"] = dict(prev["T"])
                self.state["nav_k"] = prev.get("nav_k")
        elif abs(float(last["net"])) >= 0.005 and float(k) > 0 and float(T.get("base") or 0) > 0:
            T["base"] = float(T["base"]) / float(k)
            T["peak"] = float(T.get("peak") or 0.0) / float(k)
            T["net_flow"] = float(T.get("net_flow") or 0.0) - float(last["net"])
        st = self.state["spot"]
        st["net_in"] = float(st.get("net_in") or 0.0) - float(last["spot"])
        if self.ledger and float(last["fut"]):
            for key in LEDGER_BASES:
                if kf:
                    self.ledger[key] = float(self.ledger.get(key) or 0.0) / float(kf)
                elif (prev.get("L") or {}).get(key) is not None:
                    self.ledger[key] = prev["L"][key]
        rec = {"ts": self.now(), "mode": self.state["mode"], "spot": -last["spot"], "fut": -last["fut"],
               "net": -last["net"], "total": last.get("total"), "src": "undo"}
        self.store.append("flows.jsonl", rec)
        self.state["last_flow"] = None
        self.event("FLOW", msg=f"undo {last['net']:+.2f}")
        self.save()
        self.send(f"↩️ 마지막 기록({usd(last['net'])})을 취소했습니다. 수익률 계산이 그 전 상태로 돌아갔습니다.")

    def cmd_scan(self, args):
        lines = ["🔎 스캔 (마지막 마감봉 기준)"]
        for sym in self.symbols():
            d = self.data.get(sym)
            if not d:
                lines.append(f"{short(sym)}: 데이터 없음")
                continue
            sig = d["sig"]
            reg = S.REGIME_KO.get(sig["regime"], sig["regime"])
            dist = ""
            if sig["regime"] == S.LONG and "dist_long_pct" in sig:
                dist = f" | 돌파선까지 {sig['dist_long_pct']:+.2f}%"
            elif sig["regime"] == S.SHORT and "dist_short_pct" in sig:
                dist = f" | 이탈선까지 {-sig['dist_short_pct']:+.2f}%"
            adxs = f" | ADX {sig['adx']:.0f}" if sig.get("adx") is not None else ""
            if sym in self.positions:
                state = f"보유 중({SIDE_KO[self.positions[sym]['side']]})"
            elif sig.get("side"):
                state = "✅ " + S.REASON_KO.get(sig["code"], sig["code"])
            else:
                state = "대기: " + S.REASON_KO.get(sig["code"], sig["code"])
            lines.append(f"{short(sym)} — {reg}{dist}{adxs}\n   {state}")
        self.send("\n".join(lines))

    def cmd_log(self, args):
        n = 15
        if args and args[0].isdigit():
            n = min(int(args[0]), 40)
        rows = self.store.tail("events.jsonl", n)
        if not rows:
            self.send("기록 없음")
            return
        out = ["📜 최근 판단 기록"]
        for e in rows:
            t = kst(e.get("ts", 0)).strftime("%m/%d %H:%M")
            k = e.get("kind")
            sym = short(e.get("sym", "")) if e.get("sym") else ""
            if k == "ENTRY":
                out.append(f"{t} 진입 {sym} {SIDE_KO.get(e.get('side'), '')} @{px(e.get('entry'))} 손절 {px(e.get('stop'))}")
            elif k == "EXIT":
                out.append(f"{t} 청산 {sym} {usd(e.get('pnl', 0))} ({e.get('r', 0):+.1f}R) {EXIT_KO.get(e.get('reason'), e.get('reason'))}")
            elif k == "SKIP":
                what = "불타기 패스" if e.get("add") else "패스"
                out.append(f"{t} {what} {sym} {SIDE_KO.get(e.get('side'), '')}: {R.GUARD_KO.get(e.get('code'), e.get('code'))}")
            elif k == "TRAIL":
                out.append(f"{t} 손절이동 {sym} {px(e.get('old'))}→{px(e.get('new'))}")
            elif k == "ADD":
                out.append(f"{t} 불타기 {sym} {SIDE_KO.get(e.get('side'), '')} {e.get('n')}회차 @{px(e.get('entry'))}")
            elif k == "GUARD":
                out.append(f"{t} 가드 {R.GUARD_KO.get(e.get('code'), e.get('code'))}")
            elif k == "ERROR":
                out.append(f"{t} 오류 {e.get('where')} {sym}: {str(e.get('msg'))[:80]}")
            else:
                out.append(f"{t} {k} {sym} {e.get('msg', '')}")
        self.send("\n".join(out))

    def cmd_pause(self, args):
        self.state["paused"] = True
        self.save()
        self.send("⏸ 신규 진입과 불타기를 멈췄습니다. 보유 포지션 관리(손절·추적)는 계속합니다. 재개: /resume")

    def cmd_resume(self, args):
        self.state["paused"] = False
        self.save()
        self.send("▶️ 신규 진입을 재개합니다.")

    def _find_sym(self, word):
        w = word.upper()
        for s in list(self.positions) + list(self.cfg["symbols"]):
            if s == w or short(s) == w:
                return s
        return w if w.endswith("USDT") else w + "USDT"

    def cmd_close(self, args):
        if not args:
            self.send("사용법: /close BTC")
            return
        sym = self._find_sym(args[0])
        if sym not in self.positions:
            self.send(f"{short(sym)} 보유 포지션이 없습니다.")
            return
        self.confirm(f"{short(sym)} 포지션을 시장가로 청산할까요?", "close", sym)

    def act_close(self, sym):
        if sym in self.positions:
            self.exit_position(sym, "MANUAL")

    def cmd_closeall(self, args):
        if not self.positions:
            self.send("보유 포지션이 없습니다.")
            return
        self.confirm(f"보유 포지션 {len(self.positions)}개를 모두 시장가로 청산할까요?", "closeall")

    def act_closeall(self):
        for sym in list(self.positions):
            self.exit_position(sym, "MANUAL")

    def cmd_risk(self, args):
        if not args:
            self.send(f"현재 1회 위험: {self.cfg['risk_per_trade_pct']}% — 변경: /risk 2.5")
            return
        self.cmd_set(["risk_per_trade_pct", args[0]])

    def cmd_settings(self, args):
        keys = ["spot_enabled", "alloc_spot_pct", "alloc_band_pct", "spot_candidates", "spot_universe_size",
                "spot_vol_target", "spot_band_pct", "spot_btc_gate", "spot_btc_gate_min", "spot_earn", "spot_cash_yield",
                "symbols", "signal_tf", "trend_tf", "allow_long", "allow_short", "risk_per_trade_pct", "max_leverage", "max_open_positions", "max_same_direction",
                "pyramid_max_adds", "pyramid_step_r", "pyramid_risk_frac", "liq_buffer_mult", "funding_max_pct",
                "max_entries_per_day", "daily_loss_limit_pct", "loss_streak_limit", "loss_streak_pause_hours",
                "cooldown_after_loss_hours", "equity_floor_pct", "time_stop_hours", "adx_min",
                "brief_morning_kst", "brief_evening_kst", "monthly_report", "flow_detect", "update_url"]
        lines = ["⚙️ 설정 (변경: /set 키 값)"]
        for k in keys:
            v = self.cfg.get(k)
            if k in ("symbols", "spot_candidates"):
                v = ",".join(short(s) for s in (v or []))
            lines.append(f"{k} = {v if v not in ('', None) else '(없음)'}")
        self.send("\n".join(lines))

    def cmd_set(self, args):
        if len(args) < 2 or args[0] not in SETTABLE:
            self.send("사용법: /set 키 값\n바꿀 수 있는 키: " + ", ".join(SETTABLE))
            return
        key, raw = args[0], " ".join(args[1:])
        kind, lo, hi = SETTABLE[key]
        try:
            if kind in (float, int):
                val = kind(float(raw)) if kind is int else float(raw)
                if not lo <= val <= hi:
                    raise ValueError(f"{lo}~{hi} 사이여야 합니다")
            elif kind is bool:
                low = raw.strip().lower()
                if low in ("true", "on", "1", "yes", "켜기", "켬"):
                    val = True
                elif low in ("false", "off", "0", "no", "끄기", "끔"):
                    val = False
                else:
                    raise ValueError("true 또는 false")
            elif kind is list:
                val = []
                for w in raw.replace(" ", "").split(","):
                    if not w:
                        continue
                    s = w.upper() if w.upper().endswith("USDT") else w.upper() + "USDT"
                    if self.filters and (s not in self.filters or self.filters[s]["status"] != "TRADING"):
                        raise ValueError(f"{s} 는 바이낸스 USDⓈ-M 무기한에 없습니다")
                    if self.filters and not self.plain_perp(s):
                        raise ValueError(f"{s} 는 주식·원자재 기반(TradFi) 무기한 또는 만기 선물이라 지원하지 않습니다"
                                         "(거래 시간이 따로 있고, 쉬는 동안에는 포지션을 관리할 수 없습니다)")
                    val.append(s)
                if not val:
                    raise ValueError("종목이 비었습니다")
            elif kind == "spotlist":
                val = []
                for w in raw.replace(" ", "").split(","):
                    if not w:
                        continue
                    s_ = w.upper() if w.upper().endswith("USDT") else w.upper() + "USDT"
                    if self.spot_ready:
                        try:
                            self.spot.public.exchange_info([s_])
                        except (BinanceError, NetworkError):
                            raise ValueError(f"{s_} 는 바이낸스 현물에 없습니다")
                    val.append(s_)
                if not val:
                    raise ValueError("종목이 비었습니다")
            elif kind == "hhmm":
                hh, mm = [int(x) for x in raw.split(":")]
                if not (0 <= hh < 24 and 0 <= mm < 60):
                    raise ValueError("HH:MM 형식")
                val = f"{hh:02d}:{mm:02d}"
            else:
                val = raw.strip()
        except ValueError as e:
            self.send(f"값 오류: {e}")
            return
        waiting = self.flow_waiting() if key in ("flow_detect", "spot_enabled") else 0.0
        settings = self.store.load_settings()
        settings[key] = val
        self.store.save_settings(settings)
        self.cfg[key] = val
        note = ""
        if abs(waiting) >= 1.0:
            note = (f"\n확인 중이던 지갑 변화 {usd(waiting)}는 반영하지 않고 넘깁니다. 입금·출금이었다면 /deposit 또는 "
                    "/withdraw 로 적어 주세요(그대로 두면 수익률에 섞입니다).")
        if key == "symbols":
            self.refresh_data()
        if key in ("spot_candidates", "spot_universe_size") and self.spot_ready:
            self.state["spot"]["universe_month"] = None
            if key == "spot_candidates":
                self.spot.load_filters()
                note = ("\n이미 들고 있는 코인이 운용 대상에 새로 들어오거나 빠지면, 그 금액은 입금·출금으로 기록됩니다"
                        "(수익률 계산에서 빼기 위해서이며 돈은 움직이지 않습니다).")
        if key == "spot_enabled":
            if val:
                self.spot_next_try = 0.0  # built fresh for the current mode on the next step
            else:
                self.spot, self.spot_ready = None, False  # holdings stay as they are; no more spot trades
            self.flow_reset()  # the set of wallets being watched changed: watch from now on
        if key in ("alloc_spot_pct",):
            self.state["force_alloc"] = True
        if key == "flow_detect":
            self.flow_reset()  # switched on: watch from now on, not from where the watch stopped
        self.event("SET", key=key, msg=str(val))
        self.send(f"✅ {key} = {val} 로 바꿨습니다 (즉시 적용).{note}")

    def cmd_rebase(self, args):
        if self.cfg.get("spot_enabled", True) and not (self.spot_ready and self.spot_mode_ok()):
            # the new base needs both wallets: without the spot balance, money that reaches the spot wallet later
            # could be counted neither as a deposit nor in the old base
            self.send("현물 모듈이 아직 준비되지 않아 지금은 기준점을 다시 잡을 수 없습니다(현물 잔고를 읽어야 합니다). "
                      "몇 분 뒤 다시 시도해 주세요. 계속 안 되면 /selftest 로 점검해 주세요.")
            return
        # what is in the wallets now is the new base: none of it may be booked as a deposit later
        self.flow_reset()
        try:  # the balance as it is now, not as the last step saw it
            self.note_equity(self.broker.equity())
        except (BinanceError, NetworkError) as err:
            self.log.warning("rebase: futures balance: %s", err)
        eq = self.state.get("equity") or 0.0
        self.ledger["start_equity"] = eq
        self.ledger["peak_equity"] = eq
        self.state["floor_alerted"] = False
        self.state["max_dd"] = 0.0
        extra = ""
        if self.spot_ready:
            try:
                sv = self.spot.value(refresh=True)["equity"]
                self.state["spot"]["net_in"] = sv
                tot = eq + sv
                self._new_base(tot, self.now())
                extra = (f"\n총자산 기준점 {usd(tot, False)} (현물 {usd(sv, False)} + 선물 {usd(eq, False)}). "
                         "수익률을 지금부터 새로 재고 싶을 때 쓰세요. 입금·출금은 봇이 스스로 반영합니다.")
            except (BinanceError, NetworkError) as e:
                extra = f"\n⚠️ 현물 평가 실패로 총자산 기준점은 그대로입니다: {e}"
        self.save()
        self.send(f"✅ 선물 자본 기준점을 {usd(eq, False)}로 재설정했습니다. 바닥선 = "
                  f"{usd(eq * self.cfg['equity_floor_pct'] / 100, False)}{extra}")

    # --- mode switching
    def cmd_live(self, args):
        if self.state["mode"] == "live":
            self.send("이미 실전 모드입니다.")
            return
        import selftest
        res = selftest.run_checks(self.api, self.cfg, self.cfg["symbols"], fix=False)
        if self.cfg.get("spot_enabled", True):
            res += selftest.run_spot_checks(self.spot_api_or_new(), self.cfg)
            self._merge_balance_checks(res)
        report = selftest.format_report(res)
        fails = [r for r in res if r["ok"] is False and r.get("blocking", True) and not r.get("fixable")]
        if fails:
            extra = ("\n(현물 전략 없이 선물만 쓰려면: /set spot_enabled false)" if any(r.get("spot") for r in fails) else "")
            self.send(report + "\n\n❌ 위 문제를 해결해야 실전으로 전환할 수 있습니다." + extra)
            return
        fut_eq = next((r.get("equity") for r in res if r.get("equity")), 0) or 0
        spot_eq = next((r.get("spot_equity") for r in res if r.get("spot_equity") is not None), 0) or 0
        tot = fut_eq + spot_eq
        if self.cfg.get("spot_enabled", True):
            sp = float(self.cfg.get("alloc_spot_pct", 50))
            plan = (f"총 {usd(tot, False)} → 현물 {sp:g}% ({usd(tot * sp / 100, False)}) : 선물 {100 - sp:g}% "
                    f"({usd(tot * (100 - sp) / 100, False)}) 로 자동 배분 후 바로 운용 시작.")
            risk_amt = tot * (100 - sp) / 100 * self.cfg["risk_per_trade_pct"] / 100
        else:
            plan = f"선물 {usd(fut_eq, False)} 로 운용."
            risk_amt = fut_eq * self.cfg["risk_per_trade_pct"] / 100
        coins = next((r for r in res if r.get("spot_coins") is not None), None)
        if self.cfg.get("spot_enabled", True) and coins and coins["spot_coins"] >= 1.0:
            plan += (f"\n⚠️ 현물 지갑에 이미 있는 코인({coins['spot_listing']})도 봇이 운용합니다. 목표 비중에 맞춰 일부를 팔 수 있어요. "
                     "따로 보관할 코인이면 먼저 다른 곳으로 옮기세요.")
        self.confirm(report + f"\n\n🔴 실전 모드로 전환할까요? 실제 돈으로 매매합니다.\n{plan}\n"
                     f"선물 1회 위험 {self.cfg['risk_per_trade_pct']}% ≈ {usd(risk_amt, False)}. 모의 포지션은 정리됩니다.", "go_live")

    @staticmethod
    def _merge_balance_checks(res):
        """With the spot sleeve the money may sit in either wallet: judge the TOTAL, not the futures wallet alone."""
        fut = next((r for r in res if "equity" in r), None)
        spot_eq = next((r.get("spot_equity") for r in res if r.get("spot_equity") is not None), 0.0) or 0.0
        move_ok = next((r["ok"] for r in res if r["name"].startswith("현물↔선물")), False)
        if fut is not None and fut["ok"] is False and (fut.get("equity") or 0) + spot_eq >= 10 and move_ok:
            fut["ok"] = None
            fut["detail"] += " — 현물 지갑 자금을 봇이 자동으로 배분합니다"

    def spot_api_or_new(self):
        if self.spot_api is None:
            self.spot_api = BinanceSpot(self.api.key, self.api.secret.decode(),
                                        base_url=os.environ.get("TH_SPOT_BASE", "https://api.binance.com"),
                                        clock=self.clock, sleep=self.sleep, log=self.log)
        return self.spot_api

    def reset_spot_mode(self, mode):
        """Start the spot sleeve over for a new mode: fresh state, fresh paper wallet, fresh back-end."""
        st = self.state.setdefault("spot", {})
        st.update(last_day=None, net_in=None, targets={}, diag={}, fails=0, retry_at=0.0, last_trades=[], earn={})
        self.flow_reset()
        self.state["nav_k"], self.state["nav_last"] = 1.0, None
        self.state["total"] = {}
        self.state["hist"] = []
        self.state["hist_day"] = None
        self.state["force_alloc"] = True
        self.state["pending_transfer"] = None
        try:
            from spot import PaperSpot
            PaperSpot(None, {}, self.cfg, self.store.path("paper_spot.json"), self.log, self.clock).reset(0.0)
        except OSError as e:
            self.log.warning("paper spot reset: %s", e)
        self.spot_startup()  # builds nothing when spot is disabled; otherwise a clean sleeve for `mode`
        if self.cfg.get("spot_enabled", True) and not self.spot_ready:
            self.spot_next_try = self.now() + 60
            self.send("⚠️ 현물 모듈을 새 모드로 준비하지 못했습니다 — 1분 뒤 다시 시도합니다. 그동안 현물 매매·이체는 하지 않습니다.")

    def act_go_live(self):
        try:
            live = LiveBroker(self.api, self.filters, self.cfg, self.log)
            self.broker = live
            self.check_account_settings(fix=True)
            eq = live.equity()
        except (BinanceError, NetworkError) as e:
            self.broker = self.make_broker()
            self.send(f"❌ 실전 전환 실패: {e}")
            return
        if self.state.get("blocked"):
            self.broker = self.make_broker()
            self.send(f"❌ 실전 전환 중단: {self.state['blocked']}")
            return
        try:
            PaperBroker(self.api, self.filters, self.cfg, self.store.path("paper.json"), self.log, self.clock).reset()
        except Exception:
            pass
        self.state.update(mode="live", positions={}, ledger=R.new_ledger(eq["equity"], self.now()),
                          max_dd=0.0, floor_alerted=False)
        for s in self.symbols():
            live.prepare(s)
        self.state["equity"] = eq["equity"]
        self.reconcile()
        self.reset_spot_mode("live")
        self.save()
        self.event("MODE", msg="live")
        spot_note = ("\n현물/선물 배분과 현물 리밸런싱을 1분 안에 실행하고, 이후 매일 09:05 KST에 점검합니다."
                     if self.cfg.get("spot_enabled", True) else "")
        self.send(f"🔴 실전 모드 시작 — 선물 잔고 {usd(eq['equity'], False)}\n"
                  f"선물 1회 위험 {self.cfg['risk_per_trade_pct']}% (배분 후 선물 잔고 기준) | "
                  f"선물 자본 바닥선 {self.cfg['equity_floor_pct']:g}%\n"
                  f"선물 신호는 다음 {self.cfg['signal_tf']} 봉 마감부터 봅니다.{spot_note}", keyboard=KEYBOARD)

    def cmd_paper(self, args):
        if self.state["mode"] == "paper":
            self.send("이미 모의 모드입니다.")
            return
        if self.positions:
            self.send("실전 포지션이 남아 있습니다. 먼저 /closeall 로 정리한 뒤 전환하세요.")
            return
        self.confirm("모의 모드로 전환할까요? (가상 잔고로 새로 시작)", "go_paper")

    def act_go_paper(self):
        if self.positions:
            self.send("실전 포지션이 남아 있어 전환을 취소했습니다.")
            return
        self.state.update(mode="paper", positions={})
        self.broker = self.make_broker()
        self.broker.reset()
        eq = self.broker.equity()
        self.state.update(ledger=R.new_ledger(eq["equity"], self.now()), max_dd=0.0, floor_alerted=False,
                          equity=eq["equity"])
        self.reset_spot_mode("paper")
        self.save()
        self.event("MODE", msg="paper")
        note = (f"\n곧 현물 {float(self.cfg.get('alloc_spot_pct', 50)):g}% : 선물 나머지로 가상 배분합니다. "
                "실전 현물 보유분은 건드리지 않습니다." if self.cfg.get("spot_enabled", True) else "")
        self.send(f"🧪 모의 모드 시작 — 가상 잔고 {usd(eq['equity'], False)}{note}")

    # --- background jobs
    def _bg(self, name, fn):
        if self.bg_busy:
            self.send(f"이미 '{self.bg_busy}' 작업이 진행 중입니다. 끝나면 다시 시도하세요.")
            return

        def run():
            try:
                fn()
            except Exception as e:
                self.log.error("%s failed: %s\n%s", name, e, traceback.format_exc())
                self.send(f"⚠️ {name} 실패: {e}")
            finally:
                self.bg_busy = None

        self.bg_busy = name
        threading.Thread(target=run, daemon=True, name=name).start()

    def cmd_backtest(self, args):
        days = 730 if self.cfg.get("spot_enabled", True) else 365
        if args and args[0].isdigit():
            days = max(30, min(int(args[0]), 1460))
        self.send(f"⏳ 최근 {days}일 백테스트를 시작합니다(데이터 내려받기 포함 1~3분).")
        cfg = dict(self.cfg)
        only_fut = bool(args and args[-1].lower() in ("futures", "선물"))

        def job():
            if cfg.get("spot_enabled", True) and not only_fut:
                import backtest_mix
                text, _ = backtest_mix.report(cfg, days, fut_api=self.public_api_factory(),
                                              spot_api=self.spot_public_factory(),
                                              cache_dir=self.store.path("cache"), log=self.log)
            else:
                import backtest
                text, _ = backtest.report(cfg, days, risks=None, cache_dir=self.store.path("cache"),
                                          api=self.public_api_factory(), log=self.log)
            self.send(text)

        self._bg("백테스트", job)

    def cmd_selftest(self, args):
        import selftest
        if args and args[0].lower() == "live":
            self.confirm("실주문 왕복 테스트를 할까요?\n[선물] 최소 수량(약 6달러어치)을 시장가로 사고, 손절 주문을 걸었다 취소한 뒤 바로 팝니다.\n"
                         "[현물] 필요하면 선물→현물 7 USDT 이체, 6 USDT어치 사고 바로 판 뒤 되돌려 놓습니다.\n"
                         "비용은 수수료·호가차이로 보통 0.02달러 안팎입니다.", "selftest_live")
            return
        res = selftest.run_checks(self.api, self.cfg, self.cfg["symbols"], fix=False)
        if self.cfg.get("spot_enabled", True):
            res += selftest.run_spot_checks(self.spot_api_or_new(), self.cfg)
            self._merge_balance_checks(res)
        self.send(selftest.format_report(res))

    def act_selftest_live(self):
        import selftest

        def job():
            out = selftest.live_roundtrip(self.api, self.cfg, self.filters, self.log,
                                          exclude=set(self.positions))
            self.send(out["text"])
            if self.cfg.get("spot_enabled", True):
                if self.spot_ready and self.spot.due(self.now()):
                    self.send("ℹ️ 곧 현물 리밸런싱이 있어 현물 실주문 테스트는 건너뜁니다. 10분 뒤 다시 해 주세요.")
                    return
                self.spot_busy = True
                try:
                    out2 = selftest.spot_roundtrip(self.spot_api_or_new(), self.api, self.cfg, self.log)
                finally:
                    self.spot_busy = False
                    if self.spot is not None:
                        # not booked as the bot's own moves on purpose: nothing is judged while the test runs
                        # (flow_pass), and afterwards it has bought and sold the same amount and moved the same
                        # USDT there and back, so the look sees zero — and if the test broke half-way, it
                        # correctly sees money that changed wallets
                        self.spot.cache = None
                self.send(out2["text"])

        self._bg("실주문 테스트", job)

    def cmd_update(self, args):
        url = self.cfg.get("update_url")
        if not url:
            self.send("업데이트 주소가 없습니다. /set update_url https://github.com/아이디/저장소/raw/main/trendhunter.zip")
            return
        self.confirm(f"아래 주소의 최신 코드로 업데이트할까요?\n{url}\n(검증에 실패하면 기존 버전을 유지합니다)", "update")

    def act_update(self):
        import updater

        def job():
            old, new = updater.update(self.cfg["update_url"], APP_DIR, self.store.dir)
            self.send(f"✅ 업데이트 v{old} → v{new} 설치 완료. 재시작합니다(포지션·손절은 유지).")
            self.exit_code = 0

        self._bg("업데이트", job)

    def cmd_rollback(self, args):
        self.confirm("직전 버전으로 되돌릴까요?", "rollback")

    def act_rollback(self):
        import updater
        ver = updater.rollback(APP_DIR, self.store.dir)
        self.send(f"↩️ v{ver} 로 복구했습니다. 재시작합니다.")
        self.exit_code = 0

    def cmd_restart(self, args):
        self.confirm("봇을 재시작할까요? (포지션·손절은 유지됩니다)", "restart")

    def act_restart(self):
        self.send("🔄 재시작합니다.")
        self.exit_code = 0

    def cmd_version(self, args):
        self.send(f"{self.cfg['bot_name']} v{self.cfg['version']}")


# ---------------------------------------------------------------- runner

def run(data_dir):
    store = Store(data_dir)
    log = setup_logging(store)
    cfg = load_config(APP_DIR, store)
    sec = store.load_secrets()
    if not sec.get("telegram_token"):
        log.error("secrets.json 이 없습니다. install.sh 를 먼저 실행하세요.")
        return 2
    base = os.environ.get("TH_BINANCE_BASE", "https://fapi.binance.com")
    api = BinanceFutures(sec.get("binance_key", ""), sec.get("binance_secret", ""), base_url=base, log=log)
    spot_base = os.environ.get("TH_SPOT_BASE", "https://api.binance.com")
    spot_api = BinanceSpot(sec.get("binance_key", ""), sec.get("binance_secret", ""), base_url=spot_base, log=log)
    tg = Telegram(sec["telegram_token"], sec.get("telegram_chat_id"), log=log)
    trader = Trader(cfg, store, api, tg, log, spot_api=spot_api,
                    spot_public_factory=lambda: BinanceSpot(base_url=spot_base, timeout=8))
    q = queue.Queue()
    poller = Poller(tg, q, log)
    poller.start()

    stopping = {"flag": False}

    def on_term(signum, frame):
        stopping["flag"] = True

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    # start-up with retries (e.g. network down, wrong key) while still answering commands
    while not stopping["flag"]:
        try:
            trader.startup()
            break
        except Exception as e:
            log.error("startup failed: %s\n%s", e, traceback.format_exc())
            hint = ""
            if isinstance(e, BinanceError) and (e.status == 451 or e.code == -2015):
                hint = ("\n힌트: -2015 = API 키/IP 제한/선물 권한 문제, 451 = 서버 국가 차단(미국 리전 등).")
            trader.alert("startup", f"⚠️ 봇 시작 실패: {e}{hint}\n1분 뒤 다시 시도합니다. /selftest 로 점검할 수 있어요.", every=900)
            end = time.time() + 60
            while time.time() < end and not stopping["flag"]:
                try:
                    u = q.get(timeout=1)
                    if trader.broker is None:
                        trader.broker = trader.make_broker()
                    trader.handle_update(u)
                except queue.Empty:
                    pass
                except Exception as ex:
                    log.warning("command during startup failed: %s", ex)

    next_step = 0.0
    loop = float(cfg.get("loop_seconds", 20))
    while not stopping["flag"] and trader.exit_code is None:
        now = time.time()
        if now >= next_step:
            try:
                trader.step()
                if trader.err_alerted:
                    trader.send("✅ 거래소 연결이 복구됐습니다.")
                trader.err_count = 0
                trader.err_alerted = False
            except Exception as e:
                trader.err_count += 1
                log.error("step failed (%d): %s\n%s", trader.err_count, e, traceback.format_exc())
                trader.event("ERROR", where="step", msg=str(e)[:300])
                if trader.err_count >= 3 and not trader.err_alerted:
                    trader.err_alerted = True
                    trader.send(f"⚠️ 연속 오류 {trader.err_count}회: {e}\n거래소 손절 주문은 유지됩니다. 계속 재시도합니다.")
            next_step = now + loop
        try:
            u = q.get(timeout=1.0)
            trader.handle_update(u)
        except queue.Empty:
            pass
        except Exception as e:
            log.error("update handling failed: %s", e)
    poller.stop()
    trader.save()
    if trader.exit_code is None:
        trader.send("⏹ 봇이 정지됐습니다. 거래소에 걸린 손절 주문은 그대로 유지됩니다.")
        return 0
    return trader.exit_code


def check(data_dir):
    """Used by the updater: imports everything and validates the config."""
    import backtest  # noqa: F401
    import backtest_mix  # noqa: F401
    import report  # noqa: F401
    import selftest  # noqa: F401
    import spot  # noqa: F401
    import spot_strategy  # noqa: F401
    import updater  # noqa: F401
    store = Store(data_dir)
    cfg = load_config(APP_DIR, store)
    for key in ("symbols", "signal_tf", "trend_tf", "risk_per_trade_pct", "ma_periods",
                "spot_candidates", "spot_lookbacks", "spot_vol_target", "alloc_spot_pct", "monthly_report",
                "spot_btc_gate", "spot_btc_gate_min", "spot_earn", "spot_cash_yield",
                "pyramid_max_adds", "pyramid_step_r", "pyramid_risk_frac", "liq_buffer_mult", "funding_max_pct"):
        if key not in cfg:
            raise SystemExit(f"config missing {key}")
    for key, lo, hi in (("pyramid_max_adds", 0, 3), ("pyramid_step_r", 0.5, 5.0), ("pyramid_risk_frac", 0.1, 1.0),
                        ("liq_buffer_mult", 0.0, 5.0), ("funding_max_pct", 0.0, 1.0)):
        v = cfg[key]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
            raise SystemExit(f"bad {key} ({lo}~{hi})")
    if cfg["pyramid_max_adds"] != int(cfg["pyramid_max_adds"]):
        raise SystemExit("bad pyramid_max_adds (whole number)")
    if not 0 <= float(cfg["alloc_spot_pct"]) <= 100:
        raise SystemExit("bad alloc_spot_pct")
    if not isinstance(cfg["monthly_report"], bool):
        raise SystemExit("bad monthly_report (true/false)")
    if not isinstance(cfg["spot_btc_gate"], bool):
        raise SystemExit("bad spot_btc_gate (true/false)")
    if isinstance(cfg["spot_btc_gate_min"], bool) or not isinstance(cfg["spot_btc_gate_min"], (int, float)) \
            or not 0 <= cfg["spot_btc_gate_min"] <= 1:
        raise SystemExit("bad spot_btc_gate_min (0~1)")
    if not isinstance(cfg["spot_earn"], bool):
        raise SystemExit("bad spot_earn (true/false)")
    if not isinstance(cfg.get("flow_detect"), bool):
        raise SystemExit("bad or missing flow_detect (true/false)")
    if isinstance(cfg["spot_cash_yield"], bool) or not isinstance(cfg["spot_cash_yield"], (int, float)) \
            or not 0 <= cfg["spot_cash_yield"] <= 0.3:
        raise SystemExit("bad spot_cash_yield (0~0.3)")
    if cfg["signal_tf"] not in TF_SECONDS or cfg["trend_tf"] not in TF_SECONDS:
        raise SystemExit("bad timeframe")
    print(f"OK {cfg['bot_name']} {cfg['version']}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.environ.get("TH_DATA_DIR", os.path.expanduser("~/trendhunter-data")))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.check:
        return check(a.data)
    return run(a.data)


if __name__ == "__main__":
    sys.exit(main())
