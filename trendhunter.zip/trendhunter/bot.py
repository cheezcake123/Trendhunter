#!/usr/bin/env python3
"""TrendHunter — Binance USD-M futures trend-following bot, operated from Telegram.

Run:  python3 bot.py [--data ~/trendhunter-data]
Mode starts as PAPER (simulated fills on live prices). Switch with /live in Telegram.
"""
from __future__ import annotations

import argparse
import logging
import logging.handlers
import math
import os
import queue
import secrets as pysecrets
import signal
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

import risk as R  # noqa: E402
import strategy as S  # noqa: E402
from binance_api import BinanceError, BinanceFutures, NetworkError, parse_filters  # noqa: E402
from brokers import LiveBroker, PaperBroker  # noqa: E402
from store import Store, load_config  # noqa: E402
from telegram_client import Poller, Telegram  # noqa: E402

KST = timezone(timedelta(hours=9))
TF_SECONDS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200,
              "4h": 14400, "6h": 21600, "8h": 28800, "12h": 43200, "1d": 86400}

SIDE_KO = {S.LONG: "롱", S.SHORT: "숏"}
SIDE_ICON = {S.LONG: "🟢", S.SHORT: "🔴"}
EXIT_KO = {
    "STOP": "손절",
    "TRAIL": "추적 손절·이익 보호",
    "TIME": "시간 손절",
    "REVERSE": "반대 신호",
    "SOFT_STOP": "봇 백업 손절",
    "STOP_NOW": "손절가 통과 즉시 청산",
    "NO_STOP": "손절 주문 실패 안전 청산",
    "MANUAL": "수동 청산",
    "EXTERNAL": "외부 청산(앱에서 직접 등)",
}

KEYBOARD = [["📊 상태", "💰 손익"], ["🔎 스캔", "📜 기록"], ["⏸ 정지", "▶️ 재개"], ["❓ 도움말"]]
LABEL_CMD = {"📊 상태": "status", "💰 손익": "pnl", "🔎 스캔": "scan", "📜 기록": "log",
             "⏸ 정지": "pause", "▶️ 재개": "resume", "❓ 도움말": "help"}
COMMANDS = [
    ("status", "현재 상태·보유 포지션"), ("pnl", "손익 성과"), ("scan", "종목별 신호 상태"),
    ("log", "최근 판단 기록"), ("pause", "신규 진입 일시정지"), ("resume", "신규 진입 재개"),
    ("close", "포지션 청산: /close BTC"), ("closeall", "전체 청산"), ("risk", "1회 위험 변경: /risk 3"),
    ("settings", "설정 보기"), ("set", "설정 변경: /set 키 값"), ("backtest", "백테스트: /backtest 365"),
    ("selftest", "계정·API 점검"), ("live", "실전 모드 전환"), ("paper", "모의 모드 전환"),
    ("update", "코드 업데이트"), ("rollback", "직전 버전 복구"), ("restart", "봇 재시작"),
    ("rebase", "자본 기준점 재설정"), ("help", "도움말"),
]
SETTABLE = {
    "risk_per_trade_pct": (float, 0.25, 5.0),
    "max_open_positions": (int, 1, 6),
    "max_same_direction": (int, 1, 6),
    "max_entries_per_day": (int, 1, 24),
    "daily_loss_limit_pct": (float, 2.0, 30.0),
    "max_leverage": (int, 1, 20),
    "equity_floor_pct": (float, 0.0, 95.0),
    "loss_streak_limit": (int, 2, 10),
    "loss_streak_pause_hours": (float, 0.0, 72.0),
    "cooldown_after_loss_hours": (float, 0.0, 72.0),
    "time_stop_hours": (float, 0.0, 480.0),
    "allow_short": (bool, None, None),
    "allow_long": (bool, None, None),
    "adx_min": (float, 0.0, 50.0),
    "symbols": (list, None, None),
    "update_url": (str, None, None),
    "brief_morning_kst": ("hhmm", None, None),
    "brief_evening_kst": ("hhmm", None, None),
}


# ---------------------------------------------------------------- formatting

def short(sym):
    return sym[:-4] if sym.endswith("USDT") else sym


def usd(x, signed=True):
    if not signed:
        return f"${x:,.2f}"
    sign = "+" if x > 0.004 else ("-" if x < -0.004 else "")
    return f"{sign}${abs(x):,.2f}"


def px(x):
    if x is None:
        return "-"
    ax = abs(x)
    if ax >= 1000:
        return f"{x:,.1f}"
    if ax >= 100:
        return f"{x:,.2f}"
    if ax >= 1:
        return f"{x:,.4f}"
    return f"{x:.5f}"


def tfl(tf):
    return tf.upper()


def kst(ts):
    return datetime.fromtimestamp(ts, KST)


def hhmm(ts):
    return kst(ts).strftime("%m/%d %H:%M")


def setup_logging(store):
    log = logging.getLogger("trendhunter")
    if log.handlers:
        return log
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fh = logging.handlers.RotatingFileHandler(store.path("bot.log"), maxBytes=1_000_000, backupCount=5,
                                              encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    log.addHandler(sh)
    return log


# ---------------------------------------------------------------- trader

class Trader:
    def __init__(self, cfg, store, api, tg, log, clock=time.time, sleep=time.sleep, public_api_factory=None):
        self.cfg = cfg
        self.store = store
        self.api = api
        self.tg = tg
        self.log = log
        self.clock = clock
        self.sleep = sleep
        self.public_api_factory = public_api_factory or (lambda: BinanceFutures(base_url=api.base))
        st = store.load_state() or {}
        st.setdefault("mode", "paper")
        st.setdefault("paused", False)
        st.setdefault("positions", {})
        st.setdefault("ledger", None)
        st.setdefault("last_candle", 0)
        st.setdefault("briefs", {})
        st.setdefault("blocked", None)
        st.setdefault("equity", None)
        st.setdefault("max_dd", 0.0)
        self.state = st
        self.filters = {}
        self.filters_loaded_at = 0.0
        self.data = {}
        self.marks = {}
        self.broker = None
        self.pending = {}
        self.exit_code = None
        self.bg_busy = None
        self.err_count = 0
        self.err_alerted = False
        self.last_alert = {}

    # ------------------------------------------------------------ basics
    @property
    def p(self):
        return self.cfg

    @property
    def positions(self):
        return self.state["positions"]

    @property
    def ledger(self):
        return self.state["ledger"]

    def now(self):
        return self.clock()

    def now_ms(self):
        return int(self.clock() * 1000)

    def symbols(self):
        return [s for s in self.cfg["symbols"] if s in self.filters] if self.filters else list(self.cfg["symbols"])

    def mode_ko(self):
        return "실전(LIVE)" if self.state["mode"] == "live" else "모의(PAPER)"

    def save(self):
        self.store.save_state(self.state)

    def event(self, kind, **kw):
        try:
            self.store.event(kind, ts=self.now(), **kw)
        except Exception as e:  # logging must never break trading
            self.log.warning("event log failed: %s", e)

    def send(self, text, **kw):
        self.log.info("TG> %s", text.replace("\n", " | ")[:300])
        return self.tg.send(text, **kw) if self.tg else None

    def alert(self, key, text, every=1800):
        now = self.now()
        if now - self.last_alert.get(key, 0) >= every:
            self.last_alert[key] = now
            self.send(text)

    def make_broker(self):
        if self.state["mode"] == "live":
            return LiveBroker(self.api, self.filters, self.cfg, self.log)
        return PaperBroker(self.api, self.filters, self.cfg, self.store.path("paper.json"), self.log, self.clock)

    # ------------------------------------------------------------ lifecycle
    def startup(self):
        self.api.sync_time()
        self.load_filters()
        self.broker = self.make_broker()
        if self.state["mode"] == "live":
            self.check_account_settings(fix=True)
        for s in self.symbols():
            self.broker.prepare(s)
        self.marks = self.api.mark_prices()
        self.broker.tick(self.marks)
        eq = self.broker.equity()
        now = self.now()
        if not self.ledger:
            self.state["ledger"] = R.new_ledger(eq["equity"], now)
        self.state["equity"] = eq["equity"]
        self.refresh_data()
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        cur_open = int(now // tf) * tf
        if not self.state.get("last_candle"):
            self.state["last_candle"] = (cur_open - tf) * 1000  # do not act on a candle that closed before start
        self.reconcile(startup=True)
        self.save()
        if self.tg:
            self.tg.set_commands(COMMANDS)
        lines = [f"🤖 {self.cfg['bot_name']} v{self.cfg['version']} 시작 — {self.mode_ko()}",
                 f"잔고 {usd(eq['equity'], False)} | 감시 {len(self.symbols())}종목 | 1회 위험 {self.cfg['risk_per_trade_pct']}%",
                 f"보유 포지션 {len(self.positions)}개"]
        if self.state.get("blocked"):
            lines.append(f"⚠️ 신규 진입 차단: {self.state['blocked']}")
        if self.state.get("paused"):
            lines.append("⏸ 일시정지 상태입니다 (/resume 으로 재개)")
        self.send("\n".join(lines), keyboard=KEYBOARD)

    def load_filters(self):
        info = self.api.exchange_info()
        self.filters.clear()
        self.filters.update(parse_filters(info))
        self.filters_loaded_at = self.now()
        bad = [s for s in self.cfg["symbols"] if s not in self.filters or self.filters[s]["status"] != "TRADING"]
        if bad:
            self.alert("bad_symbols", f"⚠️ 거래 불가 종목 제외: {', '.join(bad)}", every=86400)

    def check_account_settings(self, fix=False):
        problems = []
        try:
            has_pos = bool(self.broker.positions()) if self.broker else False
            if self.api.get_position_mode():
                if fix and not has_pos:
                    self.api.set_position_mode(False)
                    self.send("🔧 포지션 모드를 헤지 → 단방향(One-way)으로 바꿨습니다.")
                else:
                    problems.append("헤지 모드 — 단방향(One-way)으로 바꿔주세요")
            if self.api.get_multi_assets():
                if fix and not has_pos:
                    self.api.set_multi_assets(False)
                    self.send("🔧 멀티에셋 모드 → 단일자산 모드로 바꿨습니다(격리 마진 사용을 위해).")
                else:
                    problems.append("멀티에셋 모드 — 단일자산 모드로 바꿔주세요")
        except (BinanceError, NetworkError) as e:
            problems.append(f"계정 설정 확인 실패: {e}")
        self.state["blocked"] = "; ".join(problems) or None
        return problems

    # ------------------------------------------------------------ market data
    def refresh_data(self):
        now = self.now()
        now_ms = int(now * 1000)
        tf_sec = TF_SECONDS[self.cfg["signal_tf"]]
        for sym in self.symbols():
            try:
                raw1 = self.api.klines(sym, self.cfg["signal_tf"], limit=500)
                raw4 = self.api.klines(sym, self.cfg["trend_tf"], limit=1000)
            except (BinanceError, NetworkError) as e:
                self.log.warning("klines %s: %s", sym, e)
                self.data.pop(sym, None)
                continue
            c1 = S.candles_from_klines(raw1, now_ms)
            c4 = S.candles_from_klines(raw4, now_ms)
            if len(c1["c"]) < 60 or not c4["c"]:
                self.data.pop(sym, None)
                continue
            ind = S.prepare_1h(c1, self.cfg)
            r4 = S.prepare_4h(c4, self.cfg)
            i = len(ind["c"]) - 1
            reg = S.regime_at(r4, ind["tc"][i])
            sig = S.evaluate(ind, i, reg, self.cfg)
            fresh = (now_ms - ind["tc"][i]) <= (tf_sec * 1000 + 180_000)
            self.data[sym] = {"ind": ind, "r4": r4, "sig": sig, "updated": now, "fresh": fresh}

    # ------------------------------------------------------------ main step
    def step(self):
        now = self.now()
        self.marks = self.api.mark_prices()
        self.broker.tick(self.marks)
        if now - self.filters_loaded_at > 6 * 3600:
            self.load_filters()
        self.track_equity(now)
        self.reconcile()
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        cur_open = int(now // tf) * tf
        last_closed_ms = (cur_open - tf) * 1000
        if last_closed_ms > int(self.state.get("last_candle") or 0) and now - cur_open >= 5:
            self.state["last_candle"] = last_closed_ms
            self.on_candle(now, allow_entries=(now - cur_open) <= 600)
        self.briefs(now)
        self.save()

    def track_equity(self, now):
        eq = self.broker.equity()
        e = eq["equity"]
        self.state["equity"] = e
        self.state["available"] = eq["available"]
        L = self.ledger
        if L is None:
            self.state["ledger"] = L = R.new_ledger(e, now)
        R.roll_day(L, now, e)
        L["peak_equity"] = max(float(L.get("peak_equity") or e), e)
        if L["peak_equity"] > 0:
            dd = (e - L["peak_equity"]) / L["peak_equity"] * 100.0
            self.state["max_dd"] = min(float(self.state.get("max_dd") or 0.0), dd)
        floor = float(L.get("start_equity", 0)) * float(self.cfg["equity_floor_pct"]) / 100.0
        if e < floor and not self.state.get("floor_alerted"):
            self.state["floor_alerted"] = True
            self.send(f"🛑 자본 바닥선 도달 — 잔고 {usd(e, False)} < 바닥선 {usd(floor, False)}\n"
                      "신규 진입을 멈췄습니다. 보유 포지션은 손절이 걸린 채 유지됩니다.\n"
                      "전략을 점검한 뒤 /rebase (현재 잔고를 새 기준으로) 로 해제하세요.")
            self.event("GUARD", code="EQUITY_FLOOR", equity=e)
        return eq

    # ------------------------------------------------------------ reconcile & protection
    def reconcile(self, startup=False):
        ex = self.broker.positions()
        known = set(self.positions)  # symbols handled below must not be "adopted" in the same pass
        for sym, pos in list(self.positions.items()):
            e = ex.get(sym)
            if not e or (e["amt"] > 0) != (pos["side"] == S.LONG):
                self.finalize(sym, pos)
                continue
            qty = abs(e["amt"])
            if abs(qty - pos["qty"]) > 1e-12:
                pos["qty"] = qty
            m = self.marks.get(sym) or e["mark"]
            pos["mark"] = m
            pos["upnl"] = e["upnl"]
            pos["liq"] = e.get("liq", 0.0)
            if m:
                pos["extreme"] = max(pos["extreme"], m) if pos["side"] == S.LONG else min(pos["extreme"], m)
            if not self.ensure_stop(sym, pos):
                continue
            breached = m and ((pos["side"] == S.LONG and m <= pos["stop"]) or
                              (pos["side"] == S.SHORT and m >= pos["stop"]))
            if breached:
                pos["breach"] = int(pos.get("breach", 0)) + 1
                if pos["breach"] >= 3:
                    self.alert(f"soft_{sym}", f"⚠️ {short(sym)}: 가격이 손절가를 넘었는데 거래소 손절이 체결되지 않아 봇이 직접 청산합니다.", every=60)
                    self.exit_position(sym, "SOFT_STOP")
                    continue
            else:
                pos["breach"] = 0
            self.maybe_trail(sym, pos)
        for sym, e in ex.items():
            if sym in self.positions or sym in known:
                continue
            if sym not in self.cfg["symbols"]:
                self.alert(f"foreign_{sym}", f"ℹ️ 봇 감시 목록 밖의 포지션({short(sym)})은 관리하지 않습니다.", every=86400)
                continue
            self.adopt(sym, e)

    def ensure_stop(self, sym, pos):
        """Make sure exactly one protective stop sits on the exchange. Returns False if the position was closed."""
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        try:
            stops = self.broker.open_stops(sym)
        except (BinanceError, NetworkError) as e:
            self.log.warning("open stops %s: %s", sym, e)
            return True
        mine = [s for s in stops if s["side"] == close_side and (s["reduce_only"] or s["close_position"])]
        ids = {s["id"] for s in mine}
        if pos.get("stop_id") in ids:
            ours = next(s for s in mine if s["id"] == pos["stop_id"])
            for s in mine:
                if s["id"] != pos["stop_id"]:
                    self.broker.cancel_stop(sym, s["id"])
            if not ours["close_position"] and abs(ours["qty"] - pos["qty"]) > 1e-9:
                self.replace_stop(sym, pos, pos["stop"], note=False)
            return True
        if mine:
            # adopt the most protective stop that already exists, drop the rest
            if pos["side"] == S.LONG:
                best = max(mine, key=lambda s: s["trigger"])
                take = best["trigger"] >= pos["stop"]
            else:
                best = min(mine, key=lambda s: s["trigger"])
                take = best["trigger"] <= pos["stop"]
            for s in mine:
                if s["id"] != best["id"] or not take:
                    self.broker.cancel_stop(sym, s["id"])
            if take:
                pos["stop_id"] = best["id"]
                pos["stop"] = best["trigger"]
                self.save()
                return True
        if pos.get("stop_id"):
            self.alert(f"stop_gone_{sym}", f"⚠️ {short(sym)} 손절 주문이 거래소에서 사라져 다시 걸었습니다.", every=600)
        return self.place_stop_safe(sym, pos)

    def place_stop_safe(self, sym, pos, trigger=None):
        trigger = pos["stop"] if trigger is None else trigger
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        last = None
        for attempt in range(3):
            try:
                sid = self.broker.place_stop(sym, close_side, pos["qty"], trigger)
                pos.update(stop_id=sid, stop=trigger, stop_set_ms=self.now_ms())
                self.save()
                return True
            except BinanceError as e:
                last = e
                if e.code == -2021:  # would immediately trigger: price is already through the stop
                    self.exit_position(sym, "STOP_NOW")
                    return False
            except NetworkError as e:
                last = e
                try:
                    for s in self.broker.open_stops(sym):
                        if s["side"] == close_side and abs(s["trigger"] - trigger) <= abs(trigger) * 1e-6 + 1e-12:
                            pos.update(stop_id=s["id"], stop=trigger, stop_set_ms=self.now_ms())
                            self.save()
                            return True
                except Exception:
                    pass
            self.sleep(1.0)
        self.send(f"🚨 {short(sym)} 손절 주문을 걸지 못했습니다({last}). 안전을 위해 즉시 청산합니다.")
        self.event("ERROR", where="place_stop", sym=sym, msg=str(last))
        self.exit_position(sym, "NO_STOP")
        return False

    def replace_stop(self, sym, pos, new_trigger, note=True):
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        old_id, old_stop = pos.get("stop_id"), pos["stop"]
        try:
            sid = self.broker.place_stop(sym, close_side, pos["qty"], new_trigger)
        except BinanceError as e:
            if e.code == -2021:
                self.exit_position(sym, "TRAIL")
            else:
                self.log.warning("replace stop %s: %s", sym, e)
                self.event("ERROR", where="replace_stop", sym=sym, msg=str(e))
            return False
        except NetworkError as e:
            self.log.warning("replace stop %s: %s", sym, e)
            return False
        pos.update(stop_id=sid, stop=new_trigger, stop_set_ms=self.now_ms())
        if old_id and old_id != sid:
            self.broker.cancel_stop(sym, old_id)
        self.save()
        self.event("TRAIL", sym=sym, old=old_stop, new=new_trigger)
        locked = (pos["side"] == S.LONG and new_trigger > pos["entry"]) or \
                 (pos["side"] == S.SHORT and new_trigger < pos["entry"])
        if note and locked and not pos.get("locked_notified"):
            pos["locked_notified"] = True
            gain = abs(new_trigger - pos["entry"]) * pos["qty"]
            self.send(f"🔒 {short(sym)} {SIDE_KO[pos['side']]}: 손절을 수익 구간 {px(new_trigger)}로 올렸습니다 "
                      f"(최소 {usd(gain)} 확보, 수수료 전).", silent=True)
        return True

    def maybe_trail(self, sym, pos, force=False):
        atr_v = pos.get("atr_now") or pos.get("atr")
        if not atr_v:
            return
        f = self.filters.get(sym, R.DEFAULT_FILTER)
        cand = S.trail_stop(pos["side"], pos["entry"], pos["r_dist"], pos["stop"], pos["extreme"], atr_v, self.cfg)
        cand = R.round_step(cand, f["tick"])
        improve = (cand - pos["stop"]) if pos["side"] == S.LONG else (pos["stop"] - cand)
        min_step = max(float(self.cfg["trail_min_step_atr"]) * atr_v, float(f["tick"]))
        if improve < min_step:
            return
        if not force and self.now_ms() - int(pos.get("stop_set_ms") or 0) < 300_000:
            return
        m = self.marks.get(sym)
        if m and ((pos["side"] == S.LONG and m <= cand) or (pos["side"] == S.SHORT and m >= cand)):
            self.exit_position(sym, "TRAIL")
            return
        self.replace_stop(sym, pos, cand)

    # ------------------------------------------------------------ candle close
    def on_candle(self, now, allow_entries=True):
        self.refresh_data()
        for sym, pos in list(self.positions.items()):
            d = self.data.get(sym)
            if not d:
                continue
            ind = d["ind"]
            i = len(ind["c"]) - 1
            start = int(pos["opened_ms"])
            hs = [ind["h"][k] for k in range(len(ind["t"])) if ind["tc"][k] > start]
            ls = [ind["l"][k] for k in range(len(ind["t"])) if ind["tc"][k] > start]
            if hs:
                pos["extreme"] = max(pos["extreme"], max(hs)) if pos["side"] == S.LONG else min(pos["extreme"], min(ls))
            pos["atr_now"] = ind["atr"][i] or pos.get("atr")
            if S.time_stop_due(start, int(now * 1000), pos["side"], pos["entry"], pos["extreme"], pos["r_dist"], self.cfg):
                self.exit_position(sym, "TIME")
                continue
            sig = d["sig"]
            if sig.get("side") and sig["side"] != pos["side"]:
                self.exit_position(sym, "REVERSE")
                continue
            self.maybe_trail(sym, pos, force=True)
        if allow_entries:
            self.try_entries(now)
        self.save()

    def try_entries(self, now):
        cands = [(sym, d["sig"]) for sym, d in self.data.items()
                 if d.get("fresh") and d["sig"].get("side") and sym not in self.positions]
        cands.sort(key=lambda x: -x[1].get("strength", 0))
        for sym, sig in cands:
            eq = self.broker.equity()
            ok, code = R.can_enter(self.ledger, self.positions, sym, sig["side"], now, eq["equity"], self.cfg,
                                   paused=self.state.get("paused"), blocked=bool(self.state.get("blocked")))
            if not ok:
                self.event("SKIP", sym=sym, side=sig["side"], code=code)
                continue
            self.enter(sym, sig, eq)

    def enter(self, sym, sig, eq):
        side = sig["side"]
        f = self.filters[sym]
        mark = self.marks.get(sym) or sig["close"]
        stop_ref, dist = S.initial_stop(side, mark, sig["atr"], self.cfg)
        sz = R.size_position(eq["equity"], eq["available"], mark, dist, self.cfg, f)
        if not sz["ok"]:
            self.event("SKIP", sym=sym, side=side, code=sz["code"])
            return False
        try:
            self.broker.prepare(sym)
            self.broker.set_leverage(sym, sz["lev"])
            fill = self.broker.market(sym, "BUY" if side == S.LONG else "SELL", sz["qty"], tag="E")
        except (BinanceError, NetworkError) as e:
            self.alert(f"entry_{sym}", f"⚠️ {short(sym)} 진입 주문 실패: {e}", every=600)
            self.event("ERROR", where="entry", sym=sym, msg=str(e))
            return False
        if fill["qty"] <= 0 or fill["avg"] <= 0:
            self.alert(f"entry_{sym}", f"⚠️ {short(sym)} 진입 주문이 체결되지 않았습니다(상태 {fill.get('status')}).", every=600)
            return False
        entry = fill["avg"]
        stop = R.round_step(entry - dist if side == S.LONG else entry + dist, f["tick"])
        pos = {
            "sym": sym, "side": side, "qty": fill["qty"], "entry": entry, "stop": stop, "init_stop": stop,
            "r_dist": dist, "atr": sig["atr"], "atr_now": sig["atr"], "opened_ms": self.now_ms(),
            "extreme": entry, "stop_id": None, "stop_set_ms": 0, "lev": sz["lev"],
            "risk_amt": fill["qty"] * dist, "reason": sig["code"], "breach": 0,
            "entry_order_id": fill.get("order_id"),
            "signal": {"regime": sig["regime"], "adx": round(sig["adx"], 1), "rsi": round(sig["rsi"], 1)},
        }
        self.positions[sym] = pos
        R.on_entry(self.ledger, self.now())
        self.save()
        if not self.place_stop_safe(sym, pos):
            return False
        self.event("ENTRY", sym=sym, side=side, qty=pos["qty"], entry=entry, stop=stop, lev=sz["lev"],
                   risk=round(pos["risk_amt"], 4))
        stop_pct = abs(entry - stop) / entry * 100
        eqv = eq["equity"] or 1
        regime_word = S.REGIME_KO.get(sig["regime"], sig["regime"])
        brk = "고점" if side == S.LONG else "저점"
        self.send(
            f"{SIDE_ICON[side]} {SIDE_KO[side]} 진입 — {short(sym)} (x{sz['lev']}, 격리)\n"
            f"진입가 {px(entry)} | 수량 {fill['qty']:g}\n"
            f"손절 {px(stop)} ({'-' if side == S.LONG else '+'}{stop_pct:.2f}%) — 거래소에 걸어둠\n"
            f"위험 {usd(pos['risk_amt'], False)} (잔고의 {pos['risk_amt'] / eqv * 100:.1f}%) | 증거금 {usd(sz['margin'], False)}\n"
            f"근거: {tfl(self.cfg['trend_tf'])} {regime_word} · {tfl(self.cfg['signal_tf'])} {self.cfg['donchian_len']}봉 {brk} 돌파 · ADX {sig['adx']:.0f} · RSI {sig['rsi']:.0f}"
            + ("\n※ 증거금 한도로 위험을 줄였습니다." if sz.get("capped") else ""))
        return True

    # ------------------------------------------------------------ exits
    def exit_position(self, sym, reason):
        pos = self.positions.get(sym)
        if not pos:
            return False
        pos["exit_reason"] = reason
        close_side = "SELL" if pos["side"] == S.LONG else "BUY"
        try:
            self.broker.market(sym, close_side, pos["qty"], reduce_only=True, tag="X")
        except (BinanceError, NetworkError) as e:
            self.send(f"🚨 {short(sym)} 청산 주문 실패: {e}\n거래소 손절 주문은 유지됩니다. 앱에서 확인해 주세요.")
            self.event("ERROR", where="exit", sym=sym, msg=str(e))
            pos.pop("exit_reason", None)
            return False
        self.finalize(sym, pos, reason)
        return True

    def finalize(self, sym, pos, reason=None):
        reason = reason or pos.get("exit_reason")
        since = max(int(pos["opened_ms"]) - 3000, int(self.state.get("last_close_ms", {}).get(sym, 0)) + 1)
        try:
            r = self.broker.realized(sym, since, pos["side"], pos.get("entry_order_id"))
        except (BinanceError, NetworkError) as e:
            self.log.warning("realized %s: %s", sym, e)
            r = None
        if (r is None or r["closed_qty"] < pos["qty"] * 0.99) and int(pos.get("fin_tries", 0)) < 6:
            pos["fin_tries"] = int(pos.get("fin_tries", 0)) + 1
            return False
        if r is None:
            r = {"pnl": 0.0, "fee": 0.0, "funding": 0.0, "closed_qty": 0.0, "exit_price": 0.0}
        exit_px = r["exit_price"] or self.marks.get(sym) or pos["entry"]
        pnl = r["pnl"] - r["fee"] + r["funding"]
        if reason is None:
            near = abs(exit_px - pos["stop"]) / max(pos["stop"], 1e-12) < 0.006
            locked = (pos["side"] == S.LONG and pos["stop"] > pos["entry"]) or \
                     (pos["side"] == S.SHORT and pos["stop"] < pos["entry"])
            reason = ("TRAIL" if locked else "STOP") if near else "EXTERNAL"
        try:
            for s in self.broker.open_stops(sym):
                self.broker.cancel_stop(sym, s["id"])
        except (BinanceError, NetworkError):
            pass
        rmult = pnl / pos["risk_amt"] if pos.get("risk_amt") else 0.0
        now = self.now()
        events = R.on_exit(self.ledger, sym, pnl, now, self.cfg)
        hours = (self.now_ms() - int(pos["opened_ms"])) / 3_600_000
        rec = {"ts": now, "mode": self.state["mode"], "sym": sym, "side": pos["side"], "qty": pos["qty"],
               "entry": pos["entry"], "exit": exit_px, "pnl": round(pnl, 6), "fee": round(r["fee"], 6),
               "funding": round(r["funding"], 6), "r": round(rmult, 3), "reason": reason,
               "opened_ms": pos["opened_ms"], "hours": round(hours, 2), "lev": pos.get("lev")}
        self.store.append("journal.jsonl", rec)
        self.positions.pop(sym, None)
        self.state.setdefault("last_close_ms", {})[sym] = self.now_ms()
        self.save()
        self.event("EXIT", sym=sym, side=pos["side"], pnl=round(pnl, 4), r=round(rmult, 2), reason=reason)
        head = "✅ 익절" if pnl > 0 else "❌ 손절" if pnl < 0 else "➖ 본전"
        try:
            eq = self.broker.equity()["equity"]
            self.state["equity"] = eq
        except (BinanceError, NetworkError):
            eq = self.state.get("equity") or 0
        self.send(f"{head} — {short(sym)} {SIDE_KO[pos['side']]} ({EXIT_KO.get(reason, reason)})\n"
                  f"진입 {px(pos['entry'])} → 청산 {px(exit_px)} | 보유 {hours:.1f}시간\n"
                  f"손익 {usd(pnl)} ({rmult:+.2f}R, 수수료·펀딩 포함)\n"
                  f"오늘 누적 {usd(self.ledger['day_realized'])} | 잔고 {usd(eq, False)}")
        for ev in events:
            if ev == "DAILY_LIMIT":
                self.send(f"⛔ 일일 손실 한도(-{self.cfg['daily_loss_limit_pct']}%) 도달 — 오늘(09시 KST 기준) 신규 진입을 멈춥니다.\n"
                          "보유 포지션은 손절이 걸린 채 유지됩니다.")
            elif ev == "STREAK_PAUSE":
                until = self.ledger.get("pause_until", 0)
                self.send(f"⏸ {self.cfg['loss_streak_limit']}연속 손실 — {hhmm(until)} (KST)까지 신규 진입 휴식.")
            self.event("GUARD", code=ev)
        return True

    def adopt(self, sym, e):
        side = S.LONG if e["amt"] > 0 else S.SHORT
        d = self.data.get(sym)
        atr_v = None
        if d:
            atr_v = d["ind"]["atr"][-1]
        if not atr_v:
            atr_v = e["entry"] * 0.01
        f = self.filters.get(sym, R.DEFAULT_FILTER)
        stop, dist = S.initial_stop(side, e["entry"], atr_v, self.cfg)
        m = self.marks.get(sym) or e["mark"]
        if (side == S.LONG and m <= stop) or (side == S.SHORT and m >= stop):
            stop, dist = S.initial_stop(side, m, atr_v, self.cfg)
            dist = abs(e["entry"] - stop)
        stop = R.round_step(stop, f["tick"])
        pos = {"sym": sym, "side": side, "qty": abs(e["amt"]), "entry": e["entry"], "stop": stop, "init_stop": stop,
               "r_dist": dist, "atr": atr_v, "atr_now": atr_v, "opened_ms": self.now_ms(), "extreme": m or e["entry"],
               "stop_id": None, "stop_set_ms": 0, "lev": None, "risk_amt": abs(e["amt"]) * dist,
               "reason": "ADOPTED", "breach": 0, "adopted": True}
        self.positions[sym] = pos
        self.save()
        self.send(f"ℹ️ {short(sym)} {SIDE_KO[side]} 포지션을 발견해 관리합니다(봇이 연 포지션이 아니거나 재시작 복구).\n"
                  f"보호 손절 {px(stop)} 설정 중…")
        self.ensure_stop(sym, pos)
        self.event("ADOPT", sym=sym, side=side, qty=pos["qty"], stop=stop)

    # ------------------------------------------------------------ briefs
    def briefs(self, now):
        k = kst(now)
        today = k.strftime("%Y-%m-%d")
        for name in ("morning", "evening"):
            try:
                hh, mm = [int(x) for x in str(self.cfg[f"brief_{name}_kst"]).split(":")]
            except Exception:
                continue
            sched = k.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if k >= sched and (k - sched) < timedelta(hours=2) and self.state["briefs"].get(name) != today:
                self.state["briefs"][name] = today
                try:
                    self.send(self.brief_text(name, now))
                except Exception as e:
                    self.log.warning("brief failed: %s", e)

    def worst_case(self):
        tot = 0.0
        for pos in self.positions.values():
            diff = (pos["stop"] - pos["entry"]) if pos["side"] == S.LONG else (pos["entry"] - pos["stop"])
            tot += diff * pos["qty"]
        return tot

    def brief_text(self, name, now):
        eq = self.state.get("equity") or 0.0
        if name == "morning":
            since = now - 11 * 3600
            title = "☀️ 아침 브리핑 — 밤사이(약 21시~08시)"
        else:
            since = datetime(*kst(now).timetuple()[:3], tzinfo=KST).timestamp()
            title = "🌙 저녁 브리핑 — 오늘(00시~지금 KST)"
        trades = [t for t in self.store.read_all("journal.jsonl") if t.get("ts", 0) >= since
                  and t.get("mode") == self.state["mode"]]
        entries = [e for e in self.store.tail("events.jsonl", 300) if e.get("kind") == "ENTRY" and e.get("ts", 0) >= since]
        pnl = sum(t["pnl"] for t in trades)
        lines = [title, f"모드 {self.mode_ko()} | 잔고 {usd(eq, False)}",
                 f"진입 {len(entries)}건 · 청산 {len(trades)}건 · 실현손익 {usd(pnl)}"]
        for t in trades[-6:]:
            lines.append(f"  {'✅' if t['pnl'] > 0 else '❌'} {short(t['sym'])} {SIDE_KO.get(t['side'], '')} "
                         f"{usd(t['pnl'])} ({t['r']:+.1f}R, {EXIT_KO.get(t['reason'], t['reason'])})")
        if self.positions:
            lines.append(f"보유 {len(self.positions)}개:")
            lines.extend(self.positions_lines())
            wc = self.worst_case()
            lines.append(f"모든 손절이 체결되면: {usd(wc)} (수수료 전)")
        else:
            lines.append("보유 포지션 없음")
        lines.append(self.guard_line())
        if name == "evening":
            lines.append("폰 반납 후에도 봇과 거래소 손절은 계속 작동합니다. 내일 08시에 다시 보고할게요.")
        return "\n".join(lines)

    # ------------------------------------------------------------ text blocks
    def positions_lines(self):
        out = []
        for sym, p in self.positions.items():
            m = p.get("mark") or self.marks.get(sym) or p["entry"]
            chg = (m - p["entry"]) / p["entry"] * 100 * (1 if p["side"] == S.LONG else -1)
            upnl = (m - p["entry"]) * p["qty"] * (1 if p["side"] == S.LONG else -1)
            rnow = upnl / p["risk_amt"] if p.get("risk_amt") else 0
            stop_pct = (p["stop"] - p["entry"]) / p["entry"] * 100 * (1 if p["side"] == S.LONG else -1)
            lev = f" x{p['lev']}" if p.get("lev") else ""
            out.append(f"{SIDE_ICON[p['side']]} {short(sym)} {SIDE_KO[p['side']]}{lev} | {px(p['entry'])} → {px(m)} ({chg:+.2f}%)")
            out.append(f"   손절 {px(p['stop'])} ({stop_pct:+.2f}%) | 미실현 {usd(upnl)} ({rnow:+.2f}R)")
        return out

    def guard_line(self):
        L = self.ledger or {}
        lim = float(L.get("day_start_equity", 0)) * float(self.cfg["daily_loss_limit_pct"]) / 100
        parts = [f"오늘 진입 {L.get('day_entries', 0)}/{self.cfg['max_entries_per_day']}",
                 f"연속손실 {L.get('loss_streak', 0)}/{self.cfg['loss_streak_limit']}",
                 f"일일손익 {usd(float(L.get('day_realized', 0)))} (한도 -{usd(lim, False)})"]
        if self.now() < float(L.get("pause_until", 0)):
            parts.append(f"휴식 ~{hhmm(L['pause_until'])}")
        if L.get("day_limit_hit"):
            parts.append("일일한도 도달")
        return "가드: " + " | ".join(parts)

    # ------------------------------------------------------------ telegram
    def handle_update(self, u):
        owner = str(self.tg.chat_id) if self.tg else None
        if "callback_query" in u:
            cb = u["callback_query"]
            chat = str(((cb.get("message") or {}).get("chat") or {}).get("id"))
            if owner and chat != owner:
                return
            self.tg.answer_callback(cb["id"])
            self.on_callback(cb.get("data", ""))
            return
        msg = u.get("message") or {}
        chat = str((msg.get("chat") or {}).get("id"))
        if owner and chat != owner:
            return
        text = (msg.get("text") or "").strip()
        if not text:
            return
        if text in LABEL_CMD:
            text = "/" + LABEL_CMD[text]
        if not text.startswith("/"):
            self.send("명령은 아래 버튼이나 /help 를 사용하세요.", keyboard=KEYBOARD)
            return
        parts = text.split()
        cmd = parts[0][1:].split("@")[0].lower()
        args = parts[1:]
        fn = getattr(self, f"cmd_{cmd}", None)
        if not fn:
            self.send(f"모르는 명령: /{cmd}  — /help 참고")
            return
        try:
            fn(args)
        except Exception as e:
            self.log.error("command %s failed: %s\n%s", cmd, e, traceback.format_exc())
            self.send(f"⚠️ /{cmd} 처리 중 오류: {e}")

    def confirm(self, text, action, *args):
        nonce = pysecrets.token_hex(3)
        self.pending = {k: v for k, v in self.pending.items() if v[2] > self.now()}
        self.pending[nonce] = (action, args, self.now() + 180)
        self.send(text + "\n(3분 안에 눌러주세요)", inline=[[("✅ 실행", f"ok:{nonce}"), ("취소", f"no:{nonce}")]])

    def on_callback(self, data):
        kind, _, nonce = data.partition(":")
        item = self.pending.pop(nonce, None)
        if kind == "no":
            self.send("취소했습니다.")
            return
        if not item or item[2] < self.now():
            self.send("만료된 버튼입니다. 명령을 다시 보내주세요.")
            return
        action, args, _ = item
        getattr(self, f"act_{action}")(*args)

    # --- commands
    def cmd_start(self, args):
        self.cmd_help(args)

    def cmd_help(self, args):
        self.send(
            f"🤖 {self.cfg['bot_name']} 명령어\n"
            "📊 /status 상태·보유 포지션\n💰 /pnl 손익 성과\n🔎 /scan 종목별 신호 상태\n📜 /log 최근 판단 기록\n"
            "⏸ /pause 신규 진입 정지 · ▶️ /resume 재개\n"
            "/close BTC 한 종목 청산 · /closeall 전체 청산\n"
            "/risk 3 — 1회 위험(%) 변경 · /settings 설정 보기 · /set 키 값\n"
            "/backtest 365 — 최근 N일 백테스트\n/selftest — API·계정 점검 (/selftest live: 실주문 왕복 테스트)\n"
            "/live 실전 전환 · /paper 모의 전환\n/update 업데이트 · /rollback 이전 버전 · /restart 재시작\n"
            "/rebase 자본 기준점(바닥선) 재설정", keyboard=KEYBOARD)

    def cmd_status(self, args):
        eq = self.state.get("equity") or 0.0
        avail = self.state.get("available") or 0.0
        st = "⏸ 일시정지" if self.state.get("paused") else ("⚠️ 차단: " + self.state["blocked"] if self.state.get("blocked") else "정상 운영")
        L = self.ledger or {}
        lines = [f"📊 상태 — {self.mode_ko()} | {st}",
                 f"잔고 {usd(eq, False)} (가용 {usd(avail, False)}) | 오늘 실현 {usd(float(L.get('day_realized', 0)))}",
                 f"보유 {len(self.positions)}/{self.cfg['max_open_positions']}"]
        lines.extend(self.positions_lines())
        lines.append(self.guard_line())
        tf = TF_SECONDS[self.cfg["signal_tf"]]
        nxt = (int(self.now() // tf) + 1) * tf
        lines.append(f"다음 판단: {kst(nxt).strftime('%H:%M')} KST ({self.cfg['signal_tf']} 마감)")
        self.send("\n".join(lines), keyboard=KEYBOARD)

    def journal(self):
        return [t for t in self.store.read_all("journal.jsonl") if t.get("mode") == self.state["mode"]]

    def cmd_pnl(self, args):
        js = self.journal()
        now = self.now()

        def block(rows, label):
            if not rows:
                return f"{label}: 거래 없음"
            pnl = sum(t["pnl"] for t in rows)
            wins = [t for t in rows if t["pnl"] > 0]
            return f"{label}: {len(rows)}건, 승률 {len(wins) / len(rows) * 100:.0f}%, {usd(pnl)}, 평균 {sum(t['r'] for t in rows) / len(rows):+.2f}R"

        L = self.ledger or {}
        day_start = datetime.fromtimestamp(now, timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        lines = [f"💰 성과 — {self.mode_ko()}",
                 block([t for t in js if t["ts"] >= day_start], "오늘(09시~)"),
                 block([t for t in js if t["ts"] >= now - 7 * 86400], "최근 7일"),
                 block(js, "전체")]
        if js:
            gw = sum(t["pnl"] for t in js if t["pnl"] > 0)
            gl = -sum(t["pnl"] for t in js if t["pnl"] < 0)
            best = max(js, key=lambda t: t["pnl"])
            worst = min(js, key=lambda t: t["pnl"])
            lines.append(f"수익팩터 {gw / gl:.2f}" if gl > 0 else "수익팩터 -")
            lines.append(f"최고 {usd(best['pnl'])} ({short(best['sym'])}) / 최저 {usd(worst['pnl'])} ({short(worst['sym'])})")
        start = float(L.get("start_equity") or 0)
        eq = self.state.get("equity") or 0
        if start:
            lines.append(f"잔고 {usd(eq, False)} (기준 {usd(start, False)} 대비 {(eq / start - 1) * 100:+.1f}%) | 최대낙폭 {self.state.get('max_dd', 0):.1f}%")
        self.send("\n".join(lines))

    def cmd_scan(self, args):
        lines = ["🔎 스캔 (마지막 마감봉 기준)"]
        for sym in self.symbols():
            d = self.data.get(sym)
            if not d:
                lines.append(f"{short(sym)}: 데이터 없음")
                continue
            sig = d["sig"]
            reg = S.REGIME_KO.get(sig["regime"], sig["regime"])
            dist = ""
            if sig["regime"] == S.LONG and "dist_long_pct" in sig:
                dist = f" | 돌파선까지 {sig['dist_long_pct']:+.2f}%"
            elif sig["regime"] == S.SHORT and "dist_short_pct" in sig:
                dist = f" | 이탈선까지 {-sig['dist_short_pct']:+.2f}%"
            adxs = f" | ADX {sig['adx']:.0f}" if sig.get("adx") is not None else ""
            if sym in self.positions:
                state = f"보유 중({SIDE_KO[self.positions[sym]['side']]})"
            elif sig.get("side"):
                state = "✅ " + S.REASON_KO.get(sig["code"], sig["code"])
            else:
                state = "대기: " + S.REASON_KO.get(sig["code"], sig["code"])
            lines.append(f"{short(sym)} — {reg}{dist}{adxs}\n   {state}")
        self.send("\n".join(lines))

    def cmd_log(self, args):
        n = 15
        if args and args[0].isdigit():
            n = min(int(args[0]), 40)
        rows = self.store.tail("events.jsonl", n)
        if not rows:
            self.send("기록 없음")
            return
        out = ["📜 최근 판단 기록"]
        for e in rows:
            t = kst(e.get("ts", 0)).strftime("%m/%d %H:%M")
            k = e.get("kind")
            sym = short(e.get("sym", "")) if e.get("sym") else ""
            if k == "ENTRY":
                out.append(f"{t} 진입 {sym} {SIDE_KO.get(e.get('side'), '')} @{px(e.get('entry'))} 손절 {px(e.get('stop'))}")
            elif k == "EXIT":
                out.append(f"{t} 청산 {sym} {usd(e.get('pnl', 0))} ({e.get('r', 0):+.1f}R) {EXIT_KO.get(e.get('reason'), e.get('reason'))}")
            elif k == "SKIP":
                out.append(f"{t} 패스 {sym} {SIDE_KO.get(e.get('side'), '')}: {R.GUARD_KO.get(e.get('code'), e.get('code'))}")
            elif k == "TRAIL":
                out.append(f"{t} 손절이동 {sym} {px(e.get('old'))}→{px(e.get('new'))}")
            elif k == "GUARD":
                out.append(f"{t} 가드 {R.GUARD_KO.get(e.get('code'), e.get('code'))}")
            elif k == "ERROR":
                out.append(f"{t} 오류 {e.get('where')} {sym}: {str(e.get('msg'))[:80]}")
            else:
                out.append(f"{t} {k} {sym} {e.get('msg', '')}")
        self.send("\n".join(out))

    def cmd_pause(self, args):
        self.state["paused"] = True
        self.save()
        self.send("⏸ 신규 진입을 멈췄습니다. 보유 포지션 관리(손절·추적)는 계속합니다. 재개: /resume")

    def cmd_resume(self, args):
        self.state["paused"] = False
        self.save()
        self.send("▶️ 신규 진입을 재개합니다.")

    def _find_sym(self, word):
        w = word.upper()
        for s in list(self.positions) + list(self.cfg["symbols"]):
            if s == w or short(s) == w:
                return s
        return w if w.endswith("USDT") else w + "USDT"

    def cmd_close(self, args):
        if not args:
            self.send("사용법: /close BTC")
            return
        sym = self._find_sym(args[0])
        if sym not in self.positions:
            self.send(f"{short(sym)} 보유 포지션이 없습니다.")
            return
        self.confirm(f"{short(sym)} 포지션을 시장가로 청산할까요?", "close", sym)

    def act_close(self, sym):
        if sym in self.positions:
            self.exit_position(sym, "MANUAL")

    def cmd_closeall(self, args):
        if not self.positions:
            self.send("보유 포지션이 없습니다.")
            return
        self.confirm(f"보유 포지션 {len(self.positions)}개를 모두 시장가로 청산할까요?", "closeall")

    def act_closeall(self):
        for sym in list(self.positions):
            self.exit_position(sym, "MANUAL")

    def cmd_risk(self, args):
        if not args:
            self.send(f"현재 1회 위험: {self.cfg['risk_per_trade_pct']}% — 변경: /risk 2.5")
            return
        self.cmd_set(["risk_per_trade_pct", args[0]])

    def cmd_settings(self, args):
        keys = ["symbols", "signal_tf", "trend_tf", "allow_long", "allow_short", "risk_per_trade_pct", "max_leverage", "max_open_positions", "max_same_direction",
                "max_entries_per_day", "daily_loss_limit_pct", "loss_streak_limit", "loss_streak_pause_hours",
                "cooldown_after_loss_hours", "equity_floor_pct", "time_stop_hours", "adx_min",
                "brief_morning_kst", "brief_evening_kst", "update_url"]
        lines = ["⚙️ 설정 (변경: /set 키 값)"]
        for k in keys:
            v = self.cfg.get(k)
            if k == "symbols":
                v = ",".join(short(s) for s in v)
            lines.append(f"{k} = {v if v not in ('', None) else '(없음)'}")
        self.send("\n".join(lines))

    def cmd_set(self, args):
        if len(args) < 2 or args[0] not in SETTABLE:
            self.send("사용법: /set 키 값\n바꿀 수 있는 키: " + ", ".join(SETTABLE))
            return
        key, raw = args[0], " ".join(args[1:])
        kind, lo, hi = SETTABLE[key]
        try:
            if kind in (float, int):
                val = kind(float(raw)) if kind is int else float(raw)
                if not lo <= val <= hi:
                    raise ValueError(f"{lo}~{hi} 사이여야 합니다")
            elif kind is bool:
                low = raw.strip().lower()
                if low in ("true", "on", "1", "yes", "켜기", "켬"):
                    val = True
                elif low in ("false", "off", "0", "no", "끄기", "끔"):
                    val = False
                else:
                    raise ValueError("true 또는 false")
            elif kind is list:
                val = []
                for w in raw.replace(" ", "").split(","):
                    if not w:
                        continue
                    s = w.upper() if w.upper().endswith("USDT") else w.upper() + "USDT"
                    if self.filters and (s not in self.filters or self.filters[s]["status"] != "TRADING"):
                        raise ValueError(f"{s} 는 바이낸스 USDⓈ-M 무기한에 없습니다")
                    val.append(s)
                if not val:
                    raise ValueError("종목이 비었습니다")
            elif kind == "hhmm":
                hh, mm = [int(x) for x in raw.split(":")]
                if not (0 <= hh < 24 and 0 <= mm < 60):
                    raise ValueError("HH:MM 형식")
                val = f"{hh:02d}:{mm:02d}"
            else:
                val = raw.strip()
        except ValueError as e:
            self.send(f"값 오류: {e}")
            return
        settings = self.store.load_settings()
        settings[key] = val
        self.store.save_settings(settings)
        self.cfg[key] = val
        if key == "symbols":
            self.refresh_data()
        self.event("SET", key=key, msg=str(val))
        self.send(f"✅ {key} = {val} 로 바꿨습니다 (즉시 적용).")

    def cmd_rebase(self, args):
        eq = self.state.get("equity") or 0.0
        self.ledger["start_equity"] = eq
        self.ledger["peak_equity"] = eq
        self.state["floor_alerted"] = False
        self.state["max_dd"] = 0.0
        self.save()
        self.send(f"✅ 자본 기준점을 {usd(eq, False)}로 재설정했습니다. 바닥선 = {usd(eq * self.cfg['equity_floor_pct'] / 100, False)}")

    # --- mode switching
    def cmd_live(self, args):
        if self.state["mode"] == "live":
            self.send("이미 실전 모드입니다.")
            return
        import selftest
        res = selftest.run_checks(self.api, self.cfg, self.cfg["symbols"], fix=False)
        report = selftest.format_report(res)
        fails = [r for r in res if r["ok"] is False and r.get("blocking", True) and not r.get("fixable")]
        if fails:
            self.send(report + "\n\n❌ 위 문제를 해결해야 실전으로 전환할 수 있습니다.")
            return
        risk_amt = (res and next((r.get("equity") for r in res if r.get("equity")), 0) or 0) * self.cfg["risk_per_trade_pct"] / 100
        self.confirm(report + f"\n\n🔴 실전 모드로 전환할까요? 실제 돈으로 매매합니다.\n"
                     f"1회 위험 {self.cfg['risk_per_trade_pct']}% ≈ {usd(risk_amt, False)}. 모의 포지션은 정리됩니다.", "go_live")

    def act_go_live(self):
        try:
            live = LiveBroker(self.api, self.filters, self.cfg, self.log)
            self.broker = live
            self.check_account_settings(fix=True)
            eq = live.equity()
        except (BinanceError, NetworkError) as e:
            self.broker = self.make_broker()
            self.send(f"❌ 실전 전환 실패: {e}")
            return
        if self.state.get("blocked"):
            self.broker = self.make_broker()
            self.send(f"❌ 실전 전환 중단: {self.state['blocked']}")
            return
        try:
            PaperBroker(self.api, self.filters, self.cfg, self.store.path("paper.json"), self.log, self.clock).reset()
        except Exception:
            pass
        self.state.update(mode="live", positions={}, ledger=R.new_ledger(eq["equity"], self.now()),
                          max_dd=0.0, floor_alerted=False)
        for s in self.symbols():
            live.prepare(s)
        self.state["equity"] = eq["equity"]
        self.reconcile()
        self.save()
        self.event("MODE", msg="live")
        self.send(f"🔴 실전 모드 시작 — 잔고 {usd(eq['equity'], False)}\n"
                  f"1회 위험 {self.cfg['risk_per_trade_pct']}% ≈ {usd(eq['equity'] * self.cfg['risk_per_trade_pct'] / 100, False)} | "
                  f"자본 바닥선 {usd(eq['equity'] * self.cfg['equity_floor_pct'] / 100, False)}\n"
                  "다음 1시간봉 마감부터 신호를 봅니다.", keyboard=KEYBOARD)

    def cmd_paper(self, args):
        if self.state["mode"] == "paper":
            self.send("이미 모의 모드입니다.")
            return
        if self.positions:
            self.send("실전 포지션이 남아 있습니다. 먼저 /closeall 로 정리한 뒤 전환하세요.")
            return
        self.confirm("모의 모드로 전환할까요? (가상 잔고로 새로 시작)", "go_paper")

    def act_go_paper(self):
        if self.positions:
            self.send("실전 포지션이 남아 있어 전환을 취소했습니다.")
            return
        self.state.update(mode="paper", positions={})
        self.broker = self.make_broker()
        self.broker.reset()
        eq = self.broker.equity()
        self.state.update(ledger=R.new_ledger(eq["equity"], self.now()), max_dd=0.0, floor_alerted=False,
                          equity=eq["equity"])
        self.save()
        self.event("MODE", msg="paper")
        self.send(f"🧪 모의 모드 시작 — 가상 잔고 {usd(eq['equity'], False)}")

    # --- background jobs
    def _bg(self, name, fn):
        if self.bg_busy:
            self.send(f"이미 '{self.bg_busy}' 작업이 진행 중입니다. 끝나면 다시 시도하세요.")
            return

        def run():
            try:
                fn()
            except Exception as e:
                self.log.error("%s failed: %s\n%s", name, e, traceback.format_exc())
                self.send(f"⚠️ {name} 실패: {e}")
            finally:
                self.bg_busy = None

        self.bg_busy = name
        threading.Thread(target=run, daemon=True, name=name).start()

    def cmd_backtest(self, args):
        days = 365
        if args and args[0].isdigit():
            days = max(30, min(int(args[0]), 1095))
        self.send(f"⏳ 최근 {days}일 백테스트를 시작합니다(데이터 내려받기 포함 1~3분).")
        cfg = dict(self.cfg)

        def job():
            import backtest
            text, _ = backtest.report(cfg, days, risks=None, cache_dir=self.store.path("cache"),
                                      api=self.public_api_factory(), log=self.log)
            self.send(text)

        self._bg("백테스트", job)

    def cmd_selftest(self, args):
        import selftest
        if args and args[0].lower() == "live":
            self.confirm("실주문 왕복 테스트를 할까요?\n최소 수량(약 6달러어치)을 시장가로 사고, 손절 주문을 걸었다 취소한 뒤 바로 팝니다.\n"
                         "비용은 수수료·호가차이로 보통 0.01달러 안팎입니다.", "selftest_live")
            return
        res = selftest.run_checks(self.api, self.cfg, self.cfg["symbols"], fix=False)
        self.send(selftest.format_report(res))

    def act_selftest_live(self):
        import selftest

        def job():
            out = selftest.live_roundtrip(self.api, self.cfg, self.filters, self.log,
                                          exclude=set(self.positions))
            self.send(out["text"])

        self._bg("실주문 테스트", job)

    def cmd_update(self, args):
        url = self.cfg.get("update_url")
        if not url:
            self.send("업데이트 주소가 없습니다. /set update_url https://github.com/아이디/저장소/raw/main/trendhunter.zip")
            return
        self.confirm(f"아래 주소의 최신 코드로 업데이트할까요?\n{url}\n(검증에 실패하면 기존 버전을 유지합니다)", "update")

    def act_update(self):
        import updater

        def job():
            old, new = updater.update(self.cfg["update_url"], APP_DIR, self.store.dir)
            self.send(f"✅ 업데이트 v{old} → v{new} 설치 완료. 재시작합니다(포지션·손절은 유지).")
            self.exit_code = 0

        self._bg("업데이트", job)

    def cmd_rollback(self, args):
        self.confirm("직전 버전으로 되돌릴까요?", "rollback")

    def act_rollback(self):
        import updater
        ver = updater.rollback(APP_DIR, self.store.dir)
        self.send(f"↩️ v{ver} 로 복구했습니다. 재시작합니다.")
        self.exit_code = 0

    def cmd_restart(self, args):
        self.confirm("봇을 재시작할까요? (포지션·손절은 유지됩니다)", "restart")

    def act_restart(self):
        self.send("🔄 재시작합니다.")
        self.exit_code = 0

    def cmd_version(self, args):
        self.send(f"{self.cfg['bot_name']} v{self.cfg['version']}")


# ---------------------------------------------------------------- runner

def run(data_dir):
    store = Store(data_dir)
    log = setup_logging(store)
    cfg = load_config(APP_DIR, store)
    sec = store.load_secrets()
    if not sec.get("telegram_token"):
        log.error("secrets.json 이 없습니다. install.sh 를 먼저 실행하세요.")
        return 2
    base = os.environ.get("TH_BINANCE_BASE", "https://fapi.binance.com")
    api = BinanceFutures(sec.get("binance_key", ""), sec.get("binance_secret", ""), base_url=base, log=log)
    tg = Telegram(sec["telegram_token"], sec.get("telegram_chat_id"), log=log)
    trader = Trader(cfg, store, api, tg, log)
    q = queue.Queue()
    poller = Poller(tg, q, log)
    poller.start()

    stopping = {"flag": False}

    def on_term(signum, frame):
        stopping["flag"] = True

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    # start-up with retries (e.g. network down, wrong key) while still answering commands
    while not stopping["flag"]:
        try:
            trader.startup()
            break
        except Exception as e:
            log.error("startup failed: %s\n%s", e, traceback.format_exc())
            hint = ""
            if isinstance(e, BinanceError) and (e.status == 451 or e.code == -2015):
                hint = ("\n힌트: -2015 = API 키/IP 제한/선물 권한 문제, 451 = 서버 국가 차단(미국 리전 등).")
            trader.alert("startup", f"⚠️ 봇 시작 실패: {e}{hint}\n1분 뒤 다시 시도합니다. /selftest 로 점검할 수 있어요.", every=900)
            end = time.time() + 60
            while time.time() < end and not stopping["flag"]:
                try:
                    u = q.get(timeout=1)
                    if trader.broker is None:
                        trader.broker = trader.make_broker()
                    trader.handle_update(u)
                except queue.Empty:
                    pass
                except Exception as ex:
                    log.warning("command during startup failed: %s", ex)

    next_step = 0.0
    loop = float(cfg.get("loop_seconds", 20))
    while not stopping["flag"] and trader.exit_code is None:
        now = time.time()
        if now >= next_step:
            try:
                trader.step()
                if trader.err_alerted:
                    trader.send("✅ 거래소 연결이 복구됐습니다.")
                trader.err_count = 0
                trader.err_alerted = False
            except Exception as e:
                trader.err_count += 1
                log.error("step failed (%d): %s\n%s", trader.err_count, e, traceback.format_exc())
                trader.event("ERROR", where="step", msg=str(e)[:300])
                if trader.err_count >= 3 and not trader.err_alerted:
                    trader.err_alerted = True
                    trader.send(f"⚠️ 연속 오류 {trader.err_count}회: {e}\n거래소 손절 주문은 유지됩니다. 계속 재시도합니다.")
            next_step = now + loop
        try:
            u = q.get(timeout=1.0)
            trader.handle_update(u)
        except queue.Empty:
            pass
        except Exception as e:
            log.error("update handling failed: %s", e)
    poller.stop()
    trader.save()
    if trader.exit_code is None:
        trader.send("⏹ 봇이 정지됐습니다. 거래소에 걸린 손절 주문은 그대로 유지됩니다.")
        return 0
    return trader.exit_code


def check(data_dir):
    """Used by the updater: imports everything and validates the config."""
    import backtest  # noqa: F401
    import selftest  # noqa: F401
    import updater  # noqa: F401
    store = Store(data_dir)
    cfg = load_config(APP_DIR, store)
    for key in ("symbols", "signal_tf", "trend_tf", "risk_per_trade_pct", "ma_periods"):
        if key not in cfg:
            raise SystemExit(f"config missing {key}")
    if cfg["signal_tf"] not in TF_SECONDS or cfg["trend_tf"] not in TF_SECONDS:
        raise SystemExit("bad timeframe")
    print(f"OK {cfg['bot_name']} {cfg['version']}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.environ.get("TH_DATA_DIR", os.path.expanduser("~/trendhunter-data")))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.check:
        return check(a.data)
    return run(a.data)


if __name__ == "__main__":
    sys.exit(main())
