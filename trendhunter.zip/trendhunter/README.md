# TrendHunter v1.0.0

바이낸스 USDⓈ-M 무기한 선물 추세추종 자동매매 봇. 서버(우분투)에서 24시간 돌고, 텔레그램으로 조작합니다.
자세한 설치·운영·전략 설명은 Claude가 함께 만든 설명서를 보세요.

## 설치 (서버에서 한 번)
```
U=https://github.com/<아이디>/trendhunter/raw/main/trendhunter.zip
cd ~ && curl -fsSL -o th.zip "$U" && python3 -m zipfile -e th.zip ~ && bash ~/trendhunter/install.sh "$U"
```
- 파이썬 표준 라이브러리만 사용(추가 설치 없음), Ubuntu 22.04/24.04, python3 3.8+
- 키는 `~/trendhunter-data/secrets.json` (권한 600)에만 저장됩니다. 코드에는 비밀정보가 없습니다.
- 처음엔 모의(PAPER) 모드로 시작합니다. 실전 전환은 텔레그램 `/live`.

## 파일
| 파일 | 역할 |
|---|---|
| bot.py | 메인 루프, 텔레그램 명령, 브리핑 |
| strategy.py | 일봉 4이평 정배열 + 4시간봉 20봉 돌파, 손절·추적 규칙 |
| risk.py | 1회 위험 기반 수량·레버리지, 가드(일일한도·쿨다운·연패휴식·바닥선) |
| brokers.py | 실전(바이낸스)·모의 체결 |
| binance_api.py | 바이낸스 REST 클라이언트 (손절 = Algo Order API) |
| backtest.py | 같은 규칙으로 백테스트 (`/backtest 365`) |
| selftest.py | 계정·API 점검, 소액 실주문 왕복 테스트 |
| updater.py | zip 주소에서 업데이트·롤백 (검증 후 교체) |
| install.sh, th | 설치 스크립트, 서버 관리 명령 |
| config.json | 기본 설정 (텔레그램 `/set` 변경값은 data/settings.json 에 저장) |
| tests/ | 가짜 거래소로 돌리는 테스트 (`python3 -m unittest discover tests`) |

과거 성과는 미래 수익을 보장하지 않습니다. 잃어도 되는 돈으로만 운용하세요.
